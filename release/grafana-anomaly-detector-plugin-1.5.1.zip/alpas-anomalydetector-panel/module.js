/* [create-plugin] version: 7.0.7 */
/* [create-plugin] plugin: alpas-anomalydetector-panel@1.5.1 */
define(["@emotion/css","@grafana/data","@grafana/runtime","@grafana/ui","react"],(e,t,a,i,n)=>(()=>{"use strict";var r={89(t){t.exports=e},781(e){e.exports=t},531(e){e.exports=a},7(e){e.exports=i},959(e){e.exports=n}},s={};function o(e){var t=s[e];if(void 0!==t)return t.exports;var a=s[e]={exports:{}};return r[e](a,a.exports,o),a.exports}o.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return o.d(t,{a:t}),t},o.d=(e,t)=>{for(var a in t)o.o(t,a)&&!o.o(e,a)&&Object.defineProperty(e,a,{enumerable:!0,get:t[a]})},o.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),o.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var l={};o.r(l),o.d(l,{plugin:()=>Ea});var c=o(781);function d(e){const t="string"==typeof e?e.trim().toLowerCase():"";return"high_mean"===t||"low_mean"===t||"high_or_low"===t?{direction:t,warning:null}:{direction:"high_or_low",warning:null==e?null:"Unsupported anomaly direction. Using high_or_low (both directions). Review Advanced tuning and save a supported direction."}}const m=.2,u=10,p=4;var h=o(959),g=o.n(h),f=o(89),y=o(7),v=o(531);function b(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}const w=e=>e.reduce((e,t)=>e+t,0),x=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2?t[a]:(t[a-1]+t[a])/2},E=(e,t)=>{const a=e.map(e=>e-t),i=w(a.map(e=>e*e));let n=0;for(let e=1;e<a.length;e++)n+=a[e-1]*a[e];return i?Math.max(0,Math.min(.98,n/i)):0};class k{get length(){return this.items.length}get first(){return this.items[this.start]}push(e){this.items.length<this.capacity?this.items.push(e):(this.items[this.start]=e,this.start=(this.start+1)%this.capacity)}values(){return this.items.slice(this.start).concat(this.items.slice(0,this.start))}constructor(e){b(this,"capacity",void 0),b(this,"items",void 0),b(this,"start",void 0),this.capacity=e,this.items=[],this.start=0}}class S{estimateNoise(e,t,a,i){const n=this.errors.length>=32?this.errors.values():this.clean.values().map((e,n)=>e-t-a*this.sines[n]-i*this.cosines[n]),r=x(n);let s=Math.max(1.4826*x(n.map(e=>Math.abs(e-r))),1e-6*Math.abs(e),1e-6);const o=E(n,r),l=2*this.period-this.raw.length,c=this.raw.values().slice(0,-10).map((e,n)=>e-t-a*this.sines[l+n]-i*this.cosines[l+n]),d=x(c);s=Math.max(s,1.4826*x(c.map(e=>Math.abs(e-d))),(e=>{const t=[...e].sort((e,t)=>e-t),a=e=>{const a=(t.length-1)*e,i=Math.floor(a);return t[i]+(t[Math.min(i+1,t.length-1)]-t[i])*(a-i)};return(a(.9)-a(.1))/2.5631031310892007})(c));const m=Math.max(o,E(c,d));return[s*Math.min(2.5,1/Math.sqrt(1-m)),m]}update(e){var t;if(!Number.isFinite(e))throw new Error("Harmonic samples must be finite.");const a=this.count++,i=2*this.period;if(a<i)return this.clean.push(e),this.raw.push(e),null;if(a%this.period===0){const e=this.clean.values();this.total=w(e),this.sineTotal=w(e.map((e,t)=>e*this.sines[t])),this.cosineTotal=w(e.map((e,t)=>e*this.cosines[t]))}const n=this.total/i,r=2*this.sineTotal/i,s=2*this.cosineTotal/i,o=n+s,l=o+(this.biases.length?x(this.biases.values()):0);null!==this.frozen||null!==this.noise&&a%Math.min(16,this.period)!==0||(this.noise=this.estimateNoise(l,n,r,s));const[c,d]=null!==(t=this.frozen)&&void 0!==t?t:this.noise,m=(e-l)/c;this.normalized.push(m);const u=this.normalized.length,p=w(this.normalized.values())/u;if(u!==this.windowCount||d!==this.windowRho){let e=0;for(let t=1;t<u;t++)e+=(1-t/u)*Math.pow(d,t);this.windowScale=Math.sqrt(u/(1+2*e)),this.windowCount=u,this.windowRho=d}const h=p*m>0&&Math.abs(m)>1?Math.abs(p)*this.windowScale:0,g=Math.abs(m);let f;Math.max(g,h)>=.75*this.threshold?(this.frozen=[c,d],f=o):(this.frozen=null,f=e,this.biases.push(e-o),this.errors.push(e-l));const y=this.clean.first;this.clean.push(f),this.raw.push(e),this.total+=f-y;const v=this.sineTotal,b=this.cosineTotal-y+f;return this.sineTotal=v*this.phaseCosine-b*this.phaseSine,this.cosineTotal=b*this.phaseCosine+v*this.phaseSine,{expected:l,spread:c,pointScore:g,windowScore:h}}constructor(e,t){if(b(this,"period",void 0),b(this,"threshold",void 0),b(this,"count",void 0),b(this,"clean",void 0),b(this,"raw",void 0),b(this,"errors",void 0),b(this,"biases",void 0),b(this,"normalized",void 0),b(this,"sines",void 0),b(this,"cosines",void 0),b(this,"phaseSine",void 0),b(this,"phaseCosine",void 0),b(this,"total",void 0),b(this,"sineTotal",void 0),b(this,"cosineTotal",void 0),b(this,"noise",void 0),b(this,"frozen",void 0),b(this,"windowCount",void 0),b(this,"windowRho",void 0),b(this,"windowScale",void 0),this.period=e,this.threshold=t,this.count=0,this.errors=new k(128),this.biases=new k(32),this.normalized=new k(10),this.total=0,this.sineTotal=0,this.cosineTotal=0,this.noise=null,this.frozen=null,this.windowCount=0,this.windowRho=-1,this.windowScale=1,!Number.isInteger(e)||e<8||e>4096)throw new Error("Harmonic period must be 8 to 4096 scored samples.");if(!Number.isFinite(t)||t<=0)throw new Error("Harmonic threshold must be positive and finite.");this.clean=new k(2*e),this.raw=new k(Math.min(2*e,138)),this.sines=Array.from({length:2*e},(t,a)=>Math.sin(a*(2*Math.PI)/e)),this.cosines=Array.from({length:2*e},(t,a)=>Math.cos(a*(2*Math.PI)/e)),this.phaseSine=Math.sin(2*Math.PI/e),this.phaseCosine=Math.cos(2*Math.PI/e)}}function F(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}const M=e=>{const t=w(e)/e.length;return Math.sqrt(w(e.map(e=>Math.pow(e-t,2)))/e.length)};class ${update(e){if(!Number.isFinite(e))throw new Error("Rolling samples must be finite.");const t=this.count++,a=this.clean.values();if(a.length<this.window)return this.clean.push(e),this.raw.push(e),null;const i="zscore"===this.algorithm?w(a)/a.length:x(a);if(null===this.frozen&&(null===this.noise||t%16==0)){const e=this.errors.length>=32?this.errors.values():a,t=x(e),n=[...e].sort((e,t)=>e-t);let r=Math.max(1.4826*x(e.map(e=>Math.abs(e-t))),(n[Math.floor(.9*(n.length-1))]-n[Math.floor(.1*(n.length-1))])/2.563);r<=1e-9&&(r=Math.max(.02*Math.abs(i),1e-6));const s=this.raw.values().slice(0,-10),o=s.length?E(s,w(s)/s.length):0;this.noise=[r,o,Math.min(2.5,1/Math.sqrt(1-E(e,t)))]}let[n,r,s]=this.noise;null===this.frozen?("zscore"===this.algorithm?n=Math.max(n,M(a)):(n=Math.max(n,1.4826*x(a.map(e=>Math.abs(e-i)))),new Set(a).size<=5&&(n=Math.max(n,M(a)))),n*=s):[n,r]=this.frozen;const o=(e-i)/n;this.recent.push(o);const l=this.recent.length,c=w(this.recent.values())/l;if(l!==this.windowCount||r!==this.windowRho){let e=0;for(let t=1;t<l;t++)e+=(1-t/l)*Math.pow(r,t);this.windowScale=Math.sqrt(l/(1+2*e)),this.windowCount=l,this.windowRho=r}const d=o*c>0&&Math.abs(o)>Math.max(1,.5*Math.abs(c))?Math.abs(c)*this.windowScale:0,m=Math.abs(o),u=t>=Math.max(128,4*this.window)||Math.min(...a)===Math.max(...a)||t>=2*this.window&&m>=2*this.threshold;return Math.max(m,d)>=Math.min(3,.75*this.threshold)&&u?(this.frozen=[n,r],this.clean.push(i)):(this.frozen=null,this.clean.push(e),this.errors.push(e-i)),this.raw.push(e),{expected:i,spread:n,pointScore:m,windowScore:d}}constructor(e,t,a){if(F(this,"algorithm",void 0),F(this,"window",void 0),F(this,"threshold",void 0),F(this,"count",void 0),F(this,"clean",void 0),F(this,"raw",void 0),F(this,"errors",void 0),F(this,"recent",void 0),F(this,"frozen",void 0),F(this,"noise",void 0),F(this,"windowCount",void 0),F(this,"windowRho",void 0),F(this,"windowScale",void 0),this.algorithm=e,this.window=t,this.threshold=a,this.count=0,this.raw=new k(128),this.errors=new k(128),this.recent=new k(10),this.frozen=null,this.noise=null,this.windowCount=0,this.windowRho=-1,this.windowScale=1,!Number.isInteger(t)||t<3||!Number.isFinite(a)||a<=0)throw new Error("Rolling window must be an integer >=3 and threshold positive and finite.");this.clean=new k(t)}}function N(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}class C{update(e){var t;if(!Number.isFinite(e))throw new Error("EWMA samples must be finite.");const a=this.count++;null===this.smooth&&(this.smooth=this.smooth2=e);const i=2*this.smooth-this.smooth2,n=e-i;if(a<this.window)return this.errors.push(n),this.rawErrors.push(n),this.smooth=this.alpha*e+(1-this.alpha)*this.smooth,this.smooth2=this.alpha*this.smooth+(1-this.alpha)*this.smooth2,null;if(null===this.frozen&&(null===this.noise||a%16==0)){const e=this.errors.values();let t=this.rawErrors.values().slice(0,-10);t.length||(t=e);const a=x(e),n=[...t].sort((e,t)=>e-t);let r=Math.max(1.4826*x(e.map(e=>Math.abs(e-a))),(n[Math.floor(.9*(n.length-1))]-n[Math.floor(.1*(n.length-1))])/2.563);r<=1e-9&&(r=1.4826*Math.max(.02*Math.abs(i),1e-6));const s=Math.max(E(e,a),E(t,x(t)));this.noise=[r*Math.min(2.5,1/Math.sqrt(1-s)),s]}const[r,s]=null!==(t=this.frozen)&&void 0!==t?t:this.noise,o=n/r;this.recent.push(o);const l=this.recent.length,c=w(this.recent.values())/l;if(l!==this.windowCount||s!==this.windowRho){let e=0;for(let t=1;t<l;t++)e+=(1-t/l)*Math.pow(s,t);this.windowScale=Math.sqrt(l/(1+2*e)),this.windowCount=l,this.windowRho=s}const d=o*c>0&&Math.abs(o)>Math.max(1,.5*Math.abs(c))?Math.abs(c)*this.windowScale:0,m=Math.min(2.5,1/Math.sqrt(1-s)),u=r/m/1.4826,p=Math.abs(n)/(r/m)*1.4826,h=(a>=Math.max(128,4*this.window)||this.errors.values().every(e=>Math.abs(e)<=1e-9)||a>=2*this.window&&p>=2*this.threshold)&&Math.max(Math.abs(o),d)>=Math.min(3,.75*this.threshold);return this.rawErrors.push(n),h?this.frozen=[r,s]:(this.frozen=null,this.errors.push(n),this.smooth=this.alpha*e+(1-this.alpha)*this.smooth),this.smooth2=this.alpha*this.smooth+(1-this.alpha)*this.smooth2,{expected:i,spread:u,pointScore:p,windowScore:d}}constructor(e,t,a=10){if(N(this,"window",void 0),N(this,"threshold",void 0),N(this,"count",void 0),N(this,"smooth",void 0),N(this,"smooth2",void 0),N(this,"errors",void 0),N(this,"rawErrors",void 0),N(this,"recent",void 0),N(this,"noise",void 0),N(this,"frozen",void 0),N(this,"windowCount",void 0),N(this,"windowRho",void 0),N(this,"windowScale",void 0),N(this,"alpha",void 0),this.window=e,this.threshold=t,this.count=0,this.smooth=null,this.smooth2=0,this.errors=new k(128),this.rawErrors=new k(138),this.noise=null,this.frozen=null,this.windowCount=0,this.windowRho=-1,this.windowScale=1,!Number.isInteger(e)||e<3||!Number.isFinite(t)||t<=0)throw new Error("EWMA requires window >=3 and a finite positive threshold.");if(this.alpha=2/(e+1),!Number.isInteger(a)||a<3||a>12)throw new Error("Evidence window must be between 3 and 12.");this.recent=new k(a)}}function A(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}class L{append(e,t){this.clean.length<this.capacity?this.clean.push(e):this.clean[t%this.capacity]=e}update(e){var t;if(!Number.isFinite(e))throw new Error("Seasonal samples must be finite.");const a=this.count++;if(null===this.frozen&&a>=2*this.period&&a%16==0){const e=[];for(let t=a-this.period;t<a;t++)e.push(this.clean[t%this.capacity]-this.clean[(t-this.period)%this.capacity]);const t=x(e),i=E(e,t),n=1.4826*x(e.map(e=>Math.abs(e-t)))/Math.sqrt(1-i),r=i<.5&&Math.abs(t)>2*Math.max(n,1e-6)?t/this.period:0;r!==this.drift&&(this.biases=new k(16)),this.drift=r}const i=[];for(let e=1;e<=Math.min(this.depth,Math.floor(a/this.period));e++)for(const t of[a-e*this.period-1,a-e*this.period,a-e*this.period+1])t>=0&&t<a&&i.push(this.clean[t%this.capacity]+this.drift*(a-t));const n=i.length?w(i)/i.length:e,r=n+(this.biases.length?x(this.biases.values()):0),s=e-r;if(a<2*this.period)return this.append(e,a),this.errors.push(s),this.rawErrors.push(s),null;if(null===this.frozen&&(null===this.noise||a%16==0)){const e=this.errors.values();let t=this.rawErrors.values().slice(0,-10);t.length||(t=e);const a=x(e),i=[...t].sort((e,t)=>e-t);let n=Math.max(1.4826*x(e.map(e=>Math.abs(e-a))),(i[Math.floor(.9*(i.length-1))]-i[Math.floor(.1*(i.length-1))])/2.563);n<=1e-9&&(n=Math.max(.02*Math.abs(r),1e-6));const s=Math.max(E(e,a),E(t,x(t)));this.noise=[n*Math.min(2.5,1/Math.sqrt(1-s)),s]}const[o,l]=null!==(t=this.frozen)&&void 0!==t?t:this.noise,c=s/o;this.recent.push(c);const d=this.recent.length,m=w(this.recent.values())/d;if(d!==this.windowCount||l!==this.windowRho){let e=0;for(let t=1;t<d;t++)e+=(1-t/d)*Math.pow(l,t);this.windowScale=Math.sqrt(d/(1+2*e)),this.windowCount=d,this.windowRho=l}const u=c*m>0&&Math.abs(c)>Math.max(1,.5*Math.abs(m))?Math.abs(m)*this.windowScale:0,p=a>=Math.max(128,4*this.depth)&&Math.max(Math.abs(c),u)>=Math.min(3,.75*this.threshold);let h;return this.rawErrors.push(s),p?(this.frozen=[o,l],h=n):(this.frozen=null,h=e,this.errors.push(s),this.biases.push(e-n)),this.append(h,a),{expected:r,spread:o,pointScore:Math.abs(c),windowScore:u}}constructor(e,t,a){if(A(this,"period",void 0),A(this,"depth",void 0),A(this,"threshold",void 0),A(this,"count",void 0),A(this,"capacity",void 0),A(this,"clean",void 0),A(this,"errors",void 0),A(this,"rawErrors",void 0),A(this,"recent",void 0),A(this,"biases",void 0),A(this,"drift",void 0),A(this,"noise",void 0),A(this,"frozen",void 0),A(this,"windowCount",void 0),A(this,"windowRho",void 0),A(this,"windowScale",void 0),this.period=e,this.depth=t,this.threshold=a,this.count=0,this.clean=[],this.errors=new k(128),this.rawErrors=new k(138),this.recent=new k(10),this.biases=new k(16),this.drift=0,this.noise=null,this.frozen=null,this.windowCount=0,this.windowRho=-1,this.windowScale=1,!Number.isInteger(e)||e<2||!Number.isInteger(t)||t<3||!Number.isFinite(a)||a<=0)throw new Error("Seasonal period >=2, depth >=3 and a finite positive threshold are required.");this.capacity=t*e+1}}function B(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function D(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},i=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(i=i.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),i.forEach(function(t){B(e,t,a[t])})}return e}function T(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);t&&(i=i.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,i)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const P={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},_=(Object.values(P).sort((e,t)=>e-t),{warning_first:{low:35,medium:55,high:72,critical:88},balanced:{low:40,medium:60,high:75,critical:90},page_first:{low:45,medium:65,high:82,critical:95}}),R=e=>{if(!Number.isFinite(e.time)||!Number.isFinite(e.value))return null;const t=Number.isFinite(e.sampleCount)?Math.max(1,Math.floor(e.sampleCount)):1,a=Number.isFinite(e.minValue)?e.minValue:e.value,i=Number.isFinite(e.maxValue)?e.maxValue:e.value;return T(D({},e),{bucketStart:Number.isFinite(e.bucketStart)?e.bucketStart:e.time,bucketEnd:Number.isFinite(e.bucketEnd)?e.bucketEnd:e.time,sampleCount:t,minValue:Math.min(a,i,e.value),maxValue:Math.max(a,i,e.value)})},I=e=>e.map(R).filter(e=>null!==e).sort((e,t)=>e.time-t.time),V=e=>Number.isFinite(e)?Math.max(0,Math.min(100,e)):0,q=e=>e.reduce((e,t)=>e+t,0)/e.length,O=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},z=(e,t)=>{if(0===e.length)return 0;const a=null!=t?t:O(e);return 1.4826*O(e.map(e=>Math.abs(e-a)))},W=(e,t)=>Number.isFinite(e)&&e>1e-9?e:Math.max(.02*Math.abs(t),1e-6),j=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(D({},a))}return t},H=(e,t,a)=>{const i=_[a],n=e/Math.max(t,1e-4);if(n<1)return{severityScore:Math.min(i.low-1,Math.round(n*(i.low-1))),severityLabel:"normal"};const r=Math.min(100,Math.round(i.low+30*(n-1)));return r>=i.critical?{severityScore:r,severityLabel:"critical"}:r>=i.high?{severityScore:r,severityLabel:"high"}:r>=i.medium?{severityScore:r,severityLabel:"medium"}:{severityScore:r,severityLabel:"low"}},U=(e,t,a)=>{const i=Math.max(0,t-a),n=t+1-i,r=Math.max(i,t+1-Math.max(4,Math.min(a,8))),s=e.slice(r,t+1);if(n<Math.max(3,Math.floor(a/2)))return"thin";if(s.length>=3){const e=s.slice(1).map((e,t)=>e.time-s[t].time).filter(e=>e>0),t=e.length>0?Math.min(...e):null,a=e.length>0?Math.max(...e):null;if(t&&a&&a>1.8*t)return"gappy"}if(s.length>=4){const e=s.map(e=>e.value),t=Math.max(.002*Math.abs(q(e)),1e-6);if(Math.max(...e)-Math.min(...e)<=t)return"flatline"}return"healthy"},Q=(e,t,a,i,n,r)=>{const s=Math.max(t,1e-6);let o=Math.min(e/s,2.5)/2.5*100;i>a&&(o+=8),n>=8&&(o+=4),"thin"===r?o-=18:"flatline"===r?o-=22:"gappy"===r&&(o-=12);const l=Math.max(5,Math.min(100,Math.round(10*o)/10));return{confidenceScore:l,confidenceLabel:l>=80?"high":l>=55?"medium":"low",dataQualityLabel:r}},G=(e,t,a)=>{const i=H(0,t,a);return T(D(T(D({},e),{expected:null,upper:null,lower:null,score:0,pointScore:0,windowScore:0,scoreDriver:"point",isAnomaly:!1,decisionState:"warming_up"}),i),{confidenceScore:5,confidenceLabel:"low",dataQualityLabel:"thin"})},Y=(e,t,a,i)=>e.map((n,r)=>{const s=e.slice(Math.max(0,r-a),r).map(e=>e.value);if(s.length<(o=a,Math.max(3,Math.floor(Number.isFinite(o)?o:3))))return G(n,t,i);var o;const l=q(s),c=W(((e,t)=>{if(e.length<=1)return 0;const a=null!=t?t:q(e),i=e.reduce((e,t)=>e+Math.pow(t-a,2),0)/e.length;return Math.sqrt(i)})(s,l),l),d=Math.abs(n.value-l)/c,m=d,u=H(m,t,i),p=Q(m,t,d,0,s.length+1,U(e,r,a));return D(T(D({},n),{expected:l,lower:l-t*c,upper:l+t*c,score:m,pointScore:d,windowScore:0,scoreDriver:0>d?"window":"point",isAnomaly:m>=t,decisionState:m>=t?"open":"normal"}),u,p)}),K=(e,t,a,i,n,r)=>{const s="cycle"===n&&i>=8?new L(i,a,t):null,o=new Map,l=new Map;return e.map((c,d)=>{let m=[];if(s){const i=s.update(c.value);if(null===i)return G(c,t,r);const{expected:n,spread:o,pointScore:l,windowScore:m}=i,u=Math.max(l,m);return D(T(D({},c),{expected:n,lower:n-t*o,upper:n+t*o,score:u,pointScore:l,windowScore:m,scoreDriver:m>l?"window":"point",isAnomaly:u>=t,decisionState:u>=t?"open":"normal"}),H(u,t,r),Q(u,t,l,m,a+1,U(e,d,a)))}if("cycle"===n){for(let t=d-i;t>=0&&m.length<a;t-=i)m.push(e[t].value);m.reverse()}else{var u,p,h,g;const e=(e=>{const t=new Date(e);return{hour_of_day:`hour:${t.getHours()}`,weekday_hour:`weekday:${t.getDay()}-${t.getHours()}`}})(c.time);var f;if(m="hour_of_day"===n?[...null!==(u=o.get(e.hour_of_day))&&void 0!==u?u:[]].slice(-a):[...null!==(p=l.get(e.weekday_hour))&&void 0!==p?p:[]].slice(-a),"weekday_hour"===n&&m.length<3)m=[...null!==(f=o.get(e.hour_of_day))&&void 0!==f?f:[]].slice(-a);const t=null!==(h=o.get(e.hour_of_day))&&void 0!==h?h:[];t.push(c.value),o.set(e.hour_of_day,t);const i=null!==(g=l.get(e.weekday_hour))&&void 0!==g?g:[];i.push(c.value),l.set(e.weekday_hour,i)}if(m.length<3)return G(c,t,r);const y=e.slice(Math.max(0,d-a),d).map(e=>e.value),{expected:v,spread:b}=((e,t)=>{const a=O(e),i=W(z(e,a),a),n=e.slice(1).map((t,a)=>t-e[a]),r=n.length>=2?O(n):0,s=n.length>=2?W(z(n,r),a):0,o=t.length>0?W(z(t),O(t)):0,l=Math.max(i,s,.75*o);return{expected:a+r,spread:W(l,a+r)}})(m,y),w=Math.abs(c.value-v)/b,x=w,E=H(x,t,r),k=Q(x,t,w,0,y.length+1,U(e,d,a));return D(T(D({},c),{expected:v,lower:v-t*b,upper:v+t*b,score:x,pointScore:w,windowScore:0,scoreDriver:0>w?"window":"point",isAnomaly:x>=t,decisionState:x>=t?"open":"normal"}),E,k)})},J=(e,t)=>{var a,i,n,r,s,o,l,c;const m=Math.max(t.baselineWindow,3),u=Math.max(t.sensitivity,.2),p=j(I(e));let h;switch(t.algorithm){case"zscore":case"mad":case"harmonic":{const e="harmonic"===t.algorithm?new S(t.seasonalitySamples,u):new $(t.algorithm,m,u);h=p.map((a,i)=>{const n=e.update(a.value);if(null===n)return G(a,u,t.severityPreset);const{expected:r,spread:s,pointScore:o,windowScore:l}=n,c=Math.max(o,l);return D(T(D({},a),{expected:r,lower:r-u*s,upper:r+u*s,score:c,pointScore:o,windowScore:l,scoreDriver:l>o?"window":"point",isAnomaly:c>=u,decisionState:c>=u?"open":"normal"}),H(c,u,t.severityPreset),Q(c,u,o,l,"harmonic"===t.algorithm?9:m+1,U(p,i,m)))});break}case"ewma":h=((e,t,a,i)=>{const n=[],r=new C(a,t);return e.forEach((s,o)=>{const l=r.update(s.value);if(null===l)return void n.push(G(s,t,i));const{expected:c,spread:d,pointScore:m,windowScore:u}=l,p=Math.max(m,u),h=H(p,t,i),g=Q(p,t,m,u,a+1,U(e,o,a));n.push(D(T(D({},s),{expected:c,lower:c-t*d,upper:c+t*d,score:p,pointScore:m,windowScore:u,scoreDriver:u>m?"window":"point",isAnomaly:p>=t,decisionState:p>=t?"open":"normal"}),h,g))}),n})(p,u,m,t.severityPreset);break;case"level_shift":h=((e,t,a,i)=>{const n=Math.min(Math.max(3,Math.floor(a/3)),12),r=new C(a,t,n);return e.map((n,s)=>{const o=r.update(n.value);if(null===o)return G(n,t,i);const{expected:l,spread:c,pointScore:d,windowScore:m}=o,u=Math.max(.85*d,m),p=H(u,t,i),h=Q(u,t,d,m,a+1,U(e,s,a));return D(T(D({},n),{expected:l,lower:l-t*c,upper:l+t*c,score:u,pointScore:d,windowScore:m,scoreDriver:m>=.85*d?"window":"point",isAnomaly:u>=t,decisionState:u>=t?"open":"normal"}),p,h)})})(p,u,m,t.severityPreset);break;case"seasonal":h=K(p,u,m,Math.max(t.seasonalitySamples,2),t.seasonalRefinement,t.severityPreset);break;default:h=Y(p,u,m,t.severityPreset)}const g=d(t.anomalyDirection).direction,f=Math.max(0,null!==(a=t.minimumAbsoluteDeviation)&&void 0!==a?a:0),y=Math.max(0,null!==(i=t.minimumRelativeDeviation)&&void 0!==i?i:0),v=Math.max(0,null!==(n=t.minimumActivity)&&void 0!==n?n:0),b=Math.max(1,Math.round(null!==(r=t.persistenceWindow)&&void 0!==r?r:1)),w=Math.max(1,Math.min(b,Math.round(null!==(s=t.persistenceBuckets)&&void 0!==s?s:1))),x=Math.max(0,Math.min(u,null!==(o=t.recoveryThreshold)&&void 0!==o?o:0)),E=Math.max(1,Math.round(null!==(l=t.recoveryBuckets)&&void 0!==l?l:1)),k=Math.max(0,Math.round(null!==(c=t.cooldownBuckets)&&void 0!==c?c:0));if(!("high_or_low"!==g||f>0||y>0||v>0||w>1||x>0||E>1||k>0||!0===t.dataQualityGate))return h.map(e=>T(D({},e),{score:V(e.score),pointScore:V(e.pointScore),windowScore:V(e.windowScore),decisionState:e.isAnomaly?"open":null===e.expected?"warming_up":"normal"}));const F=(e,a)=>{var i;const n=null===e.expected?0:e.value-e.expected,r="high_or_low"===g||"high_mean"===g&&n>0||"low_mean"===g&&n<0,s=Math.abs(n),o=null===e.expected?0:s/Math.max(Math.abs(e.expected),1e-9),l=!0!==t.dataQualityGate||"healthy"===e.dataQualityLabel;return e.score>=a&&r&&s>=f&&o>=y&&Math.max(Math.abs(e.value),Math.abs(null!==(i=e.expected)&&void 0!==i?i:0))>=v&&l},M=h.map(e=>F(e,u)),N=x>0?x:u,A=h.map(e=>F(e,N)),L=[];let B=!1,P=0,_=0;return h.map((e,t)=>{const a=T(D({},e),{score:V(e.score),pointScore:V(e.pointScore),windowScore:V(e.windowScore)}),i=M[t],n=A[t];if(L.push(i),L.length>b&&L.shift(),B){if(n)return P=0,T(D({},a),{isAnomaly:!0,decisionState:"open"});if(P+=1,P<E)return T(D({},a),{isAnomaly:!0,decisionState:"recovering"});B=!1,P=0,_=k}return _>0?(_-=1,T(D({},a),{isAnomaly:!1,severityScore:0,severityLabel:"normal",decisionState:"cooldown"})):i&&L.filter(Boolean).length>=w?(B=!0,T(D({},a),{isAnomaly:!0,decisionState:"open"})):T(D({},a),{isAnomaly:!1,severityScore:0,severityLabel:"normal",decisionState:i?"candidate":null===e.expected?"warming_up":"normal"})})};function Z(e,t,a,i,n,r,s){try{var o=e[r](s),l=o.value}catch(e){return void a(e)}o.done?t(l):Promise.resolve(l).then(i,n)}function X(e){return function(){var t=this,a=arguments;return new Promise(function(i,n){var r=e.apply(t,a);function s(e){Z(r,i,n,s,o,"next",e)}function o(e){Z(r,i,n,s,o,"throw",e)}s(void 0)})}}function ee(e,t,a){return t in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function te(e){for(var t=1;t<arguments.length;t++){var a=null!=arguments[t]?arguments[t]:{},i=Object.keys(a);"function"==typeof Object.getOwnPropertySymbols&&(i=i.concat(Object.getOwnPropertySymbols(a).filter(function(e){return Object.getOwnPropertyDescriptor(a,e).enumerable}))),i.forEach(function(t){ee(e,t,a[t])})}return e}function ae(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);t&&(i=i.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),a.push.apply(a,i)}return a}(Object(t)).forEach(function(a){Object.defineProperty(e,a,Object.getOwnPropertyDescriptor(t,a))}),e}const ie=["#7EB26D","#EAB839","#6ED0E0","#EF843C","#E24D42","#1F78C1"],ne=720,re={top:18,right:20,bottom:42,left:64},se={"1m":6e4,"5m":3e5,"15m":9e5,"1h":36e5},oe=Object.values(se).sort((e,t)=>e-t),le={recommended:"Recommended",advanced:"Advanced"},ce={harmonic:"Harmonic (known cycle)",zscore:"Rolling z-score",mad:"Rolling MAD",ewma:"EWMA baseline",seasonal:"Seasonal baseline",level_shift:"Level shift detector"},de={auto:"Auto",custom:"Custom",traffic:"Traffic / throughput",latency:"Latency / duration",error_rate:"Error rate",resource:"Resource usage",business:"Business KPI",level_shift:"Subtle level shift"},me={auto:"Auto",raw:"Raw samples","1m":"1 minute","5m":"5 minutes","15m":"15 minutes","1h":"1 hour"},ue={traffic:{algorithm:"ewma",anomalyDirection:"high_or_low",sensitivity:4.5,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"warning_first",badge:"Stable default",why:"Traffic and throughput metrics drift with load, so EWMA is usually the safest default for live dashboards."},latency:{algorithm:"mad",anomalyDirection:"high_mean",sensitivity:4,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Noisy data",why:"Latency metrics are often spiky and outlier-heavy, so MAD is more robust than a mean-based baseline."},error_rate:{algorithm:"mad",anomalyDirection:"high_mean",sensitivity:4.5,baselineWindow:12,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"page_first",badge:"Burst errors",why:"Error metrics often stay low and then jump sharply, so MAD isolates bursts without letting them poison the baseline."},resource:{algorithm:"ewma",anomalyDirection:"high_mean",sensitivity:4.5,baselineWindow:24,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Drifting baseline",why:"CPU, memory, and load metrics usually move gradually, so EWMA follows the baseline smoothly without overreacting."},business:{algorithm:"seasonal",anomalyDirection:"high_or_low",sensitivity:4,baselineWindow:8,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Seasonal data",why:"Business KPIs often repeat by hour or weekday, so seasonal matching reduces false positives on recurring patterns."},level_shift:{algorithm:"level_shift",anomalyDirection:"high_or_low",sensitivity:5,baselineWindow:30,seasonalitySamples:24,seasonalRefinement:"cycle",severityPreset:"balanced",badge:"Sustained change",why:"When the baseline shifts gradually or steps into a new level, a level-shift detector is better than a pure spike detector."}},pe=["latency","error_rate","level_shift","resource","business","traffic"],he=[/(^|[^a-z0-9])(up|healthy|health|availability|uptime)([^a-z0-9]|$)/i,/success[_\s-]?(rate|ratio|percent|percentage)/i,/(free|available|remaining)[_\s-]?(capacity|space|slots?|connections?|bytes?)/i,/(capacity|space|slots?|connections?|bytes?)[_\s-]?(free|available|remaining)/i,/headroom/i],ge=e=>e.map(e=>e.trim()).filter(Boolean).some(e=>he.some(t=>t.test(e)))?"low_mean":null,fe=[{preset:"latency",patterns:[/latency/i,/duration/i,/response/i,/p95/i,/p99/i,/p90/i,/quantile/i,/delay/i,/ms/i,/seconds?/i]},{preset:"error_rate",patterns:[/error/i,/errors/i,/failure/i,/fail/i,/exception/i,/timeout/i,/reject/i,/5xx/i,/4xx/i]},{preset:"resource",patterns:[/cpu/i,/memory/i,/load/i,/utili/i,/usage/i,/heap/i,/rss/i,/disk/i,/iops/i,/saturation/i,/throttle/i]},{preset:"level_shift",patterns:[/queue/i,/backlog/i,/pending/i,/session/i,/connection/i,/thread/i,/pool/i,/worker/i,/lag/i,/offset/i,/buffer/i,/inflight/i,/active/i]},{preset:"business",patterns:[/revenue/i,/order/i,/orders/i,/signup/i,/conversion/i,/checkout/i,/cart/i,/booking/i,/payment/i,/sales/i,/gmv/i]},{preset:"traffic",patterns:[/request/i,/requests/i,/throughput/i,/traffic/i,/volume/i,/events?/i,/rps/i,/qps/i,/ops/i,/hits?/i,/ingress/i,/egress/i,/count/i]}],ye={cycle:"Cycle only",hour_of_day:"Hour of day",weekday_hour:"Weekday + hour"},ve={balanced:"Balanced",warning_first:"Warning first",page_first:"Page first"},be={normal:"Normal",low:"Low",medium:"Medium",high:"High",critical:"Critical"},we={normal:"#94A3B8",low:"#EAB308",medium:"#F59E0B",high:"#F97316",critical:"#DC2626"},xe={low:"Low confidence",medium:"Medium confidence",high:"High confidence"},Ee={low:"#F59E0B",medium:"#2563EB",high:"#16A34A"},ke={healthy:"Healthy data",thin:"Thin history",flatline:"Flatline risk",gappy:"Gappy sampling"},Se=e=>{if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){const t=Number(e);return Number.isFinite(t)?t:null}return null},Fe=(e,t)=>{if(e)return"function"==typeof e.get?e.get(t):e[t]},Me=e=>{const t=[...e].sort((e,t)=>e-t),a=Math.floor(t.length/2);return t.length%2==0?(t[a-1]+t[a])/2:t[a]},$e=e=>{if(null===e||!Number.isFinite(e))return"n/a";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})},Ne=e=>null!==e&&Number.isFinite(e)?Math.round(e).toLocaleString(void 0,{maximumFractionDigits:0}):"n/a",Ce=e=>null!==e&&Number.isFinite(e)?`${e.toLocaleString(void 0,{maximumFractionDigits:1})}%`:"n/a",Ae=e=>new Date(e).toLocaleString(void 0,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),Le=(e,t)=>t<=e?Ae(e):`${Ae(e)} - ${Ae(t)}`,Be=(e,t=26)=>e.length<=t?e:`${e.slice(0,Math.max(1,t-1)).trimEnd()}…`,De=(e,t)=>"auto"!==e?e:t<=216e5?"dense":t<=1296e5?"balanced":"compact",Te=(e,t)=>{const a=De(t,e);return e<=432e5||"dense"===a?"HH:mm":e<=2592e5?"DD/MM HH:mm":"DD/MM"},Pe=(e,t,a,i)=>(0,c.dateTimeFormat)(e,{format:Te(t,a),timeZone:i}),_e=(e,t,a)=>(0,c.dateTimeFormat)(e,{format:t<=2592e5?"DD/MM HH:mm":"DD/MM/YYYY HH:mm",timeZone:a}),Re=(e,t)=>{if("classic"===t)return"circle";switch(e){case"medium":return"diamond";case"high":return"triangle";case"critical":return"square";default:return"circle"}},Ie=(e,t,a,i)=>"diamond"===e?`M ${t} ${a-i} L ${t+i} ${a} L ${t} ${a+i} L ${t-i} ${a} Z`:`M ${t} ${a-i} L ${t+.92*i} ${a+.9*i} L ${t-.92*i} ${a+.9*i} Z`,Ve=(e,t,a,i,n,r,s=0,o)=>"circle"===e?g().createElement("circle",{cx:t,cy:a,r:i,fill:n,stroke:r,strokeWidth:s,opacity:o}):"square"===e?g().createElement("rect",{x:t-i,y:a-i,width:2*i,height:2*i,rx:Math.max(1.5,.32*i),fill:n,stroke:r,strokeWidth:s,opacity:o}):g().createElement("path",{d:Ie(e,t,a,i),fill:n,stroke:r,strokeWidth:s,opacity:o}),qe=(e,t)=>{var a,i;if("advanced"===e.setupMode||"custom"===e.effectiveMetricPreset)return{source:"manual",badge:"Manual tuning",title:"Advanced controls are active",reason:`Algorithm ${ce[e.algorithm]} with ${ve[e.severityPreset]} severity mapping is applied directly.`,matchedNames:[],confidence:"matched"};const n=ue[e.effectiveMetricPreset],r="auto"===e.metricPreset?"auto":"selected",s="auto"===r?`Auto selected ${de[e.effectiveMetricPreset]}`:`${de[e.effectiveMetricPreset]} preset is active`;return{source:r,badge:n.badge,title:s,reason:n.why,matchedNames:null!==(a=null==t?void 0:t.matchedNames)&&void 0!==a?a:[],confidence:null!==(i=null==t?void 0:t.confidence)&&void 0!==i?i:"matched"}},Oe=(e,t)=>{var a,i,n,r,s,o,l;const c=null!==(a=e.setupMode)&&void 0!==a?a:"recommended",m=null!==(i=e.metricPreset)&&void 0!==i?i:"auto",u=Math.max(3,Math.min(20,Math.round(null!==(n=e.maxAnomalies)&&void 0!==n?n:8))),p=e.bucketSpan||"auto";if("advanced"===c||"custom"===m){var h,g,f,y,v,b,w,x,E,k,S,F,M,$,N,C,A,L,B,D,T;const t={setupMode:c,metricPreset:m,effectiveMetricPreset:"custom",detectionMode:null!==(h=e.detectionMode)&&void 0!==h?h:"single",algorithm:null!==(g=e.algorithm)&&void 0!==g?g:"zscore",anomalyDirection:d(e.anomalyDirection).direction,minimumAbsoluteDeviation:Math.max(0,null!==(f=e.minimumAbsoluteDeviation)&&void 0!==f?f:0),minimumRelativeDeviation:Math.max(0,null!==(y=e.minimumRelativeDeviation)&&void 0!==y?y:0),minimumActivity:Math.max(0,null!==(v=e.minimumActivity)&&void 0!==v?v:0),persistenceBuckets:Math.min(Math.max(1,Math.round(null!==(b=e.persistenceBuckets)&&void 0!==b?b:3)),Math.max(1,Math.round(null!==(w=e.persistenceWindow)&&void 0!==w?w:4))),persistenceWindow:Math.max(1,Math.round(null!==(x=e.persistenceWindow)&&void 0!==x?x:4)),recoveryThreshold:Math.min(Math.max(0,null!==(E=e.recoveryThreshold)&&void 0!==E?E:3),Math.max(.2,null!==(k=e.sensitivity)&&void 0!==k?k:4)),recoveryBuckets:Math.max(1,Math.round(null!==(S=e.recoveryBuckets)&&void 0!==S?S:2)),cooldownBuckets:Math.max(0,Math.round(null!==(F=e.cooldownBuckets)&&void 0!==F?F:2)),dataQualityGate:!1!==e.dataQualityGate,sensitivity:Math.max(.2,null!==(M=e.sensitivity)&&void 0!==M?M:4),baselineWindow:Math.max(3,Math.round(null!==($=e.baselineWindow)&&void 0!==$?$:12)),seasonalitySamples:"harmonic"===e.algorithm?Math.min(4096,Math.max(8,Math.round(null!==(N=e.seasonalitySamples)&&void 0!==N?N:24))):Math.max(2,Math.round(null!==(C=e.seasonalitySamples)&&void 0!==C?C:24)),seasonalRefinement:null!==(A=e.seasonalRefinement)&&void 0!==A?A:"cycle",severityPreset:null!==(L=e.severityPreset)&&void 0!==L?L:"balanced",bucketSpan:p,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(B=e.timeAxisDensity)&&void 0!==B?B:"auto",timeAxisPlacement:null!==(D=e.timeAxisPlacement)&&void 0!==D?D:"top_and_bottom",markerShapeMode:null!==(T=e.markerShapeMode)&&void 0!==T?T:"severity",maxAnomalies:u};return ae(te({},t),{recommendation:qe(t,null)})}const P="auto"===m?(e=>{const t=new Map;for(const i of e)for(const e of fe)if(e.patterns.some(e=>e.test(i))){var a;const n=null!==(a=t.get(e.preset))&&void 0!==a?a:[];n.push(i),t.set(e.preset,n)}for(const e of pe){var i;const a=null!==(i=t.get(e))&&void 0!==i?i:[];if(a.length>0)return{preset:e,matchedNames:a,confidence:a.length>=2?"matched":"weak"}}return{preset:"traffic",matchedNames:[],confidence:"fallback"}})(t):null,_="auto"===m?null==P?void 0:P.preset:m,R=ue[_],I="auto"===m?ge(t):null,V={setupMode:c,metricPreset:m,effectiveMetricPreset:_,detectionMode:null!==(r=e.detectionMode)&&void 0!==r?r:"single",algorithm:R.algorithm,anomalyDirection:null!=I?I:R.anomalyDirection,minimumAbsoluteDeviation:0,minimumRelativeDeviation:0,minimumActivity:0,persistenceBuckets:3,persistenceWindow:4,recoveryThreshold:Math.max(.2,.75*R.sensitivity),recoveryBuckets:2,cooldownBuckets:2,dataQualityGate:!0,sensitivity:R.sensitivity,baselineWindow:R.baselineWindow,seasonalitySamples:R.seasonalitySamples,seasonalRefinement:R.seasonalRefinement,severityPreset:R.severityPreset,bucketSpan:p,showExpectedLine:!1!==e.showExpectedLine,showInlineSeriesLabels:!1!==e.showInlineSeriesLabels,showFocusBand:!0===e.showFocusBand,timeAxisDensity:null!==(s=e.timeAxisDensity)&&void 0!==s?s:"auto",timeAxisPlacement:null!==(o=e.timeAxisPlacement)&&void 0!==o?o:"top_and_bottom",markerShapeMode:null!==(l=e.markerShapeMode)&&void 0!==l?l:"severity",maxAnomalies:u};return ae(te({},V),{recommendation:qe(V,P)})},ze=e=>e?"point"===e.kind?`point:${e.seriesKey}:${e.time}`:`event:${e.time}`:"none",We=e=>["normal","low","medium","high","critical"].indexOf(e),je=(e,t)=>We(t.severityLabel)>We(e.severityLabel)||We(t.severityLabel)===We(e.severityLabel)&&t.severityScore>e.severityScore?t:e,He=(e,t)=>"level_shift"===t?"window"===e?"Sustained baseline shift":"Fresh step change":"seasonal"===t||"harmonic"===t?"Seasonal pattern break":"window"===e?"ewma"===t?"Short sustained drift":"Sustained deviation":"Sharp point deviation",Ue=(e,t)=>{const a="warning_first"===t?"Warning-first preset surfaces operator-visible severity earlier.":"page_first"===t?"Page-first preset keeps high and critical stricter for paging workflows.":"Balanced preset aims to work for both dashboards and alert handoff.",i="low"===e.confidenceLabel?" Confidence is still low, so verify with nearby metrics before paging.":"thin"===e.dataQualityLabel?" History is still thin, so treat this as early signal rather than hard evidence.":"flatline"===e.dataQualityLabel?" The series looks nearly flat, so verify the metric is still reporting healthy samples.":"gappy"===e.dataQualityLabel?" Recent samples are gappy, so confirm the data source timing before escalating.":"";return"critical"===e.severityLabel||"high"===e.severityLabel?`${a} This anomaly is already in the investigate-now range.${i}`:"medium"===e.severityLabel?`${a} This anomaly looks strong enough for triage or warning workflows.${i}`:`${a} This anomaly is currently better suited to watchlists or dashboard review.${i}`},Qe=e=>{const t=[];for(const a of e){const e=t[t.length-1];if(e&&e.time===a.time){const t=e.sampleCount+a.sampleCount;e.value=(e.value*e.sampleCount+a.value*a.sampleCount)/t,e.sampleCount=t,e.minValue=Math.min(e.minValue,a.minValue),e.maxValue=Math.max(e.maxValue,a.maxValue),e.bucketStart=Math.min(e.bucketStart,a.bucketStart),e.bucketEnd=Math.max(e.bucketEnd,a.bucketEnd);continue}t.push(te({},a))}return t},Ge=(e,t)=>{if("raw"===t)return null;if("auto"!==t)return se[t];const a=e.map(e=>e.rawPoints.length).filter(e=>e>0);if(0===a.length)return null;const i=Math.max(...a),n=e.flatMap(e=>e.rawPoints.map(e=>e.time)),r=Math.min(...n),s=Math.max(...n),o=Math.max(s-r,0),l=e.map(e=>(e=>{if(e.length<2)return null;const t=[];for(let a=1;a<e.length&&t.length<120;a+=1){const i=e[a].time-e[a-1].time;i>0&&t.push(i)}return t.length>0?Me(t):null})(e.rawPoints)).filter(e=>null!==e),c=l.length>0?Me(l):null;if(i<=640||o<=0)return null;const d=Math.ceil(o/640),m=c?Math.max(1.5*c,d):d,u=oe.find(e=>e>=m);return null!=u?u:oe[oe.length-1]},Ye=(e,t)=>({time:e,value:t,bucketStart:e,bucketEnd:e,sampleCount:1,minValue:t,maxValue:t}),Ke=e=>"string"!=typeof e?null:e.trim().length>0?e:null,Je=(e,t,a="Series")=>{var i,n,r,s,o,l,c,d;return null!==(i=null!==(n=null!==(r=null!==(s=null!==(o=Ke(null===(l=e.config)||void 0===l?void 0:l.displayNameFromDS))&&void 0!==o?o:Ke(null===(c=e.config)||void 0===c?void 0:c.displayName))&&void 0!==s?s:Ke(null===(d=e.state)||void 0===d?void 0:d.displayName))&&void 0!==r?r:Ke(e.name))&&void 0!==n?n:Ke(t))&&void 0!==i?i:a},Ze=e=>{var t,a,i,n,r;return Boolean(null!==(t=null!==(a=Ke(null===(i=e.config)||void 0===i?void 0:i.displayNameFromDS))&&void 0!==a?a:Ke(null===(n=e.config)||void 0===n?void 0:n.displayName))&&void 0!==t?t:Ke(null===(r=e.state)||void 0===r?void 0:r.displayName))},Xe=e=>{const t=!1!==e.showSummary;return{initialLabels:!1!==e.showInitialLabels,statistics:!1!==e.showStatistics,mainChart:!1!==e.showMainChart,inspector:!1!==e.showInspector,anomalyFeed:t&&!1!==e.showAnomalyFeed,seriesSummary:!1!==e.showSeriesSummary,scoreFeed:!1!==e.showScoreFeed,detectionProfile:t&&!1!==e.showDetectionProfile,exports:t&&!1!==e.showExports}},et=e=>{const t=[];e.forEach((e,a)=>{const i=e.fields.find(e=>e.type===c.FieldType.time);if(!i)return;e.fields.filter(e=>e.type===c.FieldType.number).forEach((n,r)=>{var s,o,l,c,d;const m=[],u=Math.min(null!==(s=i.values.length)&&void 0!==s?s:0,null!==(o=n.values.length)&&void 0!==o?o:0);for(let e=0;e<u;e+=1){const t=Se(Fe(i.values,e)),a=Se(Fe(n.values,e));null!==t&&null!==a&&m.push(Ye(t,a))}if(0===m.length)return;m.sort((e,t)=>e.time-t.time);const p=Je(n,e.name,`Series ${t.length+1}`),h=null===(d=n.config.color)||void 0===d?void 0:d.fixedColor;t.push({key:`${null!==(l=e.name)&&void 0!==l?l:a}-${null!==(c=n.name)&&void 0!==c?c:r}-${a}-${r}`,label:p,preservesGrafanaDisplayName:Ze(n),color:h||ie[t.length%ie.length],rawPoints:Qe(m)})})});const a=new Map;t.forEach(e=>{var t;a.set(e.label,(null!==(t=a.get(e.label))&&void 0!==t?t:0)+1)});const i=new Map;return t.map(e=>{var t,n;if((null!==(t=a.get(e.label))&&void 0!==t?t:1)<=1||e.preservesGrafanaDisplayName)return e;const r=(null!==(n=i.get(e.label))&&void 0!==n?n:0)+1;return i.set(e.label,r),ae(te({},e),{label:`${e.label} (${r})`})})},tt=(e,t)=>{const a=Ge(e,t.bucketSpan),i=e.map(e=>{const i=((e,t)=>{if(!t||0===e.length)return Qe(e.map(e=>te({},e)));const a=new Map;for(const n of e){var i;const e=Math.floor(n.time/t)*t,r=null!==(i=a.get(e))&&void 0!==i?i:{sum:0,count:0,min:Number.POSITIVE_INFINITY,max:Number.NEGATIVE_INFINITY,end:e+t};r.sum+=n.value,r.count+=n.sampleCount,r.min=Math.min(r.min,n.minValue),r.max=Math.max(r.max,n.maxValue),a.set(e,r)}return[...a.entries()].sort((e,t)=>e[0]-t[0]).map(([e,a])=>({time:e+Math.round(t/2),value:a.sum/a.count,bucketStart:e,bucketEnd:a.end,sampleCount:a.count,minValue:a.min,maxValue:a.max}))})(e.rawPoints,a),n=((e,t)=>J(e,{algorithm:t.algorithm,anomalyDirection:t.anomalyDirection,minimumAbsoluteDeviation:t.minimumAbsoluteDeviation,minimumRelativeDeviation:t.minimumRelativeDeviation,minimumActivity:t.minimumActivity,persistenceBuckets:Math.min(t.persistenceBuckets,t.persistenceWindow),persistenceWindow:t.persistenceWindow,recoveryThreshold:t.recoveryThreshold,recoveryBuckets:t.recoveryBuckets,cooldownBuckets:t.cooldownBuckets,dataQualityGate:t.dataQualityGate,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}))(i,t),r=(e=>{if(e.length<=ne)return e;const t=new Set,a=(e.length-1)/719;for(let e=0;e<ne;e+=1)t.add(Math.round(e*a));return e.forEach((e,a)=>{e.isAnomaly&&t.add(a)}),[...t].sort((e,t)=>e-t).slice(0,ne+Math.min(60,e.filter(e=>e.isAnomaly).length)).map(t=>e[t])})(n),s=n.filter(e=>e.isAnomaly),o=s.reduce((e,t)=>je(e,t),{severityLabel:"normal",severityScore:0});return{key:e.key,label:e.label,color:e.color,points:r,allPoints:n,anomalyCount:s.length,maxScore:s.reduce((e,t)=>Math.max(e,t.score),0),maxSeverityScore:o.severityScore,maxSeverityLabel:o.severityLabel,sourcePointCount:e.rawPoints.length,aggregatedPointCount:i.length,processedPointCount:n.length}});return{analyses:i,effectiveBucketSpanMs:a}},at=(e,t)=>"raw"===e?me.raw:"auto"!==e?me[e]:t?`Auto -> ${(e=>{const t=Math.round(e/6e4);if(t<60)return`${t}m`;const a=Math.round(e/36e5*10)/10;return a<24?`${a}h`:Math.round(e/864e5*10)/10+"d"})(t)}`:"Auto -> raw",it=(e,t,a,i)=>{let n="";return e.forEach(e=>{const r=i(e);if(null===r||!Number.isFinite(r))return;const s=0===n.length?"M":"L";n+=`${s}${t(e.time).toFixed(2)},${a(r).toFixed(2)} `}),n.trim()},nt=(e,t,a)=>Number.isFinite(e)&&Number.isFinite(t)?a<=1||t===e?[e]:Array.from({length:a},(i,n)=>e+(t-e)*n/(a-1)):[],rt=(e,t,a,i=null)=>{if(e.length<=1)return e;const n=[];let r=[],s=Number.NEGATIVE_INFINITY;const o=()=>{if(0===r.length)return;let e=r[0];for(const t of r){if(null!==i&&t.time===i){e=t;break}t.score>e.score&&(e=t)}n.push(e),r=[]};for(const i of e){const e=t(i.time);0!==r.length?e-s<a?r.push(i):(o(),r=[i],s=e):(r=[i],s=e)}if(o(),null!==i&&!n.some(e=>e.time===i)){const t=e.find(e=>e.time===i);t&&(n.push(t),n.sort((e,t)=>e.time-t.time))}return n},st=(e,t)=>{if(0===e.length)return-1;let a=0,i=Math.abs(e[0]-t);for(let n=1;n<e.length;n+=1){const r=Math.abs(e[n]-t);r<i&&(i=r,a=n)}return a},ot=(e,t,a=null)=>{var i;if(e.length<=t)return e;const n=null!==a&&null!==(i=e.find(e=>e.time===a))&&void 0!==i?i:null,r=[...e].sort((e,t)=>t.score-e.score||e.time-t.time),s=[];n&&s.push(n);for(const e of r){if(s.length>=t)break;s.some(t=>t.time===e.time)||s.push(e)}return s.sort((e,t)=>e.time-t.time)},lt=(e,t,a)=>"multi"===a.detectionMode?t.filter(e=>e.isAnomaly).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies).map((e,t)=>({key:`event-${e.time}-${t}`,time:e.time,title:`Cross-metric incident at ${Ae(e.time)}`,subtitle:`${e.activeSeries} metric${1===e.activeSeries?"":"s"} aligned${e.contributors.length>0?` | ${e.contributors.join(", ")}`:""}`,detail:`${be[e.severityLabel]} ${e.severityScore} | ${xe[e.confidenceLabel]} | ${ke[e.dataQualityLabel]}`,score:e.score,severityLabel:e.severityLabel,severityScore:e.severityScore,confidenceScore:e.confidenceScore,confidenceLabel:e.confidenceLabel,dataQualityLabel:e.dataQualityLabel,selection:{kind:"event",time:e.time}})):e.flatMap(e=>(e=>{const t=e.filter(e=>e.isAnomaly).sort((e,t)=>e.time-t.time);if(0===t.length)return[];const a=[];let i=[t[0]];for(let e=1;e<t.length;e+=1){const n=i[i.length-1],r=t[e],s=Math.max(n.bucketEnd-n.bucketStart,1),o=Math.max(r.bucketEnd-r.bucketStart,1),l=1.25*Math.max(s,o);r.bucketStart<=n.bucketEnd+l?i.push(r):(a.push(i),i=[r])}return a.push(i),a})(e.allPoints).map((t,i)=>{const n=t.reduce((e,t)=>t.score>e.score?t:e),r=t[0].bucketStart,s=t[t.length-1].bucketEnd;return{key:`${e.key}-${n.time}-${i}`,time:n.time,title:(o=e.label,l=a.algorithm,c=n.scoreDriver,`${He(c,l)} in ${o}`),subtitle:t.length>1?`${t.length} consecutive buckets | ${Le(r,s)}`:Le(r,s),detail:`${be[n.severityLabel]} ${n.severityScore} | ${xe[n.confidenceLabel]} | Current ${$e(n.value)} vs expected ${$e(n.expected)}`,score:n.score,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel,selection:{kind:"point",seriesKey:e.key,time:n.time}};var o,l,c})).sort((e,t)=>t.score-e.score).slice(0,a.maxAnomalies),ct=(e,t,a)=>{if(!e)return null;if("point"===e.kind){const a=((e,t)=>{var a;const i=null!==(a=t.find(t=>t.key===e.seriesKey))&&void 0!==a?a:null,n=i?[i,...t.filter(e=>e.key!==i.key)]:t;for(const t of n){const a=t.allPoints.find(t=>t.time===e.time);if(a)return{analysis:t,point:a}}let r=null,s=null;for(const t of n)for(const a of t.allPoints){const i=Math.max(a.bucketEnd-a.bucketStart,1),n=Math.abs(a.time-e.time);a.isAnomaly&&(!s||n<s.distance)&&(s={analysis:t,point:a,distance:n}),n<=1.5*i&&(!r||n<r.distance)&&(r={analysis:t,point:a,distance:n})}const o=null!=r?r:s;return o?{analysis:o.analysis,point:o.point}:null})(e,t);if(!a)return null;const{analysis:i,point:n}=a,r=null===n.expected?null:n.value-n.expected,s=n.expected&&Math.abs(n.expected)>1e-9?r/n.expected*100:null;return{kind:"point",title:`${"window"===n.scoreDriver?"Sustained change":"Sharp change"} in ${i.label}`,subtitle:Le(n.bucketStart,n.bucketEnd),seriesKey:i.key,seriesLabel:i.label,color:i.color,time:n.time,bucketStart:n.bucketStart,bucketEnd:n.bucketEnd,actual:n.value,expected:n.expected,deviation:r,deviationPercent:s,rangeLower:n.lower,rangeUpper:n.upper,sampleCount:n.sampleCount,minValue:n.minValue,maxValue:n.maxValue,score:n.score,pointScore:n.pointScore,windowScore:n.windowScore,scoreDriver:n.scoreDriver,severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}}const i=a.find(t=>t.time===e.time);if(!i)return null;const n=t.map(e=>{const t=e.allPoints.find(e=>e.time===i.time);return t?{label:e.label,color:e.color,actual:t.value,expected:t.expected,deviation:null===t.expected?null:t.value-t.expected,rangeLower:t.lower,rangeUpper:t.upper,score:t.score,pointScore:t.pointScore,windowScore:t.windowScore,scoreDriver:t.scoreDriver,severityLabel:t.severityLabel,severityScore:t.severityScore,confidenceScore:t.confidenceScore,confidenceLabel:t.confidenceLabel,dataQualityLabel:t.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);return{kind:"event",title:`Cross-metric incident at ${Ae(i.time)}`,subtitle:Le(i.bucketStart,i.bucketEnd),time:i.time,bucketStart:i.bucketStart,bucketEnd:i.bucketEnd,score:i.score,activeSeries:i.activeSeries,contributors:i.contributors,breakdown:n,severityLabel:i.severityLabel,severityScore:i.severityScore,confidenceScore:i.confidenceScore,confidenceLabel:i.confidenceLabel,dataQualityLabel:i.dataQualityLabel}},dt=e=>{const t=new Set;return e.map(e=>(null!=e?e:"").trim()).filter(e=>!(!e||t.has(e))&&(t.add(e),!0))},mt=e=>{switch(e){case"warning_first":return 60;case"page_first":return 75;default:return 70}},ut=e=>Object.entries(e).filter(([,e])=>e.length>0).map(([e,t])=>`${e}=${t}`).join("\n"),pt=(e,t,a)=>{const i=e.document.querySelector(t);if(!i)return!1;const n=i.tagName.toLowerCase();if("input"!==n&&"textarea"!==n)return!1;return i.value=a,i.dispatchEvent(new Event("input",{bubbles:!0})),i.dispatchEvent(new Event("change",{bubbles:!0})),!0},ht=e=>{if("undefined"==typeof window)return!1;const t=new URL("/alerting/new",window.location.origin),a=new URLSearchParams(window.location.search).get("orgId");a&&t.searchParams.set("orgId",a),e.dashboardUid&&t.searchParams.set("dashboardUid",e.dashboardUid),e.panelId>0&&t.searchParams.set("panelId",String(e.panelId)),t.searchParams.set("title",e.ruleName),t.searchParams.set("ruleName",e.ruleName),e.folderTitle&&t.searchParams.set("folderTitle",e.folderTitle),t.searchParams.set("dashboardTitle",e.dashboardTitle),t.searchParams.set("panelTitle",e.panelTitle),t.searchParams.set("queryLanguage",e.queryLanguage),t.searchParams.set("threshold",String(e.threshold)),t.searchParams.set("for","10m"),t.searchParams.set("evaluateEvery","3m"),t.searchParams.set("labels",ut(e.labels)),Object.entries(e.labels).forEach(([e,a])=>{a&&t.searchParams.set(`label_${e}`,a)}),e.alertQuery&&e.alertQuery.length<=1400&&t.searchParams.set("query",e.alertQuery),t.searchParams.set("returnTo",`${window.location.pathname}${window.location.search}`);try{window.sessionStorage.setItem("grafana-anomaly-alert-draft",JSON.stringify(e))}catch(e){}const i=window.open(t.toString(),"_blank");return!!i&&(((e,t)=>{let a=0;const i=()=>{a+=1;try{var n,r;const i=e.document;if(!i||e.closed)return;if(pt(e,'[data-testid="data-testid alert-rule name-field"], input[name="name"], input[placeholder="Give your alert rule a name"]',t.ruleName),pt(e,'input[type="number"]',String(t.threshold)),pt(e,'[data-testid="annotation-value-0"], textarea[name="annotations.0.value"]',null!==(n=t.annotations.summary)&&void 0!==n?n:t.ruleName),pt(e,'[data-testid="annotation-value-1"], textarea[name="annotations.1.value"]',null!==(r=t.annotations.description)&&void 0!==r?r:""),"promql"===t.queryLanguage.toLowerCase()){const n=i.querySelector('input[id^="option-code-radiogroup"]');n&&a<=2&&"function"==typeof n.click&&n.click();const r=['textarea[placeholder*="PromQL"]','textarea[aria-label*="Query"]','textarea[aria-label*="Editor content"]','input[placeholder*="PromQL"]','input[aria-label*="Query"]','textarea[name*="expr"]','input[name*="expr"]'].join(",");pt(e,r,t.alertQuery)}}catch(e){}a<18&&!e.closed&&e.setTimeout(i,450)};e.setTimeout(i,450)})(i,e),!0)},gt=e=>{var t,a;const i=(null!==(t=e.queryLanguage)&&void 0!==t?t:"").toLowerCase(),n=(null!==(a=e.target)&&void 0!==a?a:"").toLowerCase();return"promql"===i||"prometheus"===n||!i&&e.query.includes("grafana_anomaly_rule_score")},ft=e=>{if(0===e.length)return"";if(1===e.length)return e[0].query;if(!e.every(gt))return e.map(e=>e.query).join("\n\n");return`max(max_over_time(grafana_anomaly_rule_score{rule=~"${e.map(e=>e.rule.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join("|")}"}[5m]))`},yt=e=>{if(0===e.length)return"query";const t=Array.from(new Set(e.map(e=>e.queryLanguage).filter(e=>Boolean(e))));return 1===t.length?t[0]:e.every(gt)?"PromQL":"target-specific query"},vt=["prometheus","loki","influxdb","postgresql","clickhouse","elasticsearch"],bt=e=>{const t=String(null!=e?e:"").toLowerCase();return vt.includes(t)?t:"prometheus"},wt=e=>{const t=bt(e.target);return`${Ct[t]}${e.queryLanguage?` (${e.queryLanguage})`:""}`},xt=(e,t)=>e?"point"===e.kind?`${e.title}. Raw detection score ${$e(e.score)}; alert score ${e.severityScore}/100 (${be[e.severityLabel]}). Current ${$e(e.actual)} vs expected ${$e(e.expected)}.`:`${e.title}. Raw detection score ${$e(e.score)} across ${e.activeSeries} active series; alert score ${e.severityScore}/100 (${be[e.severityLabel]}): ${e.contributors.slice(0,4).join(", ")}.`:`Anomaly score alert for ${t}.`,Et=e=>e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")||"metric",kt=(e,t,a,i)=>{if(!e)return null;const n=dt(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,Et(i),e.kind]),r={time:e.bucketStart,tags:n,text:""};if(a&&(r.dashboardUID=a,r.dashboardUid=a),t>0&&(r.panelId=t),e.bucketEnd>e.bucketStart&&(r.timeEnd=e.bucketEnd,r.isRegion=!0),"point"===e.kind){const t=Et(e.seriesLabel);return n.includes(t)||n.push(t),r.text=[e.title,`Window: ${Le(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${$e(e.score)}`,`Alert score (0-100): ${be[e.severityLabel]} ${e.severityScore}`,`Confidence: ${xe[e.confidenceLabel]} (${$e(e.confidenceScore)})`,`Data quality: ${ke[e.dataQualityLabel]}`,`Actual: ${$e(e.actual)} | Expected: ${$e(e.expected)}`,`Deviation: ${$e(e.deviation)}${null===e.deviationPercent?"":` (${$e(e.deviationPercent)}%)`}`,`Expected range: ${$e(e.rangeLower)} to ${$e(e.rangeUpper)}`].join("\n"),r}return r.text=[e.title,`Window: ${Le(e.bucketStart,e.bucketEnd)}`,`Raw detection score: ${$e(e.score)}`,`Alert score (0-100): ${be[e.severityLabel]} ${e.severityScore}`,`Confidence: ${xe[e.confidenceLabel]} (${$e(e.confidenceScore)})`,`Data quality: ${ke[e.dataQualityLabel]}`,`Active series: ${e.activeSeries}`,`Top contributors: ${e.contributors.join(", ")||"No contributors found"}`].join("\n"),r},St=e=>X(function*(){var t;if("undefined"!=typeof navigator&&(null===(t=navigator.clipboard)||void 0===t?void 0:t.writeText))try{return void(yield Promise.race([navigator.clipboard.writeText(e),new Promise((e,t)=>{("undefined"!=typeof window?window.setTimeout:setTimeout)(()=>t(new Error("Clipboard API timed out.")),900)})]))}catch(e){}if("undefined"==typeof document)throw new Error("Clipboard access is not available in this environment.");const a=document.createElement("textarea");a.value=e,a.setAttribute("readonly","true"),a.style.position="fixed",a.style.opacity="0",document.body.appendChild(a),a.select();const i=document.execCommand("copy");if(document.body.removeChild(a),!i)throw new Error("The browser blocked clipboard access.")})(),Ft=(e,t)=>{if(e&&"object"==typeof e){const t=e,a=t.data,i=a&&"object"==typeof a?a:null,n="string"==typeof(null==i?void 0:i.message)&&i.message||"string"==typeof t.statusText&&t.statusText||"string"==typeof t.message&&t.message||"",r="number"!=typeof t.status||String(n).includes(String(t.status))?"":` (HTTP ${t.status})`;if(n)return`${n}${r}`}return e instanceof Error&&e.message?e.message:t},Mt=e=>X(function*(){try{yield(0,v.getBackendSrv)().post("/api/annotations",e)}catch(e){throw new Error(Ft(e,"Failed to create the Grafana annotation."))}})(),$t="http://127.0.0.1:9110",Nt={off:"Off",manual:"Manual sync",auto:"Auto sync"},Ct={prometheus:"Prometheus metrics",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elasticsearch"},At={prometheus:"Prometheus",loki:"Loki",influxdb:"InfluxDB",postgresql:"PostgreSQL",clickhouse:"ClickHouse",elasticsearch:"Elastic"},Lt={prometheus:"#94A3B8",loki:"#F59E0B",influxdb:"#3B82F6",postgresql:"#60A5FA",clickhouse:"#FACC15",elasticsearch:"#22D3EE"},Bt=e=>At[bt(e)],Dt=({target:e})=>{switch(bt(e)){case"loki":return g().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("path",{d:"M7 20V7.6l3.3-.9V20H7Z",fill:"#D97706"}),g().createElement("path",{d:"M11.3 20V3.8l3.4-.9V20h-3.4Z",fill:"#F59E0B"}),g().createElement("path",{d:"M15.8 20V10.2l3.2-.86V20h-3.2Z",fill:"#FBBF24"}),g().createElement("path",{d:"M5.2 20.4h15.1",stroke:"#B45309",strokeWidth:"1.8",strokeLinecap:"round"}));case"influxdb":return g().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("path",{d:"M12 2.8 20 7.3v9.4l-8 4.5-8-4.5V7.3l8-4.5Z",fill:"none",stroke:"#3B82F6",strokeWidth:"1.8"}),g().createElement("path",{d:"m12 2.8 3.9 7.1L12 21.2 8.1 9.9 12 2.8Z",fill:"none",stroke:"#60A5FA",strokeWidth:"1.3"}),g().createElement("path",{d:"M4 7.3 12 12l8-4.7M4 16.7 12 12l8 4.7",fill:"none",stroke:"#2563EB",strokeWidth:"1.2"}));case"postgresql":return g().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("path",{d:"M6.2 10.6c0-4.4 2.4-7 6.1-7 3.9 0 6.5 2.7 6.5 7 0 2.9-1.2 5.1-3.3 6.3l.3 3.1-2.9-1.8c-.8.15-1.7.15-2.6-.03L7.2 20l.43-3.35c-.95-.7-1.43-2.55-1.43-6.05Z",fill:"#3B82F6",opacity:"0.9"}),g().createElement("path",{d:"M9 10.1c.45-.5 1.25-.5 1.7 0M14 10.1c.45-.5 1.25-.5 1.7 0",stroke:"#DBEAFE",strokeWidth:"1.2",strokeLinecap:"round"}),g().createElement("path",{d:"M12.8 11.3c-.4 1.2-.15 2.1.75 2.7.85.6.95 1.55.15 2.45",fill:"none",stroke:"#DBEAFE",strokeWidth:"1.3",strokeLinecap:"round"}));case"clickhouse":return g().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("path",{d:"M4 4h3v16H4V4Zm5 0h3v16H9V4Zm5 0h3v16h-3V4Z",fill:"#FACC15"}),g().createElement("path",{d:"M19 4h1.8v16H19V4Z",fill:"#EF4444"}));case"elasticsearch":return g().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("circle",{cx:"9",cy:"7",r:"4",fill:"#F59E0B"}),g().createElement("circle",{cx:"15.2",cy:"7.7",r:"3.3",fill:"#22C55E"}),g().createElement("circle",{cx:"16.1",cy:"14.8",r:"4",fill:"#06B6D4"}),g().createElement("circle",{cx:"8.2",cy:"15.5",r:"3.5",fill:"#EF4444"}),g().createElement("circle",{cx:"12",cy:"11.5",r:"3.3",fill:"#64748B",opacity:"0.72"}));default:return g().createElement("svg",{viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("ellipse",{cx:"12",cy:"5.4",rx:"7.2",ry:"3.1",fill:"#64748B"}),g().createElement("path",{d:"M4.8 5.4v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V5.4",fill:"#475569"}),g().createElement("ellipse",{cx:"12",cy:"9.9",rx:"7.2",ry:"3.1",fill:"#94A3B8"}),g().createElement("path",{d:"M4.8 9.9v4.5c0 1.7 3.2 3.1 7.2 3.1s7.2-1.4 7.2-3.1V9.9",fill:"#475569"}),g().createElement("ellipse",{cx:"12",cy:"14.4",rx:"7.2",ry:"3.1",fill:"#CBD5E1"}))}},Tt=e=>g().createElement(Dt,{target:e}),Pt=e=>(null!=e?e:$t).trim().replace(/\/+$/,"")||$t;class _t extends Error{constructor(e,t,a){super(e),ee(this,"status",void 0),ee(this,"requestId",void 0),this.status=t,this.requestId=a,this.name="ExporterApiError"}}const Rt=(e,t,a,i)=>{var n,r;const s=null!==(n=a.headers.get("Content-Type"))&&void 0!==n?n:"unknown",o=null!==(r=a.headers.get("X-Request-ID"))&&void 0!==r?r:"unavailable",l=t.split(/[?#]/,1)[0];if(!i.trim())return`${e} ${l} returned HTTP ${a.status} with an empty body. Check the exporter base path and reverse-proxy route. Request ID: ${o}.`;if(s.includes("text/plain")&&i.includes("grafana_anomaly_"))return`${e} ${l} reached the Prometheus metrics endpoint instead of the exporter JSON API. Check the configured base path. Request ID: ${o}.`;if(s.includes("text/html"))return`${e} ${l} returned HTTP ${a.status} HTML from a proxy or upstream. Request ID: ${o}.`;const c=i.replace(/\s+/g," ").trim().slice(0,200);return`${e} ${l} returned HTTP ${a.status} (${s}): ${c}. Request ID: ${o}.`},It=(e,t={})=>X(function*(){var a,i,n;const r=String(null!==(a=t.method)&&void 0!==a?a:"GET").toUpperCase();let s;try{s=yield fetch(e,t)}catch(t){throw new _t(`${r} ${e.split(/[?#]/,1)[0]} did not receive an HTTP response. Check network reachability, TLS/mixed-content rules, and CORS. ${t instanceof Error?t.message:""}`.trim(),0,"unavailable")}const o=yield s.text(),l=null!==(i=s.headers.get("X-Request-ID"))&&void 0!==i?i:"unavailable";if(!(null!==(n=s.headers.get("Content-Type"))&&void 0!==n?n:"").toLowerCase().includes("application/json")||!o.trim())throw new _t(Rt(r,e,s,o),s.status,l);let c;try{c=JSON.parse(o)}catch(t){throw new _t(Rt(r,e,s,o),s.status,l)}if(!s.ok){var d;const t="string"==typeof c.error?c.error:null===(d=c.error)||void 0===d?void 0:d.message;throw new _t(t||Rt(r,e,s,o),s.status,l)}return c})(),Vt=e=>{if("saved"===e.source)return"saved";const t=e.targets.map(e=>`${e.refId}|${e.datasourceUid}|${e.expr}`).sort().join("||");let a=2166136261;for(let e=0;e<t.length;e+=1)a^=t.charCodeAt(e),a=Math.imul(a,16777619);return`runtime-${(a>>>0).toString(16).padStart(8,"0")}`},qt=(e,t)=>{if(e.length!==t.length)return!1;const a=e=>[e.refId,e.datasourceUid,e.datasourceType,e.expr].map(e=>e.trim()).join("|"),i=e.map(a).sort(),n=t.map(a).sort();return i.every((e,t)=>e===n[t])},Ot=e=>e.trim().toLowerCase().replace(/[^a-z0-9_]+/g,"_").replace(/^_+|_+$/g,"")||"anomaly_panel",zt=(e,t)=>{const a=Ot(e||"anomaly_panel"),i=Ot(null!=t?t:"");return i?`${i}_${a}`:a},Wt=()=>{var e;if("undefined"==typeof window)return"";const t=window.location.pathname.match(/\/d\/([^/]+)/);return null!==(e=null==t?void 0:t[1])&&void 0!==e?e:""},jt=()=>"undefined"==typeof document?"":document.title.replace(/\s+-\s+Grafana$/i,"").replace(/^View panel\s+-\s+/i,"").replace(/^Edit panel\s+-\s+/i,"").replace(/\s+-\s+Dashboards$/i,"").trim(),Ht=()=>{if("undefined"==typeof document)return"";const e=Array.from(document.querySelectorAll('nav[aria-label="Breadcrumbs"] a')).map(e=>{var t,a;return null!==(t=null===(a=e.textContent)||void 0===a?void 0:a.trim())&&void 0!==t?t:""}).filter(Boolean);return e.length>=3&&"dashboards"===e[0].toLowerCase()?e[1]:""},Ut=(e,t)=>{const a=e.trim(),i=t.trim().toLowerCase();return a&&("postgres"!==i&&"postgresql"!==i&&!i.includes("postgresql")||/^postgres(?:ql)?:\/\//i.test(a))?a:""},Qt=e=>e.flatMap((e,t)=>{var a,i,n,r,s,o,l,c,d,m,u,p,h,g,f,y,v,b;if(!e||"object"!=typeof e)return[];const w=e;if(!0===w.hide)return[];const x=(e=>{var t,a,i,n;if("string"==typeof e)return{uid:e,type:"",url:""};if(!e||"object"!=typeof e)return{uid:"",type:"",url:""};const r=e;return{uid:String(null!==(t=null!==(a=r.uid)&&void 0!==a?a:r.name)&&void 0!==t?t:""),type:String(null!==(i=r.type)&&void 0!==i?i:""),url:String(null!==(n=r.url)&&void 0!==n?n:"")}})(w.datasource),E=String(null!==(a=null!==(i=w.datasourceUid)&&void 0!==i?i:x.uid)&&void 0!==a?a:"").trim(),k=String(null!==(n=null!==(r=w.datasourceType)&&void 0!==r?r:x.type)&&void 0!==n?n:"").trim().toLowerCase(),S=Ut(String(null!==(s=null!==(o=null!==(l=w.datasourceUrl)&&void 0!==l?l:w.url)&&void 0!==o?o:x.url)&&void 0!==s?s:"").trim(),k),F=String(null!==(c=null!==(d=null!==(m=null!==(u=null!==(p=w.expr)&&void 0!==p?p:w.expression)&&void 0!==u?u:w.query)&&void 0!==m?m:w.rawSql)&&void 0!==d?d:w.rawQuery)&&void 0!==c?c:"").trim(),M="elasticsearch"===k&&(w.metrics||w.bucketAggs||w.timeField)?JSON.stringify({query:F,metrics:null!==(h=w.metrics)&&void 0!==h?h:[],bucketAggs:null!==(g=w.bucketAggs)&&void 0!==g?g:[],timeField:null!==(f=w.timeField)&&void 0!==f?f:"@timestamp"}):F;return M?"__expr__"===E||"__expr__"===k||"expression"===k?[]:[{refId:String(null!==(y=w.refId)&&void 0!==y?y:`Q${t+1}`).trim()||`Q${t+1}`,expr:M,legend:String(null!==(v=null!==(b=w.legendFormat)&&void 0!==b?b:w.legend)&&void 0!==v?v:"").trim(),datasourceUid:E,datasourceType:k,datasourceUrl:S}]:[]}).filter((e,t,a)=>a.findIndex(t=>t.refId===e.refId&&t.expr===e.expr)===t),Gt=(e,t)=>X(function*(){if(!e||"__expr__"===e||"undefined"==typeof fetch)return"";try{var a,i;const n=yield fetch(`/api/datasources/uid/${encodeURIComponent(e)}`,{credentials:"same-origin"});if(!n.ok)return"";const r=yield n.json();return Ut(String(null!==(a=r.url)&&void 0!==a?a:"").trim(),String(null!==(i=r.type)&&void 0!==i?i:t))}catch(e){return""}})(),Yt=e=>X(function*(){if(0===e.length)return e;const t=Array.from(new Set(e.filter(e=>!e.datasourceUrl&&e.datasourceUid).map(e=>`${e.datasourceUid}:::${e.datasourceType}`))),a=yield Promise.all(t.map(e=>X(function*(){const[t,a]=e.split(":::");return[t,yield Gt(t,a)]})())),i=new Map(a);return e.map(e=>ae(te({},e),{datasourceUrl:e.datasourceUrl||i.get(e.datasourceUid)||""}))})(),Kt=e=>{const t=[];return e.forEach(e=>{if(!e||"object"!=typeof e)return;const a=e;void 0!==a.id&&t.push(a),Array.isArray(a.panels)&&t.push(...Kt(a.panels))}),t},Jt=(e,t,a,i)=>{var n,r;return JSON.stringify({dashboardUid:e.dashboardUid,panelTitle:e.panelTitle,source:e.source,ruleNamePrefix:a,target:i,rangeSeconds:null!==(n=e.rangeSeconds)&&void 0!==n?n:0,stepSeconds:null!==(r=e.stepSeconds)&&void 0!==r?r:0,targets:e.targets.map(e=>{var t;return{refId:e.refId,expr:e.expr,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:t.setupMode,metricPreset:t.metricPreset,effectiveMetricPreset:t.effectiveMetricPreset,detectionMode:t.detectionMode,algorithm:t.algorithm,anomalyDirection:t.anomalyDirection,minimumAbsoluteDeviation:t.minimumAbsoluteDeviation,minimumRelativeDeviation:t.minimumRelativeDeviation,minimumActivity:t.minimumActivity,persistenceBuckets:t.persistenceBuckets,persistenceWindow:t.persistenceWindow,recoveryThreshold:t.recoveryThreshold,recoveryBuckets:t.recoveryBuckets,cooldownBuckets:t.cooldownBuckets,dataQualityGate:t.dataQualityGate,sensitivity:t.sensitivity,baselineWindow:t.baselineWindow,seasonalitySamples:t.seasonalitySamples,seasonalRefinement:t.seasonalRefinement,severityPreset:t.severityPreset}})},Zt=e=>{switch(e){case"1m":return 60;case"5m":return 300;case"15m":return 900;case"1h":return 3600;default:return 0}},Xt=(e,t,a,i,n,r)=>{var s,o;const l=e.targets.filter(e=>e.expr.trim().length>0);if(0===l.length)return null;const c=Zt(n.bucketSpan),d=Math.max(0,Math.round(null!==(s=e.stepSeconds)&&void 0!==s?s:0)),m=d>0?d:c>0?Math.max(5,Math.min(c,60)):30,u="harmonic"===n.algorithm?Math.max(256,2*n.seasonalitySamples+128,n.baselineWindow+1):Math.max(256,n.baselineWindow*Math.max(n.seasonalitySamples,1)+8,6*n.baselineWindow),p=Math.max(0,Math.round(null!==(o=e.rangeSeconds)&&void 0!==o?o:0)),h=Math.max(3600,u*m);return{schemaVersion:3,pluginVersion:"1.5.1",capabilitiesRequired:["idempotentSync","scopeIdentity","directionPolicy","decisionLifecycle",..."harmonic"===n.algorithm?["harmonicScoring"]:[],..."ewma"===n.algorithm?["guardedEwmaScoring"]:[],..."level_shift"===n.algorithm?["guardedLevelShiftScoring"]:[],..."seasonal"===n.algorithm&&"cycle"===n.seasonalRefinement?["guardedSeasonalScoring"]:[],...["zscore","mad"].includes(n.algorithm)?["guardedRollingScoring"]:[]],dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleNamePrefix:zt(e.panelTitle,a),target:i,source:e.source,syncHash:r,scopeHash:Vt(e),scopePolicy:"saved"===e.source?"saved":"runtime",targets:l.map(e=>{var t;return{refId:e.refId,expr:e.expr,legend:e.legend,datasourceUid:e.datasourceUid,datasourceType:e.datasourceType,datasourceUrl:null!==(t=e.datasourceUrl)&&void 0!==t?t:""}}),resolvedOptions:{setupMode:n.setupMode,metricPreset:n.metricPreset,effectiveMetricPreset:n.effectiveMetricPreset,detectionMode:n.detectionMode,algorithm:n.algorithm,anomalyDirection:n.anomalyDirection,minimumAbsoluteDeviation:n.minimumAbsoluteDeviation,minimumRelativeDeviation:n.minimumRelativeDeviation,minimumActivity:n.minimumActivity,persistenceBuckets:n.persistenceBuckets,persistenceWindow:n.persistenceWindow,recoveryThreshold:n.recoveryThreshold,recoveryBuckets:n.recoveryBuckets,cooldownBuckets:n.cooldownBuckets,dataQualityGate:n.dataQualityGate,sensitivity:n.sensitivity,baselineWindow:n.baselineWindow,seasonalitySamples:n.seasonalitySamples,seasonalRefinement:n.seasonalRefinement,severityPreset:n.severityPreset,rangeSeconds:p>0?Math.max(4*m,p):h,stepSeconds:m,bucketSpanSeconds:c}}},ea=e=>"off"===e?{kind:"off",message:"Anomaly score feed is turned off for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:"manual"===e?{kind:"idle",message:"Manual sync is ready. Use the button to publish plugin-computed anomaly scores for this panel.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}:{kind:"idle",message:"Auto sync watches this panel and republishes plugin-computed anomaly scores shortly after data is returned.",source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""},ta=e=>{switch(e){case"synced":return"Synced";case"syncing":return"Syncing";case"error":return"Error";case"unsupported":return"Action needed";case"off":return"Off";default:return"Ready"}},aa=({panelId:e,panelTitle:t,options:a,resolvedOptions:i,liveTargets:n,savedContext:r,savedContextReady:s,analyses:o,timeRangeSeconds:l,queryStepSeconds:c})=>{var d;const[m,u]=(0,h.useState)(()=>{var e;return ea(null!==(e=a.scoreFeedMode)&&void 0!==e?e:"auto")}),[p,g]=(0,h.useState)(""),f=null!==(d=a.scoreFeedMode)&&void 0!==d?d:"auto",y=(0,h.useCallback)((d="manual")=>X(function*(){var m;if("off"!==f){if("auto"!==d||s)try{var h,y,v,b,w,x,E,k;let s=((e,t,a,i,n)=>({source:"live",dashboardUid:Wt()||"local_dashboard",folderTitle:Ht(),dashboardTitle:jt()||"Grafana dashboard",panelTitle:t,targets:a,panelOptions:{},rangeSeconds:i,stepSeconds:n}))(0,t,n,l,c),f=a,M=Pt(a.scoreFeedEndpoint);if(r){"auto"===d&&(f=te({},a,r.panelOptions),M=Pt(f.scoreFeedEndpoint));const e="auto"===d?r.targets:n.length>0?n:r.targets;s=ae(te({},r),{targets:e,source:"auto"===d||0===n.length||qt(r.targets,n)?"saved":"live",rangeSeconds:l,stepSeconds:c})}const $=null!==(h="auto"===d?f.scoreFeedRuleNamePrefix:a.scoreFeedRuleNamePrefix)&&void 0!==h?h:"",N=bt("auto"===d?f.scoreFeedTarget:a.scoreFeedTarget);s=ae(te({},s),{targets:yield Yt(s.targets),rangeSeconds:l,stepSeconds:c});const C=Jt(s,i,$,N),A=Xt(s,e,$,N,i,C),L=((e,t,a,i,n,r)=>{const s=r.flatMap(e=>{var t;const a=null!==(t=[...e.allPoints].reverse().find(e=>null!==e.expected))&&void 0!==t?t:e.allPoints[e.allPoints.length-1];return a?[{key:e.key,label:e.label,timestamp:a.time/1e3,value:a.value,expected:a.expected,lower:a.lower,upper:a.upper,deviation:null===a.expected?null:a.value-a.expected,rawScore:a.score,pointRawScore:a.pointScore,windowRawScore:a.windowScore,scoreDriver:a.scoreDriver,normalizedScore:a.severityScore,severityLabel:a.severityLabel,isAnomaly:a.isAnomaly,decisionState:a.decisionState,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel,threshold:n.sensitivity}]:[]});if(0===s.length)return null;const o=[...s].sort((e,t)=>t.normalizedScore-e.normalizedScore)[0],l=Array.from(new Map(e.targets.map(e=>[`${e.datasourceUid||"unknown"}:${e.datasourceType||"unknown"}`,{uid:e.datasourceUid||"unknown",type:e.datasourceType||"unknown"}])).values());return{dashboardUid:e.dashboardUid,folderTitle:e.folderTitle,dashboardTitle:e.dashboardTitle,panelId:t,panelTitle:e.panelTitle,ruleName:zt(e.panelTitle,a),target:i,source:e.source,sourceDatasources:l,series:s,rule:{timestamp:Math.max(...s.map(e=>e.timestamp)),score:o.normalizedScore,rawScore:o.rawScore,breachCount:s.filter(e=>e.isAnomaly).length,seriesCount:s.length,activeSeries:s.length,severityLabel:o.severityLabel},resolvedOptions:{algorithm:n.algorithm,anomalyDirection:n.anomalyDirection,minimumAbsoluteDeviation:n.minimumAbsoluteDeviation,minimumRelativeDeviation:n.minimumRelativeDeviation,minimumActivity:n.minimumActivity,persistenceBuckets:n.persistenceBuckets,persistenceWindow:n.persistenceWindow,recoveryThreshold:n.recoveryThreshold,recoveryBuckets:n.recoveryBuckets,cooldownBuckets:n.cooldownBuckets,dataQualityGate:n.dataQualityGate,severityPreset:n.severityPreset,sensitivity:n.sensitivity}}})(s,e,$,N,i,o);if(!A&&!L)return void u((m="This panel has no query target or computed anomaly score points to publish yet. Refresh the panel after data is returned.",{kind:"unsupported",message:m,source:null,registered:[],removed:[],lastSyncedAt:null,syncHash:""}));const B=JSON.stringify({registrationHash:C,target:N,ruleName:null!==(y=null!==(v=null==L?void 0:L.ruleName)&&void 0!==v?v:null==A?void 0:A.ruleNamePrefix)&&void 0!==y?y:"",ruleScore:null!==(b=null==L?void 0:L.rule.score)&&void 0!==b?b:null,ruleTimestamp:null!==(w=null==L?void 0:L.rule.timestamp)&&void 0!==w?w:null,series:null!==(x=null==L?void 0:L.series.map(e=>[e.key,e.timestamp,e.normalizedScore,e.isAnomaly]))&&void 0!==x?x:[],algorithm:i.algorithm,severityPreset:i.severityPreset});if("auto"===d&&B===p)return void u(e=>ae(te({},e),{kind:"error"===e.kind?e.kind:"synced",message:null!==e.lastSyncedAt?e.message:`Auto sync is active. Latest plugin-computed scores are published to ${Ct[N]}.`,source:s.source,syncHash:B}));u(e=>{var t;return ae(te({},e),{kind:"syncing",message:"auto"===d?`Registering panel score feed and publishing latest scores to ${Ct[N]}.`:`Registering panel score feed and publishing scores to ${Ct[N]}.`,source:null!==(t=null==s?void 0:s.source)&&void 0!==t?t:e.source})});let D={};if(A){var S;const e=yield It(`${M}/api/capabilities`),t=A.capabilitiesRequired.filter(t=>{var a;return!(null===(a=e.features)||void 0===a?void 0:a.includes(t))});var F;if((null!==(S=e.apiSchemaVersion)&&void 0!==S?S:0)<A.schemaVersion||t.length>0)throw new Error(`Exporter ${null!==(F=e.exporterVersion)&&void 0!==F?F:"unknown"} is not compatible with this plugin. Missing capabilities: ${t.join(", ")||"API schema v2"}. Upgrade the exporter first.`);D=yield It(`${M}/api/sync/panel`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(A)})}let T={};L&&(T=yield It(`${M}/api/feed/scores`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(L)}));const P=((e,t)=>{const a=new Map;return e.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),t.forEach(e=>{var t;return a.set(`${e.rule}:${null!==(t=e.target)&&void 0!==t?t:""}`,e)}),Array.from(a.values())})(Array.isArray(T.registered)?T.registered:[],Array.isArray(D.registered)?D.registered:[]),_=[...Array.isArray(D.removed)?D.removed:[],...Array.isArray(T.removed)?T.removed:[]],R="saved"===s.source?"saved dashboard":"live panel",I=Math.max(0,Math.round(null!==(E=null!==(k=T.acceptedSeries)&&void 0!==k?k:null==L?void 0:L.series.length)&&void 0!==E?E:P.length));g(B),u({kind:"synced",message:P.length>0?L?`Published ${I} plugin-computed score series and registered backend recompute from the ${R} to ${Ct[N]}.`:`Registered backend recompute from the ${R} to ${Ct[N]}; scores will continue while the dashboard is closed.`:_.length>0?`Removed ${_.length} previous score feed registration${1===_.length?"":"s"} because this panel no longer exposes computed score data.`:`Score feed is active for this panel and targets ${Ct[N]}.`,source:s.source,registered:P,removed:_,lastSyncedAt:Date.now(),syncHash:B})}catch(e){u(t=>ae(te({},t),{kind:"error",message:e instanceof Error?e.message:"Score feed sync failed unexpectedly."}))}}else u(ea("off"))})(),[o,n,p,a,e,t,c,i,r,s,f,l]);return(0,h.useEffect)(()=>{if("off"===f)return void u(ea("off"));if("manual"===f)return void u(e=>te({},"synced"===e.kind?e:ae(te({},ea("manual")),{source:e.source,registered:e.registered,removed:e.removed,lastSyncedAt:e.lastSyncedAt,syncHash:e.syncHash})));if("undefined"==typeof window)return;let e=!1,t=!1;const a=()=>X(function*(){if(!e&&!t){t=!0;try{yield y("auto")}finally{t=!1}}})();a();const i=window.setInterval(()=>{a()},15e3);return()=>{e=!0,window.clearInterval(i)}},[y,f]),ae(te({},m),{syncNow:()=>y("manual")})},ia=["Configuration"],na=["Anomaly score feed"],ra=["Analysis"],sa=["Advanced tuning"],oa=["Display"],la=["Visible sections"],ca=[{label:"Recommended",value:"recommended",description:"Pick the metric type and let the plugin choose the algorithm and severity tuning."},{label:"Advanced",value:"advanced",description:"Expose manual algorithm, threshold, and severity controls."}],da=[{label:"Single metric",value:"single"},{label:"Multi metric",value:"multi"}],ma=[{label:"High mean",value:"high_mean",description:"Flag only sustained or unusual increases above the learned baseline."},{label:"Low mean",value:"low_mean",description:"Flag only sustained or unusual decreases below the learned baseline."},{label:"High or low",value:"high_or_low",description:"Flag meaningful deviations in either direction."}],ua=[{label:"Auto sync (Recommended)",value:"auto",description:"Continuously publish plugin-computed anomaly scores to the selected score feed target."},{label:"Manual sync",value:"manual",description:"Show a sync button so users can publish the current plugin-computed score snapshot on demand."},{label:"Off",value:"off",description:"Disable anomaly score feed publishing for this panel."}],pa=[{label:"Prometheus metrics",value:"prometheus",description:"Expose the plugin-computed anomaly scores from the exporter /metrics endpoint."},{label:"Loki",value:"loki",description:"Write plugin-computed anomaly scores to the Loki sink."},{label:"InfluxDB",value:"influxdb",description:"Write plugin-computed anomaly scores to the InfluxDB sink."},{label:"PostgreSQL",value:"postgresql",description:"Write plugin-computed anomaly scores to the PostgreSQL sink."},{label:"ClickHouse",value:"clickhouse",description:"Write plugin-computed anomaly scores to the ClickHouse sink."},{label:"Elasticsearch",value:"elasticsearch",description:"Write plugin-computed anomaly scores to the Elasticsearch sink."}],ha=[{label:"Auto (Recommended)",value:"auto",description:"Inspect the metric names and choose the safest starting algorithm automatically."},{label:"Traffic / throughput",value:"traffic",description:"Good starting point for request rate, throughput, and volume metrics."},{label:"Latency / duration",value:"latency",description:"Tuned for latency, p95, and response-time style metrics."},{label:"Error rate",value:"error_rate",description:"Tuned for error percentage and error-count spikes."},{label:"Resource usage",value:"resource",description:"Useful for CPU, memory, load, saturation, and host metrics."},{label:"Business KPI",value:"business",description:"Useful for revenue, signups, conversions, and other cyclical business metrics."},{label:"Subtle level shift / drift",value:"level_shift",description:"Best when the baseline changes gradually or steps up/down without a single sharp spike."}],ga=[{label:"Auto",value:"auto",description:"Choose an efficient pre-aggregation span automatically on dense or live data."},{label:"Raw samples",value:"raw",description:"Analyze every incoming sample without pre-aggregation."},{label:"1 minute",value:"1m",description:"Aggregate close samples into 1-minute buckets before scoring."},{label:"5 minutes",value:"5m",description:"Aggregate samples into 5-minute buckets before scoring."},{label:"15 minutes",value:"15m",description:"Aggregate samples into 15-minute buckets before scoring."},{label:"1 hour",value:"1h",description:"Aggregate samples into 1-hour buckets before scoring."}],fa=[{label:"Harmonic (known cycle)",value:"harmonic",description:"Opt-in correlated-noise model. Requires a known period of 8-4096 scored samples and two full cycles of warm-up."},{label:"Rolling z-score",value:"zscore",description:"Fast default for spikes and dips in streaming metrics."},{label:"Rolling MAD",value:"mad",description:"Robust against noisy outliers and uneven distributions."},{label:"EWMA baseline",value:"ewma",description:"Tracks gradual baseline shifts while still catching sudden jumps."},{label:"Seasonal baseline",value:"seasonal",description:"Compares each point with similar positions from earlier cycles."},{label:"Level shift detector",value:"level_shift",description:"Looks for sustained baseline changes and subtle step-ups that build over several buckets."}],ya=[{label:"Cycle only",value:"cycle",description:"Uses a fixed sample lag such as 24 or 288 samples."},{label:"Hour of day",value:"hour_of_day",description:"Matches earlier values from the same hour bucket."},{label:"Weekday + hour",value:"weekday_hour",description:"Matches earlier values from the same weekday and hour bucket."}],va=[{label:"Balanced",value:"balanced",description:"General-purpose default for dashboards and alert handoff."},{label:"Warning first",value:"warning_first",description:"Promotes warning and medium severity earlier for watchlist-heavy teams."},{label:"Page first",value:"page_first",description:"Keeps high and critical severities stricter for paging workflows."}],ba=[{label:"Auto (Recommended)",value:"auto",description:"Choose a readable time tick density automatically from the panel width and visible range."},{label:"Compact",value:"compact",description:"Use fewer time labels for dense dashboards and smaller panels."},{label:"Balanced",value:"balanced",description:"Keep a mid-density time axis for general dashboard use."},{label:"Dense",value:"dense",description:"Show more time labels for close operational tracking."}],wa=[{label:"Bottom only",value:"bottom",description:"Show time labels only on the bottom axis."},{label:"Top + bottom",value:"top_and_bottom",description:"Add a second time guide on top for faster cross-checking during incident review."}],xa=[{label:"Severity shapes (Recommended)",value:"severity",description:"Use different marker shapes for low, medium, high, and critical anomalies."},{label:"Classic circles",value:"classic",description:"Keep the previous circle-style anomaly markers."}],Ea=new c.PanelPlugin(({id:e,options:t,data:a,width:i,height:n,timeRange:r,timeZone:s})=>{var o,l,m,u,p,v,b,w,x,E,k,S,F,M,$,N;const C=(0,y.useTheme2)(),A=(L=C.isDark,{wrapper:f.css`
    width: 100%;
    height: 100%;
    min-height: 0;
    container-type: inline-size;
    padding: 10px;
    box-sizing: border-box;
    overflow: auto;
    font-family: 'Segoe UI', sans-serif;
    color: ${L?"#F3F4F6":"#111827"};
    background: ${L?"radial-gradient(circle at 8% 0%, rgba(220,38,38,0.12), transparent 26%), linear-gradient(180deg, #060A12 0%, #0B111C 100%)":"linear-gradient(180deg, #F8FAFC 0%, #EEF4FF 100%)"};
  `,operationalCanvas:f.css`
    width: 100%;
    min-height: 100%;
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(300px, 360px);
    gap: 12px;
    align-items: stretch;
    @media (max-width: 1100px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 1040px) {
      grid-template-columns: 1fr;
    }
  `,workspacePane:f.css`
    min-width: 0;
    min-height: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,inspectorRail:f.css`
    min-width: 0;
    min-height: 0;
    @media (min-width: 1101px) {
      position: sticky;
      top: 0;
      align-self: start;
      max-height: calc(100vh - 24px);
      overflow: auto;
    }
    @container (max-width: 1040px) {
      position: static;
      max-height: none;
      overflow: visible;
    }
  `,header:f.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
  `,statusHeader:f.css`
    position: relative;
    display: grid;
    grid-template-columns: minmax(260px, 0.9fr) minmax(340px, 1.1fr);
    gap: 18px;
    align-items: stretch;
    padding: 14px 16px 14px 22px;
    border-radius: 18px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(135deg, rgba(17,24,39,0.94) 0%, rgba(12,18,29,0.98) 62%, rgba(8,13,22,0.98) 100%)":"linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%)"};
    overflow: hidden;
    box-shadow: ${L?"0 22px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.04)":"0 16px 34px rgba(15,23,42,0.06)"};
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 760px) {
      grid-template-columns: 1fr;
      gap: 14px;
    }
  `,statusRail:f.css`
    position: absolute;
    inset: 0 auto 0 0;
    width: 5px;
    border-radius: 18px 0 0 18px;
  `,statusMain:f.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 10px;
    padding-left: 48px;
    @media (max-width: 700px) {
      padding-left: 34px;
    }
    @container (max-width: 520px) {
      padding-left: 34px;
    }
  `,statusIcon:f.css`
    position: absolute;
    left: 18px;
    top: 50%;
    width: 30px;
    height: 30px;
    transform: translateY(-50%);
    display: grid;
    place-items: center;
    border-radius: 999px;
    color: #FCA5A5;
    border: 1px solid rgba(248,113,113,0.62);
    background: rgba(127,29,29,0.22);
    box-shadow: 0 0 0 5px rgba(220,38,38,0.08);
    @container (max-width: 760px) {
      top: 34px;
      transform: none;
    }
  `,statusIconSvg:f.css`
    width: 18px;
    height: 18px;
    overflow: visible;
  `,statusTitleRow:f.css`
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  `,statusBadge:f.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border: 1px solid currentColor;
  `,statusDot:f.css`
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: currentColor;
    box-shadow: 0 0 0 3px ${L?"rgba(148,163,184,0.18)":"rgba(15,23,42,0.10)"};
  `,titleBlock:f.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
  `,title:f.css`
    font-size: clamp(22px, 1.65vw, 30px);
    font-weight: 800;
    letter-spacing: 0.01em;
  `,subtitle:f.css`
    font-size: 12px;
    color: ${L?"#94A3B8":"#475569"};
    line-height: 1.5;
  `,headerMetaGrid:f.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(140px, max-content));
    gap: 8px 24px;
    color: ${L?"#C7D2E4":"#334155"};
    font-size: 12px;
    font-weight: 700;
    @media (max-width: 700px) {
      grid-template-columns: 1fr;
    }
    @container (max-width: 520px) {
      grid-template-columns: 1fr;
    }
  `,metaAccent:f.css`
    color: #F87171;
    font-weight: 900;
  `,configurationWarning:f.css`
    display: block;
    margin-bottom: 12px;
    padding: 10px 12px;
    border: 1px solid ${L?"#B45309":"#D97706"};
    border-radius: 10px;
    color: ${L?"#FDE68A":"#78350F"};
    background: ${L?"#292014":"#FFFBEB"};
    font-size: 13px;
    line-height: 1.5;
    overflow-wrap: anywhere;
  `,recommendationBanner:f.css`
    display: none;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#111827":"#F8FAFC"};
  `,recommendationBadge:f.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 78px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${L?"#172554":"#DBEAFE"};
    color: ${L?"#BFDBFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  `,recommendationCopy:f.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  `,recommendationTitle:f.css`
    font-size: 13px;
    font-weight: 700;
    color: ${L?"#F8FAFC":"#0F172A"};
  `,recommendationText:f.css`
    font-size: 12px;
    line-height: 1.55;
    color: ${L?"#CBD5E1":"#334155"};
  `,stats:f.css`
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  `,statusStats:f.css`
    display: grid;
    grid-template-columns: 1.18fr repeat(3, minmax(82px, 1fr));
    gap: 10px;
    align-content: stretch;
    min-width: 0;
    @media (max-width: 700px) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    @container (max-width: 520px) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  `,statCard:f.css`
    min-width: 0;
    padding: 12px 13px;
    border-radius: 12px;
    border: 1px solid ${L?"rgba(148,163,184,0.12)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(30,41,59,0.62), rgba(15,23,42,0.82))":"#F8FAFC"};
    box-shadow: ${L?"inset 0 1px 0 rgba(255,255,255,0.04)":"none"};
  `,statCardPrimary:f.css`
    border-color: rgba(248,113,113,0.38);
    background: linear-gradient(145deg, #B91C1C 0%, #7F1D1D 100%);
    color: #FFFFFF !important;
    box-shadow: 0 12px 26px rgba(220,38,38,0.22), inset 0 1px 0 rgba(255,255,255,0.12);
  `,statLabel:f.css`
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: ${L?"#94A3B8":"#64748B"};
  `,statValue:f.css`
    margin-top: 6px;
    font-size: clamp(18px, 1.35vw, 22px);
    font-weight: 850;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  `,statCaption:f.css`
    margin-top: 3px;
    font-size: 11px;
    color: ${L?"#94A3B8":"#64748B"};
    font-weight: 800;
  `,chartCard:f.css`
    flex: 1 1 auto;
    min-height: clamp(340px, 45vh, 520px);
    position: relative;
    border-radius: 12px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, #0A1321 0%, #07101D 100%)":"#FFFFFF"};
    overflow: hidden;
    box-shadow: ${L?"inset 0 1px 0 rgba(255,255,255,0.04), 0 18px 44px rgba(0,0,0,0.22)":"0 14px 28px rgba(15,23,42,0.05)"};
    outline: none;
    &:focus-visible {
      border-color: ${L?"#60A5FA":"#2563EB"};
      box-shadow: ${L?"0 0 0 1px rgba(96,165,250,0.55), inset 0 1px 0 rgba(148,163,184,0.05)":"0 0 0 1px rgba(37,99,235,0.35), 0 14px 28px rgba(15,23,42,0.05)"};
    }
  `,incidentRibbonPanel:f.css`
    position: relative;
    min-height: 34px;
    padding: 5px 10px;
    border-radius: 13px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(15,23,42,0.92), rgba(8,13,22,0.98))":"#FFFFFF"};
    box-shadow: ${L?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 22px rgba(15,23,42,0.04)"};
  `,incidentRibbonEmpty:f.css`
    display: flex;
    align-items: center;
    min-height: 24px;
    padding: 0 4px;
    color: ${L?"#94A3B8":"#64748B"};
    font-size: 12px;
    font-weight: 700;
  `,legend:f.css`
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    align-items: center;
  `,legendTable:f.css`
    border-radius: 12px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    overflow: hidden;
    min-width: 0;
  `,legendTableHeader:f.css`
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    padding: 8px 12px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: ${L?"#94A3B8":"#64748B"};
    border-bottom: 1px solid ${L?"#1E293B":"#D7E3F4"};
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendToolbar:f.css`
    display: grid;
    grid-template-columns: minmax(0, 1fr) 150px;
    gap: 8px;
    padding: 9px 10px;
    border-bottom: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"rgba(8, 13, 22, 0.55)":"#F8FAFC"};
    @media (max-width: 560px) {
      grid-template-columns: 1fr;
    }
  `,legendControl:f.css`
    width: 100%;
    min-width: 0;
    height: 30px;
    border-radius: 8px;
    border: 1px solid ${L?"#334155":"#CBD5E1"};
    background: ${L?"#0B1220":"#FFFFFF"};
    color: ${L?"#E2E8F0":"#0F172A"};
    padding: 0 9px;
    font-size: 11px;
    font-weight: 650;
    outline: none;
    &:focus {
      border-color: ${L?"#60A5FA":"#2563EB"};
      box-shadow: 0 0 0 2px ${L?"rgba(96,165,250,0.16)":"rgba(37,99,235,0.12)"};
    }
  `,legendTableRow:f.css`
    width: 100%;
    display: grid;
    grid-template-columns: minmax(180px, 1fr) 96px 84px 104px;
    gap: 10px;
    align-items: center;
    padding: 9px 12px;
    border-top: 0;
    border-left: 0;
    border-right: 0;
    border-bottom: 1px solid ${L?"rgba(30,41,59,0.7)":"rgba(215,227,244,0.8)"};
    background: transparent;
    color: inherit;
    text-align: left;
    cursor: pointer;
    font-size: 12px;
    &:hover {
      background: ${L?"rgba(59,130,246,0.09)":"rgba(37,99,235,0.06)"};
    }
    &:focus-visible {
      outline: 2px solid ${L?"#60A5FA":"#2563EB"};
      outline-offset: -2px;
    }
    &:last-child {
      border-bottom: 0;
    }
    @media (max-width: 700px) {
      grid-template-columns: minmax(0, 1fr) 72px 72px;
      & > span:last-child {
        display: none;
      }
    }
  `,legendTableFooter:f.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 9px 12px;
    border-top: 1px solid ${L?"rgba(30,41,59,0.8)":"rgba(215,227,244,0.9)"};
    color: ${L?"#94A3B8":"#64748B"};
    font-size: 11px;
    font-weight: 750;
  `,legendSeriesName:f.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    color: ${L?"#E2E8F0":"#0F172A"};
  `,legendValue:f.css`
    font-variant-numeric: tabular-nums;
    font-weight: 700;
    color: ${L?"#CBD5E1":"#334155"};
  `,legendItem:f.css`
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
    min-width: 0;
    font-size: 12px;
    padding: 6px 10px;
    border-radius: 999px;
    background: ${L?"#111827":"#EFF6FF"};
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,legendSwatch:f.css`
    width: 10px;
    height: 10px;
    border-radius: 999px;
  `,grid:f.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
    gap: 12px;
  `,bottomDock:f.css`
    display: grid;
    grid-template-columns: minmax(360px, 1.1fr) minmax(280px, 0.9fr);
    gap: 10px;
    align-items: stretch;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,secondaryDock:f.css`
    display: grid;
    grid-template-columns: minmax(420px, 1.35fr) minmax(260px, 0.65fr);
    gap: 10px;
    align-items: start;
    @media (max-width: 920px) {
      grid-template-columns: 1fr;
    }
  `,sideUtilityStack:f.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,card:f.css`
    border-radius: 12px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(15,23,42,0.94), rgba(10,16,26,0.98))":"#FFFFFF"};
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-height: 0;
    box-shadow: ${L?"inset 0 1px 0 rgba(255,255,255,0.035)":"0 10px 24px rgba(15,23,42,0.045)"};
  `,cardTitle:f.css`
    font-size: 15px;
    font-weight: 700;
    line-height: 1.4;
  `,summaryList:f.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    max-height: min(360px, 42vh);
    overflow-y: auto;
    padding-right: 4px;
  `,summaryTimeline:f.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 10px 12px 12px;
    border-radius: 14px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#0F172A":"#F8FAFC"};
  `,summaryRow:f.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#111827":"#F8FAFC"};
    cursor: pointer;
    transition: transform 120ms ease, border-color 120ms ease;
    &:hover {
      transform: translateY(-1px);
      border-color: ${L?"#334155":"#93C5FD"};
    }
  `,summaryRowSelected:f.css`
    border-color: ${L?"#3B82F6":"#2563EB"};
    box-shadow: inset 0 0 0 1px ${L?"#3B82F6":"#2563EB"};
  `,summaryTitle:f.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
  `,summaryMeta:f.css`
    display: flex;
    justify-content: space-between;
    gap: 8px;
    flex-wrap: wrap;
    font-size: 12px;
    color: ${L?"#94A3B8":"#475569"};
  `,severityBadge:f.css`
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  `,compactHealthStrip:f.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(118px, 1fr));
    gap: 8px;
  `,scoreFeedTargetGrid:f.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(168px, 1fr));
    gap: 8px;
  `,scoreFeedTargetCard:f.css`
    min-width: 0;
    min-height: 96px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 7px;
    padding: 10px;
    border-radius: 12px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.72) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,scoreFeedTargetTop:f.css`
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 9px;
  `,scoreFeedTargetIcon:f.css`
    flex: 0 0 auto;
    width: 27px;
    height: 27px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${L?"rgba(15,23,42,0.92)":"#F8FAFC"};
    border: 1px solid ${L?"rgba(148,163,184,0.16)":"#D7E3F4"};
    font-size: 16px;
    font-weight: 900;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,scoreFeedTargetTitle:f.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${L?"#E2E8F0":"#0F172A"};
  `,scoreFeedTargetStatus:f.css`
    align-self: flex-start;
    min-width: 62px;
    display: inline-flex;
    justify-content: center;
    padding: 5px 10px;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 850;
  `,scoreFeedTargetMeta:f.css`
    font-size: 11px;
    font-weight: 750;
    color: ${L?"#AAB7CA":"#64748B"};
  `,healthChip:f.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    gap: 6px;
    min-height: 68px;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${L?"rgba(148,163,184,0.13)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(15,23,42,0.82) 0%, rgba(8,13,22,0.68) 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,healthChipCompact:f.css`
    min-height: 58px;
    padding: 9px 10px;
  `,healthChipText:f.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  `,healthChipLabel:f.css`
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: ${L?"#94A3B8":"#64748B"};
  `,healthChipValue:f.css`
    font-size: 12px;
    font-weight: 800;
    color: ${L?"#E2E8F0":"#0F172A"};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,targetBadge:f.css`
    min-width: 0;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    max-width: 100%;
  `,targetIcon:f.css`
    flex: 0 0 auto;
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: ${L?"rgba(37,99,235,0.18)":"#EFF6FF"};
    border: 1px solid ${L?"rgba(96,165,250,0.22)":"#BFDBFE"};
    font-size: 15px;
    line-height: 1;

    svg {
      display: block;
      width: 18px;
      height: 18px;
    }
  `,targetText:f.css`
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  `,targetName:f.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    font-weight: 850;
    color: ${L?"#E2E8F0":"#0F172A"};
  `,targetLanguage:f.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 10px;
    font-weight: 750;
    color: ${L?"#94A3B8":"#64748B"};
  `,labelChipGrid:f.css`
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  `,labelChip:f.css`
    max-width: 100%;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 8px;
    border-radius: 999px;
    border: 1px solid ${L?"rgba(96,165,250,0.24)":"#BFDBFE"};
    background: ${L?"rgba(30,64,175,0.24)":"#EFF6FF"};
    color: ${L?"#DBEAFE":"#1D4ED8"};
    font-size: 11px;
    font-weight: 800;
  `,labelChipKey:f.css`
    opacity: 0.72;
  `,labelChipValue:f.css`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,staleBanner:f.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 12px;
    border-radius: 14px;
    border: 1px solid ${L?"#92400E":"#FDBA74"};
    background: ${L?"rgba(146,64,14,0.22)":"#FFF7ED"};
    color: ${L?"#FDBA74":"#9A3412"};
    font-size: 12px;
    font-weight: 700;
  `,incidentHeader:f.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 2px 8px 0;
    flex-wrap: wrap;
  `,severityLegend:f.css`
    display: inline-flex;
    align-items: center;
    gap: 18px;
    flex-wrap: wrap;
    font-size: 12px;
    font-weight: 800;
    color: ${L?"#AAB7CA":"#475569"};
  `,severityLegendItem:f.css`
    display: inline-flex;
    align-items: center;
    gap: 7px;
  `,severityLegendSwatch:f.css`
    width: 10px;
    height: 10px;
    border-radius: 2px;
  `,inlineInspectorLegacy:f.css`
    display: none;
  `,inspectorCard:f.css`
    min-height: 100%;
    border-radius: 16px;
    border: 1px solid ${L?"rgba(148,163,184,0.15)":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, rgba(15,23,42,0.98), rgba(8,13,22,0.99))":"#FFFFFF"};
    box-shadow: ${L?"0 24px 70px rgba(0,0,0,0.34), inset 0 1px 0 rgba(255,255,255,0.045)":"0 18px 34px rgba(15,23,42,0.08)"};
    padding: 18px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  `,inspectorTop:f.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  `,inspectorTitle:f.css`
    font-size: 20px;
    font-weight: 850;
    letter-spacing: -0.01em;
  `,inspectorClose:f.css`
    width: 28px;
    height: 28px;
    display: grid;
    place-items: center;
    border: 0;
    border-radius: 999px;
    background: transparent;
    color: ${L?"#94A3B8":"#64748B"};
    font-size: 22px;
    cursor: default;
  `,inspectorTimestamp:f.css`
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${L?"rgba(148,163,184,0.13)":"#E2E8F0"};
    color: ${L?"#D6DEEB":"#334155"};
    font-size: 15px;
    font-weight: 800;
  `,inspectorRows:f.css`
    display: grid;
    gap: 10px;
    padding-bottom: 12px;
    border-bottom: 1px solid ${L?"rgba(148,163,184,0.13)":"#E2E8F0"};
  `,inspectorRow:f.css`
    display: grid;
    grid-template-columns: minmax(110px, 0.72fr) minmax(0, 1fr);
    gap: 12px;
    align-items: baseline;
    font-size: 13px;
  `,inspectorRowLabel:f.css`
    color: ${L?"#94A3B8":"#64748B"};
    font-weight: 750;
  `,inspectorRowValue:f.css`
    min-width: 0;
    color: ${L?"#E2E8F0":"#0F172A"};
    font-weight: 800;
    text-align: right;
    overflow-wrap: anywhere;
  `,inspectorSectionTitle:f.css`
    font-size: 14px;
    font-weight: 850;
    color: ${L?"#EEF2FF":"#0F172A"};
  `,inspectorHealthRow:f.css`
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    gap: 12px;
  `,inspectorPill:f.css`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 5px 9px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 850;
  `,inspectorActionStack:f.css`
    display: grid;
    gap: 8px;
  `,inspectorActionButton:f.css`
    display: inline-flex;
    align-items: center;
    width: 100%;
    min-height: 42px;
    justify-content: center;
    border-radius: 9px;
    font-size: 13px;
    box-shadow: none;
  `,inspectorActionButtonPrimary:f.css`
    border-color: #2563EB;
    background: linear-gradient(180deg, #3B82F6 0%, #2563EB 100%);
    color: #FFFFFF;
  `,inspectorActionButtonSecondary:f.css`
    border-color: ${L?"rgba(148,163,184,0.18)":"#CBD5E1"};
    background: ${L?"rgba(15,23,42,0.72)":"#F8FAFC"};
    color: ${L?"#D6DEEB":"#334155"};
  `,queryPreview:f.css`
    max-height: 170px;
    overflow: auto;
    margin: 0;
    padding: 12px;
    border-radius: 10px;
    border: 1px solid ${L?"rgba(148,163,184,0.14)":"#D7E3F4"};
    background: ${L?"#101820":"#F8FAFC"};
    color: ${L?"#FBBF24":"#92400E"};
    font-family: 'Cascadia Code', Consolas, monospace;
    font-size: 10.5px;
    line-height: 1.5;
    white-space: pre-wrap;
  `,scoreFeedCard:f.css`
    min-width: 0;
    position: relative;
    overflow: hidden;
    &::before {
      content: '';
      position: absolute;
      inset: 0 auto 0 0;
      width: 3px;
      background: ${L?"linear-gradient(180deg, #38BDF8 0%, #2563EB 55%, #22C55E 100%)":"linear-gradient(180deg, #0EA5E9 0%, #2563EB 55%, #16A34A 100%)"};
      opacity: 0.9;
    }
  `,profileCard:f.css`
    gap: 10px;
  `,profileSummary:f.css`
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  `,profileDetailGrid:f.css`
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
    @media (max-width: 520px) {
      grid-template-columns: 1fr;
    }
  `,handoffCard:f.css`
    padding: 12px;
    gap: 10px;
    background: ${L?"linear-gradient(180deg, rgba(8,13,22,0.88), rgba(6,10,18,0.96))":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,handoffHeader:f.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,detailGrid:f.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 10px;
  `,detailStat:f.css`
    min-width: 0;
    padding: 10px 12px;
    border-radius: 12px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#111827":"#F8FAFC"};
  `,detailLabel:f.css`
    font-size: 11px;
    color: ${L?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.06em;
  `,detailValue:f.css`
    margin-top: 6px;
    font-size: 14px;
    font-weight: 700;
    line-height: 1.4;
    overflow-wrap: anywhere;
  `,detailTable:f.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
  `,metricBreakdownList:f.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,metricBreakdownCard:f.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 14px;
    border: 1px solid ${L?"#22314A":"#D7E3F4"};
    background: ${L?"linear-gradient(180deg, #101A2B 0%, #0E1625 100%)":"linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)"};
  `,metricBreakdownHeader:f.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  `,metricBreakdownTitle:f.css`
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
  `,metricBreakdownReason:f.css`
    margin-top: 4px;
    font-size: 11px;
    line-height: 1.45;
    color: ${L?"#94A3B8":"#64748B"};
  `,metricBreakdownGrid:f.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(112px, 1fr));
    gap: 8px;
  `,metricBreakdownStat:f.css`
    min-width: 0;
    padding: 8px 10px;
    border-radius: 10px;
    border: 1px solid ${L?"#1E293B":"#E2E8F0"};
    background: ${L?"rgba(2, 6, 23, 0.58)":"rgba(255, 255, 255, 0.82)"};
  `,metricBreakdownStatLabel:f.css`
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: ${L?"#94A3B8":"#64748B"};
  `,metricBreakdownStatValue:f.css`
    margin-top: 5px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.35;
    color: ${L?"#F8FAFC":"#0F172A"};
    overflow-wrap: anywhere;
  `,actionRow:f.css`
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
  `,actionButton:f.css`
    border: 1px solid ${L?"#1D4ED8":"#93C5FD"};
    background: ${L?"#172554":"#EFF6FF"};
    color: ${L?"#DBEAFE":"#1D4ED8"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionButtonSecondary:f.css`
    border: 1px solid ${L?"#334155":"#CBD5E1"};
    background: ${L?"#111827":"#F8FAFC"};
    color: ${L?"#E2E8F0":"#334155"};
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 120ms ease, transform 120ms ease;
    &:hover:enabled {
      transform: translateY(-1px);
    }
    &:disabled {
      cursor: not-allowed;
      opacity: 0.55;
    }
  `,actionNotice:f.css`
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 14px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#111827":"#F8FAFC"};
  `,feedRuleList:f.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
  `,wideCard:f.css`
    grid-column: 1 / -1;
  `,feedRuleCard:f.css`
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
    border-radius: 12px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#111827":"#F8FAFC"};
  `,codeLine:f.css`
    border-radius: 10px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#020617":"#F8FAFC"};
    padding: 10px 12px;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    word-break: break-word;
  `,detailRow:f.css`
    display: grid;
    grid-template-columns: minmax(0, 1.3fr) repeat(4, minmax(0, 1fr));
    gap: 10px;
    align-items: center;
    font-size: 12px;
  `,detailHeaderRow:f.css`
    color: ${L?"#94A3B8":"#64748B"};
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-size: 11px;
  `,monoBlock:f.css`
    width: 100%;
    min-height: 170px;
    max-height: 320px;
    overflow: auto;
    border-radius: 12px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#020617":"#F8FAFC"};
    padding: 12px;
    box-sizing: border-box;
    font-family: 'Cascadia Code', 'Consolas', monospace;
    font-size: 11px;
    line-height: 1.55;
    white-space: pre-wrap;
    word-break: break-word;
  `,emptyState:f.css`
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 240px;
    border-radius: 16px;
    border: 1px dashed ${L?"#334155":"#CBD5E1"};
    background: ${L?"#020617":"#FFFFFF"};
    color: ${L?"#94A3B8":"#64748B"};
    text-align: center;
    padding: 20px;
    line-height: 1.6;
  `,skeletonShell:f.css`
    display: grid;
    grid-template-rows: auto minmax(240px, 1fr) auto;
    gap: 12px;
  `,skeletonBlock:f.css`
    position: relative;
    overflow: hidden;
    min-height: 20px;
    border-radius: 14px;
    border: 1px solid ${L?"#1E293B":"#D7E3F4"};
    background: ${L?"#111827":"#F8FAFC"};
    &::after {
      content: '';
      position: absolute;
      inset: 0;
      transform: translateX(-100%);
      background: linear-gradient(90deg, transparent, ${L?"rgba(148,163,184,0.12)":"rgba(148,163,184,0.22)"}, transparent);
      animation: anomaly-shimmer 1.45s infinite;
    }
    @keyframes anomaly-shimmer {
      100% {
        transform: translateX(100%);
      }
    }
  `,skeletonHeader:f.css`
    height: 86px;
  `,skeletonChart:f.css`
    min-height: 320px;
  `,skeletonRows:f.css`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  `,skeletonRow:f.css`
    height: 128px;
  `});var L;const B=(0,h.useMemo)(()=>et(a.series),[a.series]),D=(e=>{const t=String(null!=e?e:"").toLowerCase();return t.includes("loading")||t.includes("streaming")||t.includes("notstarted")})(a.state),[T,P]=(0,h.useState)([]);(0,h.useEffect)(()=>{if(0===B.length||"undefined"==typeof window)return;const e=window.setTimeout(()=>{P(B)},0);return()=>window.clearTimeout(e)},[B]);const _=B.length>0?B:D?T:B,R=D&&0===B.length&&T.length>0,I=D&&0===_.length,V=(0,h.useMemo)(()=>_.map(e=>e.label),[_]),q=(0,h.useMemo)(()=>Oe(t,V),[t,V]),O=(0,h.useMemo)(()=>Xe(t),[t]),z="advanced"===t.setupMode||"custom"===t.metricPreset?d(t.anomalyDirection).warning:null,W=z?g().createElement("div",{role:"status",className:A.configurationWarning},z):null,j=t.title||"Anomaly detector",H=Wt(),[U,Q]=(0,h.useState)(null),G=(null==U?void 0:U.dashboardUid)===H?U.context:null,Y=!H||(null==U?void 0:U.dashboardUid)===H,K=(0,h.useMemo)(()=>{var e,t;return Qt(null!==(e=null===(t=a.request)||void 0===t?void 0:t.targets)&&void 0!==e?e:[])},[a]);(0,h.useEffect)(()=>{let t=!1;return H?((a=null!=e?e:0,i=j,X(function*(){var e,t,n,r,s,o,l,c;const d=Wt();if(!d||"undefined"==typeof fetch)return null;const m=yield fetch(`/api/dashboards/uid/${encodeURIComponent(d)}`,{credentials:"same-origin"});if(!m.ok)throw new Error(`Could not read the saved dashboard definition (${m.status}).`);const u=yield m.json(),p=null!==(e=u.dashboard)&&void 0!==e?e:{},h=String(null!==(t=null!==(n=null===(c=u.meta)||void 0===c?void 0:c.folderTitle)&&void 0!==n?n:Ht())&&void 0!==t?t:"").trim(),g=Kt(Array.isArray(p.panels)?p.panels:[]).find(e=>{var t;return Number(null!==(t=e.id)&&void 0!==t?t:-1)===a});if(!g)return null;const f=yield Yt(Qt(Array.isArray(g.targets)?g.targets:[]));return{source:"saved",dashboardUid:d,folderTitle:h,dashboardTitle:String(null!==(r=null!==(s=p.title)&&void 0!==s?s:jt())&&void 0!==r?r:d).trim()||d,panelTitle:String(null!==(o=g.title)&&void 0!==o?o:i).trim()||i,targets:f,panelOptions:null!==(l=g.options)&&void 0!==l?l:{}}})()).then(e=>{t||Q({dashboardUid:H,context:e})}).catch(()=>{t||Q({dashboardUid:H,context:null})}),()=>{t=!0}):()=>{t=!0};var a,i},[H,e,j]);const{analyses:J,effectiveBucketSpanMs:Z}=(0,h.useMemo)(()=>tt(_,q),[_,q]),[ee,ie]=(0,h.useState)(()=>new Set),[ne,se]=(0,h.useState)(null),[oe,ce]=(0,h.useState)(""),[me,ue]=(0,h.useState)("flagged");(0,h.useEffect)(()=>{if("undefined"==typeof window)return;const e=window.setTimeout(()=>{const e=new Set(J.map(e=>e.key));ie(t=>{const a=new Set([...t].filter(t=>e.has(t)));return a.size===t.size?t:a}),se(t=>t&&!e.has(t)?null:t)},0);return()=>window.clearTimeout(e)},[J]);const pe=(0,h.useMemo)(()=>ne?J.filter(e=>e.key===ne):J.filter(e=>!ee.has(e.key)),[J,ee,ne]),he=(0,h.useMemo)(()=>"multi"===q.detectionMode?((e,t)=>{const a=new Map;return e.forEach(e=>{e.allPoints.forEach(t=>{var i;if(null===t.expected)return;const n=null!==(i=a.get(t.time))&&void 0!==i?i:[];n.push({point:t,label:e.label}),a.set(t.time,n)})}),[...a.entries()].map(([e,a])=>{var i,n,r;const s=[...a].sort((e,t)=>t.point.score-e.point.score),o=s.slice(0,Math.min(3,s.length)).reduce((e,t)=>e+t.point.score,0)/Math.min(3,s.length||1),l=s.reduce((e,t)=>je(e,t.point),{severityLabel:"normal",severityScore:0}),c=s[0],d=s.slice(0,Math.min(3,s.length)).reduce((e,t)=>e+t.point.confidenceScore,0)/Math.min(3,s.length||1),m=d>=80?"high":d>=55?"medium":"low",u=s.reduce((e,t)=>((e,t)=>{const a=["healthy","gappy","thin","flatline"];return a.indexOf(t)>a.indexOf(e)?t:e})(e,t.point.dataQualityLabel),"healthy");return{time:e,bucketStart:null!==(i=null==c?void 0:c.point.bucketStart)&&void 0!==i?i:e,bucketEnd:null!==(n=null==c?void 0:c.point.bucketEnd)&&void 0!==n?n:e,score:o,contributors:s.filter(e=>e.point.isAnomaly).map(e=>e.label).slice(0,4),activeSeries:a.length,isAnomaly:o>=t.sensitivity||s.some(e=>e.point.isAnomaly),decisionState:null!==(r=null==c?void 0:c.point.decisionState)&&void 0!==r?r:"normal",severityLabel:l.severityLabel,severityScore:l.severityScore,confidenceScore:Math.round(10*d)/10,confidenceLabel:m,dataQualityLabel:u}}).sort((e,t)=>e.time-t.time)})(J,q):[],[J,q]),ge=(0,h.useMemo)(()=>{var e,t,a,i,n,s;const o=null!==(e=null==r||null===(i=r.from)||void 0===i||null===(a=i.valueOf)||void 0===a?void 0:a.call(i))&&void 0!==e?e:0,l=null!==(t=null==r||null===(s=r.to)||void 0===s||null===(n=s.valueOf)||void 0===n?void 0:n.call(s))&&void 0!==t?t:0;return o>0&&l>o?Math.max(60,Math.round((l-o)/1e3)):0},[r]),fe=(0,h.useMemo)(()=>{var e;const t=a.request,i=Number(null!==(e=null==t?void 0:t.intervalMs)&&void 0!==e?e:0);return Number.isFinite(i)&&i>0?Math.max(1,Math.round(i/1e3)):0},[a]),Se=aa({panelId:null!=e?e:0,panelTitle:j,options:t,resolvedOptions:q,liveTargets:K,savedContext:G,savedContextReady:Y,analyses:J,timeRangeSeconds:ge,queryStepSeconds:fe}),Fe=(0,h.useMemo)(()=>O.anomalyFeed?lt(J,he,q):[],[J,he,q,O.anomalyFeed]),[Ie,qe]=(0,h.useState)(null),[We,Qe]=(0,h.useState)(null),[Ge,Ye]=(0,h.useState)(null),[Ke,Je]=(0,h.useState)(null),[Ze,pt]=(0,h.useState)(!1),[gt,vt]=(0,h.useState)(!1),[Et,Ft]=(0,h.useState)(null),[$t,At]=(0,h.useState)({width:0,height:0}),Dt=(0,h.useMemo)(()=>{var e,t;return((e,t,a)=>!!e&&("event"===e.kind?a.some(t=>t.time===e.time):t.some(t=>t.key===e.seriesKey&&t.allPoints.some(t=>t.time===e.time))))(Ie,J,he)?Ie:null!==(e=null===(t=Fe[0])||void 0===t?void 0:t.selection)&&void 0!==e?e:null},[J,he,Ie,Fe]),Pt=(0,h.useMemo)(()=>[...Fe].sort((e,t)=>e.time-t.time),[Fe]),_t=ze(Dt);(0,h.useLayoutEffect)(()=>{const e=Et;if(!e)return;let t=0;const a=()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),t=window.requestAnimationFrame(()=>{const t={width:Math.round(e.clientWidth),height:Math.round(e.clientHeight)};At(e=>e.width===t.width&&e.height===t.height?e:t)}))};a();let i=null;return"undefined"!=typeof ResizeObserver?(i=new ResizeObserver(()=>{a()}),i.observe(e)):"undefined"!=typeof window&&window.addEventListener("resize",a),()=>{"undefined"!=typeof window&&(window.cancelAnimationFrame(t),window.removeEventListener("resize",a)),null==i||i.disconnect()}},[Et]),(0,h.useEffect)(()=>{if(!Ke||"undefined"==typeof window)return;const e=window.setTimeout(()=>{Je(null)},3200);return()=>{window.clearTimeout(e)}},[Ke]);const Rt=e=>{e&&(qe(e.selection),Ye(e.time),Qe(e.time))},It=(0,h.useMemo)(()=>{var e,t;const a=ct(Dt,J,he);if(a)return a;const i=null!==(e=null!==(t=Fe.find(e=>ze(e.selection)===_t))&&void 0!==t?t:Fe[0])&&void 0!==e?e:null;return(n=i)?{kind:"point",title:n.title,subtitle:n.subtitle,seriesKey:ze(n.selection),seriesLabel:n.title,color:we[n.severityLabel],time:n.time,bucketStart:n.time,bucketEnd:n.time+1,actual:n.score,expected:null,deviation:null,deviationPercent:null,rangeLower:null,rangeUpper:null,sampleCount:1,minValue:n.score,maxValue:n.score,score:n.score,pointScore:n.score,windowScore:0,scoreDriver:"point",severityLabel:n.severityLabel,severityScore:n.severityScore,confidenceScore:n.confidenceScore,confidenceLabel:n.confidenceLabel,dataQualityLabel:n.dataQualityLabel}:null;var n},[Dt,_t,J,he,Fe]),Vt=(0,h.useMemo)(()=>(pe.length>0?pe:J).flatMap(e=>e.allPoints),[J,pe]),qt=null!=Ge?Ge:We,Ot=(0,h.useMemo)(()=>((e,t,a)=>{var i;if(null===e)return null;const n=t.map(t=>{const a=t.allPoints.find(t=>t.time===e);return a?{key:t.key,label:t.label,color:t.color,actual:a.value,expected:a.expected,score:a.score,isAnomaly:a.isAnomaly,decisionState:a.decisionState,severityLabel:a.severityLabel,severityScore:a.severityScore,confidenceScore:a.confidenceScore,confidenceLabel:a.confidenceLabel,dataQualityLabel:a.dataQualityLabel}:null}).filter(e=>null!==e).sort((e,t)=>t.score-e.score);if(0===n.length)return null;const r=null!==(i=a.find(t=>t.time===e))&&void 0!==i?i:null,s=r?{severityLabel:r.severityLabel,severityScore:r.severityScore}:n.reduce((e,t)=>je(e,t),{severityLabel:"normal",severityScore:0});return{time:e,event:r,series:n,anomalyCount:n.filter(e=>e.isAnomaly).length+((null==r?void 0:r.isAnomaly)?1:0),severityLabel:s.severityLabel,severityScore:s.severityScore}})(qt,pe,he),[qt,pe,he]),zt=((e,t)=>{switch(e){case"synced":return t?"#34D399":"#047857";case"syncing":return t?"#FBBF24":"#B45309";case"error":return t?"#F87171":"#B91C1C";case"unsupported":return t?"#F59E0B":"#B45309";case"off":return t?"#94A3B8":"#64748B";default:return t?"#60A5FA":"#1D4ED8"}})(Se.kind,C.isDark),Ut=yt(Se.registered),Gt=bt(null!==(o=null===(w=Se.registered[0])||void 0===w?void 0:w.target)&&void 0!==o?o:t.scoreFeedTarget),Jt="error"===Se.kind?"Error":"syncing"===Se.kind?"Syncing":"synced"===Se.kind?"Up":"Ready",Zt="Up"===Jt?"#22C55E":"Syncing"===Jt?"#60A5FA":"Error"===Jt?"#EF4444":"#F59E0B",Xt="Up"===Jt?(ea=Se.lastSyncedAt)?new Date(ea).toLocaleString():"Not synced yet":"Syncing"===Jt?"Publishing":"Error"===Jt?"Check exporter":"Selected target";var ea;const ia="synced"===Se.kind?`${Bt(Gt)} healthy`:ta(Se.kind),na="off"!==t.scoreFeedMode?g().createElement("div",{className:`${A.card} ${A.scoreFeedCard}`},g().createElement("div",{style:{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,flexWrap:"wrap"}},g().createElement("div",{style:{minWidth:0,flex:"1 1 320px"}},g().createElement("div",{className:A.cardTitle},"Anomaly score feed"),g().createElement("div",{className:A.subtitle},Se.message)),g().createElement("div",{style:{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}},g().createElement("span",{className:A.recommendationBadge,style:{background:`${zt}22`,color:zt}},ia),g().createElement("button",{type:"button",onClick:()=>{Se.syncNow()},disabled:"syncing"===Se.kind,style:{border:"1px solid "+(C.isDark?"#1D4ED8":"#93C5FD"),background:C.isDark?"#172554":"#EFF6FF",color:C.isDark?"#DBEAFE":"#1D4ED8",borderRadius:999,padding:"8px 14px",fontSize:12,fontWeight:700,cursor:"syncing"===Se.kind?"wait":"pointer",opacity:"syncing"===Se.kind?.72:1}},"syncing"===Se.kind?"Syncing...":"Sync score feed"))),g().createElement("div",{className:A.scoreFeedTargetGrid,"aria-label":"Score feed target health"},g().createElement("div",{className:`${A.healthChip} ${A.healthChipCompact}`},g().createElement("span",{"aria-hidden":"true",style:{width:10,height:10,borderRadius:999,background:Zt,boxShadow:`0 0 0 4px ${Zt}1f`}}),g().createElement("div",{className:A.healthChipText},g().createElement("span",{className:A.healthChipLabel},"Status"),g().createElement("span",{className:A.healthChipValue},ta(Se.kind)))),g().createElement("div",{className:`${A.healthChip} ${A.healthChipCompact}`},g().createElement("div",{className:A.healthChipText},g().createElement("span",{className:A.healthChipLabel},"Mode"),g().createElement("span",{className:A.healthChipValue},Nt[null!==(l=t.scoreFeedMode)&&void 0!==l?l:"auto"]))),g().createElement("div",{className:`${A.healthChip} ${A.healthChipCompact}`},g().createElement("div",{className:A.scoreFeedTargetTop},g().createElement("span",{className:A.scoreFeedTargetIcon,style:{color:(ra=Gt,Lt[bt(ra)])}},Tt(Gt)),g().createElement("div",{className:A.healthChipText},g().createElement("span",{className:A.scoreFeedTargetTitle},Bt(Gt)),g().createElement("span",{className:A.scoreFeedTargetMeta},"Score target")))),g().createElement("div",{className:`${A.healthChip} ${A.healthChipCompact}`},g().createElement("div",{className:A.healthChipText},g().createElement("span",{className:A.healthChipLabel},"Last sync"),g().createElement("span",{className:A.healthChipValue},Xt))),g().createElement("div",{className:`${A.healthChip} ${A.healthChipCompact}`},g().createElement("div",{className:A.healthChipText},g().createElement("span",{className:A.healthChipLabel},"Feed series"),g().createElement("span",{className:A.healthChipValue},Se.registered.length>0?Se.registered.length:"Waiting")))),Se.registered.length>0?g().createElement(g().Fragment,null,g().createElement("div",{className:A.subtitle},"Published score feed records are ready for alerting from the selected target. Queries below match the store selected in Score feed target."),g().createElement("div",{className:A.actionRow},g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>pt(e=>!e)},Ze?"Hide synced rules":"Show synced rules")),Ze?g().createElement("div",{className:A.feedRuleList},Se.registered.map(e=>{var t,a,i;return g().createElement("div",{key:e.rule,className:A.feedRuleCard},g().createElement("div",{className:A.handoffHeader},g().createElement("div",{style:{minWidth:0,flex:"1 1 180px"}},g().createElement("div",{className:A.summaryTitle},e.rule),g().createElement("div",{className:A.subtitle},"Alert rule query")),g().createElement("span",{className:A.targetBadge,title:wt(e)},g().createElement("span",{className:A.targetIcon},Tt(null!==(t=e.target)&&void 0!==t?t:"prometheus")),g().createElement("span",{className:A.targetText},g().createElement("span",{className:A.targetName},Bt(null!==(a=e.target)&&void 0!==a?a:"prometheus")),g().createElement("span",{className:A.targetLanguage},null!==(i=e.queryLanguage)&&void 0!==i?i:Ut)))),g().createElement("div",{className:A.codeLine},e.query),g().createElement("div",{className:A.subtitle},"Per-series drilldown query"),g().createElement("div",{className:A.codeLine},e.perSeriesQuery),e.activeQuery?g().createElement(g().Fragment,null,g().createElement("div",{className:A.subtitle},"Incident lifecycle query (open or recovering)"),g().createElement("div",{className:A.codeLine},e.activeQuery)):null,e.queryVariants&&e.queryVariants.length>0?g().createElement("div",{className:A.feedRuleList},e.queryVariants.map(t=>g().createElement("div",{key:`${e.rule}-${t.target}-${t.queryLanguage}`,className:A.feedRuleCard},g().createElement("div",{className:A.handoffHeader},g().createElement("div",{className:A.subtitle},"Variant query"),g().createElement("span",{className:A.targetBadge,title:wt(t)},g().createElement("span",{className:A.targetIcon},Tt(t.target)),g().createElement("span",{className:A.targetText},g().createElement("span",{className:A.targetName},Bt(t.target)),g().createElement("span",{className:A.targetLanguage},t.queryLanguage)))),g().createElement("div",{className:A.codeLine},t.query),t.activeQuery?g().createElement("div",{className:A.codeLine},t.activeQuery):null,g().createElement("div",{className:A.codeLine},t.perSeriesQuery),g().createElement("div",{className:A.actionRow},g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>{St(t.query).then(()=>Je({tone:"success",message:`Copied ${wt(t)} query for ${e.rule}.`})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the target query."}))}},"Copy variant query"))))):null,g().createElement("div",{className:A.actionRow},g().createElement("button",{type:"button",className:A.actionButton,onClick:()=>{St(e.query).then(()=>Je({tone:"success",message:`Copied alert query for ${e.rule}.`})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Copy alert query"),g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>{St(e.perSeriesQuery).then(()=>Je({tone:"success",message:`Copied per-series query for ${e.rule}.`})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the per-series query."}))}},"Copy series query")))})):null):null):null;var ra;if(I)return g().createElement("div",{className:A.wrapper},g().createElement("div",{className:A.skeletonShell,"aria-label":"Anomaly detector is loading"},W,g().createElement("div",{className:`${A.skeletonBlock} ${A.skeletonHeader}`}),g().createElement("div",{className:`${A.skeletonBlock} ${A.skeletonChart}`}),g().createElement("div",{className:A.skeletonRows},g().createElement("div",{className:`${A.skeletonBlock} ${A.skeletonRow}`}),g().createElement("div",{className:`${A.skeletonBlock} ${A.skeletonRow}`}),g().createElement("div",{className:`${A.skeletonBlock} ${A.skeletonRow}`}))));if(0===_.length||0===Vt.length)return g().createElement("div",{className:A.wrapper},O.scoreFeed?na:null,W,g().createElement("div",{className:A.emptyState},"Add a time series query with at least one numeric field to start anomaly analysis."));const sa=J.length,oa="multi"===q.detectionMode?he.filter(e=>e.isAnomaly).length:J.reduce((e,t)=>e+t.anomalyCount,0),la="multi"===q.detectionMode?he.map(e=>e.severityScore):J.map(e=>e.maxSeverityScore),ca=Math.max(...la,0),da=J.reduce((e,t)=>je(e,{severityLabel:t.maxSeverityLabel,severityScore:t.maxSeverityScore}),{severityLabel:"normal",severityScore:0}),ma=Vt.map(e=>e.time),ua=[...new Set(ma)].sort((e,t)=>e-t),pa=Vt.flatMap(e=>[e.value,e.expected,e.lower,e.upper]).filter(e=>null!==e&&Number.isFinite(e)),ha=Math.min(...ma),ga=Math.max(...ma),fa=Math.max(ga-ha,1),ya=Math.max((null!==(m=null===(E=r.to)||void 0===E||null===(x=E.valueOf)||void 0===x?void 0:x.call(E))&&void 0!==m?m:ga)-(null!==(u=null===(S=r.from)||void 0===S||null===(k=S.valueOf)||void 0===k?void 0:k.call(S))&&void 0!==u?u:ha),1),va=Math.max(fa,ya),ba=((e,t)=>{const a=e.filter(Number.isFinite),i=t.filter(Number.isFinite);if(0===a.length)return{min:0,max:1};const n=Math.min(...a),r=Math.max(...a),s=Math.max(.12*(r-n),.03*Math.abs(r),1);return{min:i.length>0&&i.every(e=>e>=0)?Math.max(0,n-s):n-s,max:r+s}})(pa,Vt.map(e=>e.value).filter(Number.isFinite)),wa=ba.min,xa=ba.max,Ea=(0,c.timeZoneAbbrevation)(ga,{timeZone:s})||("string"==typeof s?s:"local"),ka=we[da.severityLabel],Sa=O.initialLabels||O.statistics,Fa=O.detectionProfile||O.exports,Ma=O.anomalyFeed||Fa,$a=O.seriesSummary||O.scoreFeed&&Boolean(na),Na=O.mainChart&&!Sa&&!O.anomalyFeed&&!$a&&!Fa&&!O.inspector,Ca=Math.max(i-24,120),Aa=Na?Math.max(n-24,100):Math.max(Math.min(Ma?.54*n:n-72,500),340),La=$t.width>0?$t.width:Ca,Ba=$t.height>0?$t.height:Aa,Da=ae(te({},re),{top:Ba<280?18:24,right:"multi"===q.detectionMode?28:24,bottom:Ba<280?42:54,left:"multi"===q.detectionMode?La<720?80:92:La<720?72:84}),Ta=Math.max(La-Da.left-Da.right,40),Pa=Math.max(Ba-Da.top-Da.bottom,40),_a=e=>ga===ha?Da.left+Ta/2:Da.left+(e-ha)/(ga-ha)*Ta,Ra=e=>xa===wa?Da.top+Pa/2:Da.top+Pa-(e-wa)/(xa-wa)*Pa,Ia=((e,t,a,i)=>{const n=De(a,i),r="multi"===t?e/235:e/205,s="compact"===n?.76:"dense"===n?1.35:1,o=Math.round(r*s),l="dense"===n?5:4,c="dense"===n?10:"compact"===n?7:8;return Math.max(l,Math.min(c,o))})(La,q.detectionMode,q.timeAxisDensity,va),Va=Te(va,q.timeAxisDensity).length>5?110:68,qa=Math.min(Ia,Math.max(2,Math.floor(Ta/Va)+1)),Oa=Math.max(2,Math.min(6,Math.floor(Pa/48)+1)),za=nt(ha,ga,qa),Wa="top_and_bottom"===q.timeAxisPlacement?za.filter((e,t)=>0===t||t===za.length-1||t%Math.max(1,Math.ceil(za.length/3))===0):[],ja=nt(wa,xa,Oa),Ha=Math.max(64,Ta/10),Ua="multi"===q.detectionMode?ot(rt(he.filter(e=>e.isAnomaly),_a,Ha,"event"===(null==Dt?void 0:Dt.kind)?Dt.time:null),8,"event"===(null==Dt?void 0:Dt.kind)?Dt.time:null):[],Qa=q.showFocusBand?((e,t,a)=>{if(!e||a.length<2)return null;const i=st(a,e.time);if(i<0)return null;const n=Math.max(3,Math.min(5,Math.floor(a.length/10)||3)),r=Math.max(0,i-n),s=Math.min(a.length-1,i+n),o=a[r],l=a[s];if(l<=o)return null;const c=t.map(e=>({key:e.key,label:e.label,color:e.color,points:e.allPoints.filter(e=>e.time>=o&&e.time<=l)})).filter(e=>e.points.length>0);if(0===c.length)return null;const d=c.flatMap(e=>e.points.flatMap(e=>[e.value,e.expected].filter(e=>null!==e&&Number.isFinite(e))));return 0===d.length?null:{startTime:o,endTime:l,selectedTime:e.time,bucketStart:e.bucketStart,bucketEnd:e.bucketEnd,title:"event"===e.kind?"Focused incident window":`Focused view for ${e.seriesLabel}`,series:c,minValue:Math.min(...d),maxValue:Math.max(...d)}})(It,pe,ua):null,Ga=((e,t,a,i)=>{const n=i.length>=2?Me(i.slice(1).map((e,t)=>Math.max(e-i[t],1))):6e4,r=Math.max(1.25*n,3e4),s="multi"===a?t.filter(e=>e.isAnomaly).map(e=>({start:e.bucketStart,end:Math.max(e.bucketEnd,e.time),center:e.time,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:{kind:"event",time:e.time}})):e.flatMap(e=>e.allPoints.filter(e=>e.isAnomaly).map(t=>({start:t.bucketStart,end:Math.max(t.bucketEnd,t.time),center:t.time,severityLabel:t.severityLabel,severityScore:t.severityScore,selection:{kind:"point",seriesKey:e.key,time:t.time}})));if(0===s.length)return[];s.sort((e,t)=>e.start-t.start);const o=[];let l=[s[0]];const c=()=>{if(0===l.length)return;const e=l.reduce((e,t)=>je(e,t)===e?e:t,l[0]),t=Math.min(...l.map(e=>e.start)),a=Math.max(...l.map(e=>e.end));o.push({key:`ribbon-${t}-${a}-${o.length}`,start:t,end:a,center:e.center,count:l.length,label:1===l.length?"1 incident":`${l.length} incidents`,severityLabel:e.severityLabel,severityScore:e.severityScore,selection:e.selection}),l=[]};for(let e=1;e<s.length;e+=1){const t=s[e],a=l[l.length-1];t.start<=a.end+r?l.push(t):(c(),l=[t])}return c(),o})(pe,he,q.detectionMode,ua),Ya=Qa?Math.max(54,Math.min(76,.2*Pa)):0,Ka=Qa?Da.top+Pa-Ya-10:Da.top+Pa,Ja=Qa?Ka-8:Da.top+Pa,Za=pe.length>8,Xa=Za?[]:pe.length>4?[...pe].sort((e,t)=>t.maxSeverityScore-e.maxSeverityScore||t.anomalyCount-e.anomalyCount||e.label.localeCompare(t.label)).slice(0,4):pe,ei=q.showInlineSeriesLabels&&!Za?((e,t,a,i,n,r)=>{const s=e.map(e=>{const i=[...e.points].reverse().find(e=>Number.isFinite(e.value));if(!i)return null;const n=Be(`${e.label} • ${$e(i.value)}`,28);return{key:e.key,label:n,color:e.color,targetY:a(i.value),labelY:a(i.value),anchorX:r,lastX:t(i.time),lastY:a(i.value),width:Math.max(84,Math.min(168,6.6*n.length+18)),value:i.value}}).filter(e=>null!==e).sort((e,t)=>e.targetY-t.targetY);if(0===s.length)return[];let o=i+14;for(const e of s)e.labelY=Math.max(e.targetY,o),o=e.labelY+20;o=n-12;for(let e=s.length-1;e>=0;e-=1){const t=s[e];t.labelY=Math.min(t.labelY,o),o=t.labelY-20}return s.map(e=>ae(te({},e),{labelY:Math.max(i+14,Math.min(n-12,e.labelY))}))})(Xa,_a,Ra,Da.top+12,Ja-10,La-Da.right-10):[],ti=at(q.bucketSpan,Z),ai=((e,t)=>{const a=at(e.bucketSpan,t),i="custom"===e.effectiveMetricPreset?"Custom profile is active.":`${de[e.effectiveMetricPreset]} profile is active.`,n="harmonic"===e.algorithm?`It uses a known cycle of ${e.seasonalitySamples} scored samples, with correlated-noise correction and ${2*e.seasonalitySamples} samples of warm-up. History window controls quality diagnostics, not harmonic memory. Saved Recommended profiles are unchanged.`:"level_shift"===e.algorithm?`It focuses on sustained baseline shifts over the last ${e.baselineWindow} buckets.`:"seasonal"===e.algorithm?`It compares each point with similar historical positions using ${ye[e.seasonalRefinement].toLowerCase()} refinement and ${e.seasonalitySamples} seasonal samples.`:"ewma"===e.algorithm?`It keeps a moving baseline over ${e.baselineWindow} buckets and reacts when the live metric keeps pulling away from that baseline.`:"mad"===e.algorithm?`It uses a robust median-based spread over ${e.baselineWindow} buckets so noisy data does not create too many false alarms.`:`It compares each point with a rolling average over ${e.baselineWindow} buckets.`,r=t?`Dense data is first summarized into ${a} buckets so the panel stays fast.`:"Incoming samples are scored directly for maximum detail.",s="high_mean"===e.anomalyDirection?"Only values above the learned mean may become anomalies.":"low_mean"===e.anomalyDirection?"Only values below the learned mean may become anomalies.":"Both upward and downward deviations may become anomalies.",o=e.recoveryThreshold>0?e.recoveryThreshold:e.sensitivity;return`${i} ${n} ${s} ${e.persistenceBuckets} of the latest ${e.persistenceWindow} buckets open an incident. It closes after ${e.recoveryBuckets} consecutive buckets below ${o.toFixed(2)} and then waits ${e.cooldownBuckets} cooldown buckets. Current threshold is ${e.sensitivity.toFixed(2)}. ${r}`})(q,Z),ii=It?((e,t)=>{const a=xe[e.confidenceLabel].replace("confidence","signal confidence"),i=ke[e.dataQualityLabel].toLowerCase();if("event"===e.kind)return`${e.activeSeries} metric agreed on this combined anomaly. Strongest reason: ${e.breakdown[0]?He(e.breakdown[0].scoreDriver,t):"Cross-metric deviation"}. ${a}, data quality is ${i}.`;const n=He(e.scoreDriver,t),r=null===e.deviation?"moved away from baseline":e.deviation>0?"moved above its baseline":e.deviation<0?"fell below its baseline":"stayed close to its baseline";return`${e.seriesLabel} ${r}. Main reason: ${n}. ${a}, data quality is ${i}.`})(It,q.algorithm):"",ni=((e,t)=>JSON.stringify(e.map(e=>({time:e.time,text:e.title,tags:dt(["anomaly-detector",e.severityLabel,e.confidenceLabel,e.dataQualityLabel,t]),detail:e.detail,raw_score:e.score,alarm_score_0_100:e.severityScore,alarm_severity:e.severityLabel,confidence_score:e.confidenceScore,confidence_label:e.confidenceLabel,data_quality:e.dataQualityLabel})),null,2))(Fe,ti),ri=ft(Se.registered),si=mt(q.severityPreset),oi=(null==G?void 0:G.folderTitle)||Ht(),li=(null==G?void 0:G.panelTitle)||j,ci=(null==G?void 0:G.dashboardTitle)||jt()||"Grafana dashboard",di=bt(null!==(p=null===(F=Se.registered[0])||void 0===F?void 0:F.target)&&void 0!==p?p:t.scoreFeedTarget),mi=((e,t,a)=>{const i=e.trim();let n=t.trim();return i&&n.toLowerCase().endsWith(` - ${i}`.toLowerCase())&&(n=n.slice(0,n.length-i.length-3).trim()),[i,n,a.trim()].filter((e,t,a)=>e.length>0&&a.findIndex(t=>t===e)===t).join(" - ")})(oi,ci,li)||li,ui=((e,t,a)=>({alert_family:"anomaly_detector",severity:"major",dashboard_uid:e||"unsaved_dashboard",panel_id:t>0?String(t):"unknown_panel",score_target:bt(a)}))(H,null!=e?e:0,di),pi=(gi={dashboardUid:H,folderTitle:oi,dashboardTitle:ci,panelId:null!=e?e:0,panelTitle:li,ruleName:mi},{summary:(hi=It)?hi.title:gi.ruleName,description:xt(hi,gi.panelTitle),folder_title:null!==(fi=gi.folderTitle)&&void 0!==fi?fi:"",dashboard_title:gi.dashboardTitle,panel_title:gi.panelTitle,__dashboardUid__:gi.dashboardUid,__panelId__:gi.panelId>0?String(gi.panelId):""});var hi,gi,fi;const yi={dashboardUid:H,folderTitle:oi,dashboardTitle:ci,panelId:null!=e?e:0,panelTitle:li,ruleName:mi,queryLanguage:Ut,alertQuery:ri,threshold:si,target:di,labels:ui,annotations:pi},vi=ut(ui),bi=((e,t,a,i,n)=>{var r;const s=mt(t.severityPreset),o=ft(i),l=yt(i);return JSON.stringify({title:n.ruleName,folder_name:null!==(r=n.folderTitle)&&void 0!==r?r:"",dashboard_name:n.dashboardTitle,dashboard_uid:n.dashboardUid,panel_title:n.panelTitle,panel_id:n.panelId,score_feed_ready:i.length>0,paste_into:`Grafana Alerting query editor (${l})`,query_language:l,alert_query:o||"Sync anomaly score feed first to generate an alert-ready score query.",grafana_condition:o?`WHEN QUERY IS ABOVE ${s}`:"Sync anomaly score feed first",for:"10m",evaluate_every:"3m",no_data_state:"Alerting",exec_err_state:"Error",threshold:s,suggested_labels:n.labels,suggested_label_pairs:ut(n.labels),suggested_annotations:n.annotations,synced_rules:i.map(e=>{var t,a,i,n;return{rule:e.rule,target:null!==(t=e.target)&&void 0!==t?t:"prometheus",query_language:null!==(a=e.queryLanguage)&&void 0!==a?a:l,datasource_type:null!==(i=e.datasourceType)&&void 0!==i?i:"",query:e.query,per_series_query:e.perSeriesQuery,query_variants:null!==(n=e.queryVariants)&&void 0!==n?n:[]}}),rule_scope:i.length>1?"Combined max across synced panel rules":"Single synced panel rule",mode:t.detectionMode,algorithm:t.algorithm,bucket_span:a,history_window:t.baselineWindow,severity_preset:t.severityPreset,selected_severity:e?e.severityLabel:"normal",selected_score:e?e.score:0,selected_raw_score:e?e.score:0,selected_alarm_score_0_100:e?e.severityScore:0,selected_alarm_severity:e?e.severityLabel:"normal",score_scale_note:"Alert queries use the normalized 0-100 alarm score, not the raw detection score.",selected_confidence:e?e.confidenceLabel:"low",selected_confidence_score:e?e.confidenceScore:0,selected_data_quality:e?e.dataQualityLabel:"thin",guidance:e?Ue(e,t.severityPreset):"Select an anomaly to generate a focused alert draft."},null,2)})(It,q,ti,Se.registered,yi),wi=kt(It,null!=e?e:0,H,ti),xi=wi?JSON.stringify(wi,null,2):"",Ei=It?Math.max(1,Fe.findIndex(e=>ze(e.selection)===_t)+1):0,ki="point"===(null==It?void 0:It.kind)?It.seriesLabel:"event"===(null==It?void 0:It.kind)?It.contributors.slice(0,2).join(", ")||`${It.activeSeries} active series`:null!==(v=null===(M=J[0])||void 0===M?void 0:M.label)&&void 0!==v?v:"n/a",Si="point"===(null==It?void 0:It.kind)?$e(It.actual):"event"===(null==It?void 0:It.kind)?`${It.activeSeries} active`:"n/a",Fi="point"===(null==It?void 0:It.kind)?$e(It.expected):"event"===(null==It?void 0:It.kind)?`${It.breakdown.length} contributors`:"n/a",Mi="point"===(null==It?void 0:It.kind)?null!==It.deviationPercent?Ce(It.deviationPercent):$e(It.deviation):"event"===(null==It?void 0:It.kind)?$e(It.score):"n/a",$i=It?$e(It.score):"n/a",Ni=It?`${be[It.severityLabel]} ${It.severityScore}`:"n/a",Ci=It?xe[It.confidenceLabel]:"n/a",Ai=It?`${Ne(It.confidenceScore)}%`:"n/a",Li=It?"healthy"===It.dataQualityLabel?"Good":ke[It.dataQualityLabel].replace(" data",""):"n/a",Bi=It?ke[It.dataQualityLabel]:"Not evaluated",Di=(null===($=K[0])||void 0===$?void 0:$.datasourceType)?K[0].datasourceType.charAt(0).toUpperCase()+K[0].datasourceType.slice(1):Ct[bt(t.scoreFeedTarget)],Ti=oe.trim().toLocaleLowerCase(),Pi=[...J].filter(e=>!Ti||e.label.toLocaleLowerCase().includes(Ti)).sort((e,t)=>{if("name"===me)return e.label.localeCompare(t.label);if("score"===me)return t.maxSeverityScore-e.maxSeverityScore||t.anomalyCount-e.anomalyCount;if("last"===me){var a,i,n,r;const s=null!==(a=null===(n=e.allPoints[e.allPoints.length-1])||void 0===n?void 0:n.value)&&void 0!==a?a:Number.NEGATIVE_INFINITY;return(null!==(i=null===(r=t.allPoints[t.allPoints.length-1])||void 0===r?void 0:r.value)&&void 0!==i?i:Number.NEGATIVE_INFINITY)-s||e.label.localeCompare(t.label)}return t.anomalyCount-e.anomalyCount||t.maxSeverityScore-e.maxSeverityScore||e.label.localeCompare(t.label)}),_i=It?{x:_a(It.bucketStart),height:Math.max(24,Ja-Da.top),width:It.bucketEnd>It.bucketStart?Math.max(_a(It.bucketEnd)-_a(It.bucketStart),10):12}:null,Ri=Ua.map(e=>{const t=_a(e.bucketStart),a=(e.bucketEnd>e.bucketStart?_a(e.bucketEnd):t)-t,i=Math.max(10,Math.min(Ta/80,20)),n=Math.max(10,Math.min(Number.isFinite(a)&&a>0?a:i,24)),r=a>0?t:_a(e.time)-n/2,s=Math.max(Da.left+2,Math.min(r,La-Da.right-n-2));return{event:e,x:s,width:n,centerX:s+n/2}}),Ii=`anomaly-plot-${null!=e?e:"panel"}-${q.detectionMode}`,Vi=C.isDark?"#CBD5E1":"#334155",qi=C.isDark?"#0B1628":"#F8FAFC",Oi=C.isDark?"#0F1C2D":"#FFFFFF",zi=Ot?_a(Ot.time):null,Wi=null===zi?0:Math.max(16,Math.min(zi+18,La-290)),ji=null!==zi&&zi>.62*La,Hi=null===zi?void 0:{left:ji?void 0:Wi,right:ji?Math.max(14,La-zi+14):void 0},Ui=g().createElement("aside",{className:A.inspectorCard,"aria-label":"Anomaly inspector"},g().createElement("div",{className:A.inspectorTop},g().createElement("div",{className:A.inspectorTitle},"Anomaly inspector"),g().createElement("button",{type:"button",className:A.inspectorClose,"aria-label":"Inspector is pinned in this panel"},"x")),It?g().createElement(g().Fragment,null,g().createElement("div",{className:A.inspectorTimestamp},g().createElement("span",null,_e(It.time,va,s)),g().createElement("span",{"aria-hidden":"true"},"•"),g().createElement("span",{style:{color:we[It.severityLabel]}},be[It.severityLabel])),g().createElement("div",{className:A.inspectorRows},g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Series"),g().createElement("span",{className:A.inspectorRowValue},Be(ki,34))),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Value"),g().createElement("span",{className:A.inspectorRowValue},Si)),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Expected"),g().createElement("span",{className:A.inspectorRowValue},Fi)),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Deviation"),g().createElement("span",{className:A.inspectorRowValue},Mi)),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Raw detection score"),g().createElement("span",{className:A.inspectorRowValue},$i)),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Alert score (0-100)"),g().createElement("span",{className:A.inspectorRowValue,style:{color:we[It.severityLabel]}},Ni)),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Bucket"),g().createElement("span",{className:A.inspectorRowValue},ti)),g().createElement("div",{className:A.inspectorRow},g().createElement("span",{className:A.inspectorRowLabel},"Incident"),g().createElement("span",{className:A.inspectorRowValue},Ei," of ",Math.max(Fe.length,Ei)))),g().createElement("div",null,g().createElement("div",{className:A.inspectorSectionTitle},"Why is this anomalous?"),g().createElement("div",{className:A.recommendationText,style:{marginTop:10}},ii)),g().createElement("div",{className:A.inspectorRows},g().createElement("div",{className:A.inspectorHealthRow},g().createElement("span",{className:A.inspectorRowLabel},"Confidence"),g().createElement("span",null,g().createElement("span",{className:A.inspectorPill,style:{background:`${Ee[It.confidenceLabel]}33`,color:Ee[It.confidenceLabel]}},Ci),g().createElement("span",{className:A.inspectorRowValue,style:{marginLeft:10}},Ai))),g().createElement("div",{className:A.inspectorHealthRow},g().createElement("span",{className:A.inspectorRowLabel},"Data quality"),g().createElement("span",null,g().createElement("span",{className:A.inspectorPill,style:{background:"rgba(34,197,94,0.24)",color:"#86EFAC"}},Li),g().createElement("span",{className:A.inspectorRowValue,style:{marginLeft:10}},Bi)))),g().createElement("div",null,g().createElement("div",{className:A.inspectorSectionTitle},"Rule labels"),g().createElement("div",{className:A.labelChipGrid,style:{marginTop:10}},Object.entries(ui).map(([e,t])=>g().createElement("span",{key:e,className:A.labelChip,title:`${e}=${t}`},g().createElement("span",{className:A.labelChipKey},e),g().createElement("span",null,"="),g().createElement("span",{className:A.labelChipValue},t))))),g().createElement("div",{className:A.inspectorActionStack},g().createElement("button",{type:"button",className:`${A.actionButton} ${A.inspectorActionButton} ${A.inspectorActionButtonPrimary}`,disabled:!ri,onClick:()=>{if(!ri)return void Je({tone:"error",message:"Sync anomaly score feed first to generate the alert query."});const e=ht(yi);Je({tone:"success",message:e?"Opened Grafana alert rule builder. Copying the alert query to your clipboard.":"Copying the alert query. If the builder did not open, use Alerting > Alert rules > New alert rule."}),St(ri).then(()=>Je({tone:"success",message:e?"Opened Grafana alert rule builder and copied the alert query.":"Copied the alert query. If the builder did not open, use Alerting > Alert rules > New alert rule."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."}))}},"Open alert rule builder"),g().createElement("button",{type:"button",className:`${A.actionButtonSecondary} ${A.inspectorActionButton} ${A.inspectorActionButtonSecondary}`,disabled:!vi,onClick:()=>{St(vi).then(()=>Je({tone:"success",message:"Copied suggested alert labels."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy alert labels."}))}},"Copy rule labels"),g().createElement("button",{type:"button",className:`${A.actionButtonSecondary} ${A.inspectorActionButton} ${A.inspectorActionButtonSecondary}`,disabled:!wi||!H,onClick:()=>{wi?H?Mt(wi).then(()=>Je({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):Je({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):Je({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),g().createElement("button",{type:"button",className:`${A.actionButtonSecondary} ${A.inspectorActionButton} ${A.inspectorActionButtonSecondary}`,disabled:!ri,onClick:()=>{ri?St(ri).then(()=>Je({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):Je({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query")),g().createElement("div",null,g().createElement("div",{className:A.inspectorSectionTitle},"Query preview"),g().createElement("pre",{className:A.queryPreview},ri||`Sync the score feed to generate ${Ut}.`))):g().createElement("div",{className:A.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."));return g().createElement("div",{className:A.wrapper},W,g().createElement("div",{className:A.operationalCanvas,style:te({gridTemplateColumns:O.inspector?void 0:"minmax(0, 1fr)"},Na?{height:"100%",minHeight:0}:{})},g().createElement("main",{className:A.workspacePane},Sa?g().createElement("div",{className:A.statusHeader,style:{gridTemplateColumns:O.initialLabels&&O.statistics?void 0:"minmax(0, 1fr)"}},O.initialLabels?g().createElement(g().Fragment,null,g().createElement("div",{className:A.statusRail,style:{background:ka}}),g().createElement("div",{className:A.statusIcon,"aria-hidden":"true"},g().createElement("svg",{className:A.statusIconSvg,viewBox:"0 0 24 24","aria-hidden":"true",focusable:"false"},g().createElement("path",{d:"M2.5 12h4.1l2.1-5.7 3.9 11.4 2.1-5.7h6.8",fill:"none",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),g().createElement("circle",{cx:"12",cy:"12",r:"10",fill:"none",stroke:"currentColor",strokeOpacity:"0.28",strokeWidth:"1.4"}))),g().createElement("div",{className:A.statusMain},g().createElement("div",{className:A.title,role:"heading","aria-level":2},"Anomaly Detector"),g().createElement("div",{className:A.headerMetaGrid},g().createElement("span",null,"Algorithm: ",g().createElement("span",{className:A.metaAccent},q.algorithm)),g().createElement("span",null,"Direction: ",g().createElement("span",{className:A.metaAccent},q.anomalyDirection.replaceAll("_"," "))),g().createElement("span",null,"Bucket: ",ti),g().createElement("span",null,"Series: ",Be(ki,34)),g().createElement("span",null,"Datasource: ",Di)),R?g().createElement("div",{className:A.staleBanner},"Showing the last good snapshot while Grafana refreshes the query result."):null)):null,O.statistics?g().createElement("div",{className:A.statusStats},g().createElement("div",{className:`${A.statCard} ${A.statCardPrimary}`,style:{borderColor:`${ka}99`,background:`linear-gradient(145deg, ${ka}E6 0%, ${ka}88 100%)`}},g().createElement("div",{className:A.statLabel},"Severity"),g().createElement("div",{className:A.statValue},be[da.severityLabel]),g().createElement("div",{className:A.statCaption},It?`Since ${_e(It.time,va,s)}`:`Peak ${Ne(ca)}`)),g().createElement("div",{className:A.statCard},g().createElement("div",{className:A.statLabel},"Confidence"),g().createElement("div",{className:A.statValue},Ai),g().createElement("div",{className:A.statCaption},Ci)),g().createElement("div",{className:A.statCard,role:"status","aria-live":"polite","aria-atomic":"true"},g().createElement("div",{className:A.statLabel},"Anomalies"),g().createElement("div",{className:A.statValue},oa),g().createElement("div",{className:A.statCaption},"clustered")),g().createElement("div",{className:A.statCard},g().createElement("div",{className:A.statLabel},"Data quality"),g().createElement("div",{className:A.statValue,style:{color:"#4ADE80"}},Li),g().createElement("div",{className:A.statCaption},Bi))):null):null,O.initialLabels?g().createElement("div",{className:A.recommendationBanner},g().createElement("div",{className:A.recommendationBadge},q.recommendation.badge),g().createElement("div",{className:A.recommendationCopy},g().createElement("div",{className:A.recommendationTitle},q.recommendation.title),g().createElement("div",{className:A.recommendationText},q.recommendation.reason,q.recommendation.matchedNames.length>0?` Matched metrics: ${q.recommendation.matchedNames.slice(0,3).join(", ")}.`:""))):null,Ke?g().createElement("div",{className:A.actionNotice},g().createElement("span",{className:A.recommendationBadge,style:{background:"success"===Ke.tone?`${we.low}22`:`${we.critical}22`,color:"success"===Ke.tone?we.low:we.critical}},"success"===Ke.tone?"Action complete":"Action needed"),g().createElement("div",{className:A.recommendationCopy},g().createElement("div",{className:A.recommendationTitle},"success"===Ke.tone?"Ready to continue":"Could not finish action"),g().createElement("div",{className:A.recommendationText},Ke.message))):null,O.anomalyFeed?g().createElement(g().Fragment,null,g().createElement("div",{className:A.incidentHeader},g().createElement("div",{className:A.cardTitle,role:"heading","aria-level":3},"Detected incidents"),g().createElement("div",{className:A.severityLegend,"aria-label":"Incident severity legend"},["critical","high","medium","low"].map(e=>g().createElement("span",{key:e,className:A.severityLegendItem},g().createElement("span",{className:A.severityLegendSwatch,style:{background:we[e]}}),be[e])))),Ga.length>0?g().createElement("div",{className:A.incidentRibbonPanel,"aria-label":"Detected incident overview"},g().createElement("svg",{width:"100%",height:"34",viewBox:`0 0 ${La} 34`,preserveAspectRatio:"none",role:"img","aria-label":"Detected incident overview"},g().createElement("rect",{x:Da.left,y:11,width:Ta,height:12,rx:6,fill:C.isDark?"#252C38":"#E2E8F0",opacity:.88}),Ga.map(e=>{const t=Math.max(Da.left,_a(e.start)),a=Math.min(La-Da.right,_a(e.end)),i=Math.max(8,a-t),n=ze(Dt)===ze(e.selection),r=we[e.severityLabel];return g().createElement("g",{key:`overview-${e.key}`,style:{cursor:"pointer"},onClick:()=>{qe(e.selection),Ye(e.center),Qe(e.center)}},g().createElement("title",null,`${e.label} | ${be[e.severityLabel]} ${e.severityScore} | ${_e(e.center,va,s)}`),g().createElement("rect",{x:t,y:11,width:i,height:12,rx:6,fill:r,fillOpacity:n?1:.82,stroke:n?C.isDark?"#F8FAFC":"#0F172A":"none",strokeWidth:n?1.2:0}),e.count>1&&i>=28?g().createElement("g",null,g().createElement("rect",{x:t+i/2-13,y:2,width:26,height:18,rx:8,fill:r,stroke:C.isDark?"#7F1D1D":"#FFFFFF",strokeWidth:1}),g().createElement("text",{x:t+i/2,y:15,textAnchor:"middle",fill:"#FFFFFF",fontSize:"10",fontWeight:"900",pointerEvents:"none"},"x",e.count)):null)}))):g().createElement("div",{className:A.incidentRibbonPanel,"aria-label":"Detected incident overview"},g().createElement("div",{className:A.incidentRibbonEmpty},"No clustered incidents in this time range."))):null,O.mainChart?g().createElement("div",{className:A.chartCard,style:Na?{minHeight:0,height:"100%"}:void 0,ref:Ft,tabIndex:0,onKeyDown:e=>{if((e=>e instanceof HTMLElement&&(["BUTTON","INPUT","TEXTAREA","SELECT","A"].includes(e.tagName)||e.isContentEditable))(e.target)||0===Pt.length)return;const t=Pt.findIndex(e=>ze(e.selection)===_t),a=t>=0?t:0;if("ArrowRight"===e.key||"ArrowDown"===e.key){e.preventDefault();const t=Pt[(a+1)%Pt.length];return void Rt(t)}if("ArrowLeft"===e.key||"ArrowUp"===e.key){e.preventDefault();const t=Pt[(a-1+Pt.length)%Pt.length];return void Rt(t)}if("Enter"===e.key||" "===e.key){const t=Pt[a];if(!t)return;return e.preventDefault(),Ye(e=>e===t.time?null:t.time),void Qe(t.time)}"Escape"===e.key&&(e.preventDefault(),Ye(null),Qe(null))},"aria-label":"Anomaly chart. Use left and right arrows to move between incidents, Enter to pin, and Escape to clear."},g().createElement("svg",{width:"100%",height:"100%",viewBox:`0 0 ${La} ${Ba}`,preserveAspectRatio:"none",role:"img","aria-label":"Anomaly chart",onMouseMove:e=>{const t=e.currentTarget.getBoundingClientRect(),a=(e.clientX-t.left)/t.width*La;if(a<Da.left||a>La-Da.right)return void(null===Ge&&Qe(null));const i=(e=>{if(ga===ha)return ha;const t=Math.max(0,Math.min(1,(e-Da.left)/Ta));return ha+t*(ga-ha)})(a),n=st(ua,i);Qe(n>=0?ua[n]:null)},onMouseLeave:()=>{null===Ge&&Qe(null)},onClick:()=>{Ot&&Ye(e=>e===Ot.time?null:Ot.time)},style:{width:"100%",height:"100%",display:"block",cursor:"crosshair"}},g().createElement("defs",null,g().createElement("clipPath",{id:Ii},g().createElement("rect",{x:Da.left,y:Da.top,width:Ta,height:Pa,rx:12}))),g().createElement("rect",{x:0,y:0,width:La,height:Ba,fill:C.isDark?"#08111F":"#FFFFFF"}),g().createElement("rect",{x:8,y:Da.top-8,width:Da.left-16,height:Pa+16,rx:16,fill:qi,opacity:.96}),g().createElement("text",{transform:`translate(22 ${Da.top+Pa/2}) rotate(-90)`,textAnchor:"middle",fill:Vi,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"VALUE"),g().createElement("text",{"data-axis":"time-caption",x:La-Da.right,y:Ba-8,textAnchor:"end",fill:Vi,fontSize:"11",fontWeight:"700",letterSpacing:"0.08em"},"TIME (",Ea,")"),Wa.map((e,t)=>{const a=_a(e),i=0===t?"start":t===Wa.length-1?"end":"middle";return g().createElement("g",{key:`top-x-${t}`},g().createElement("text",{x:a,y:Da.top-10,textAnchor:i,fill:C.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},((e,t,a)=>t<=2592e5?(0,c.dateTimeFormat)(e,{format:"ddd DD/MM",timeZone:a}):(0,c.dateTimeFormat)(e,{format:"DD/MM/YYYY",timeZone:a}))(e,va,s)))}),_i?g().createElement("rect",{x:Math.max(Da.left,_i.x),y:Da.top,width:Math.min(_i.width,Ta),height:_i.height,fill:C.isDark?"rgba(59,130,246,0.10)":"rgba(37,99,235,0.08)",stroke:C.isDark?"rgba(96,165,250,0.35)":"rgba(37,99,235,0.25)",rx:8}):null,g().createElement("rect",{x:Da.left,y:Da.top,width:Ta,height:Pa,rx:12,fill:C.isDark?"#06101E":"#FFFFFF",stroke:C.isDark?"#142033":"#E2E8F0"}),ja.map((e,t)=>{const a=Ra(e);return g().createElement("g",{key:`y-${t}`},g().createElement("line",{x1:Da.left,y1:a,x2:La-Da.right,y2:a,stroke:C.isDark?"#1E293B":"#E2E8F0",strokeOpacity:.78,strokeDasharray:"3 6"}),g().createElement("rect",{x:14,y:a-10,width:Da.left-28,height:20,rx:10,fill:Oi,opacity:C.isDark?.84:.96}),g().createElement("text",{x:Da.left-18,y:a+4,textAnchor:"end",fill:C.isDark?"#E2E8F0":"#0F172A",fontSize:"12",fontWeight:"700"},(e=>{if(!Number.isFinite(e))return"";const t=Math.abs(e);return t>=1e3?e.toLocaleString(void 0,{notation:"compact",maximumFractionDigits:1}):t>=100?e.toLocaleString(void 0,{maximumFractionDigits:0}):t>=10?e.toLocaleString(void 0,{maximumFractionDigits:1}):t>=1?e.toLocaleString(void 0,{maximumFractionDigits:2}):e.toLocaleString(void 0,{maximumFractionDigits:3})})(e)))}),za.map((e,t)=>{const a=_a(e),i=0===t?"start":t===za.length-1?"end":"middle";return g().createElement("g",{key:`x-${t}`},t>0&&t<za.length-1?g().createElement("line",{x1:a,y1:Da.top,x2:a,y2:Ba-Da.bottom,stroke:C.isDark?"#162336":"#E2E8F0",strokeOpacity:.45}):null,g().createElement("text",{"data-axis":"time-tick",x:a,y:Ba-28,textAnchor:i,fill:C.isDark?"#94A3B8":"#64748B",fontSize:"11"},Pe(e,va,q.timeAxisDensity,s)))}),null!==zi?g().createElement("g",{pointerEvents:"none"},g().createElement("line",{x1:zi,y1:Da.top,x2:zi,y2:Ja,stroke:C.isDark?"#93C5FD":"#2563EB",strokeDasharray:"5 5",strokeOpacity:.72,strokeWidth:1.35}),g().createElement("rect",{x:Math.max(Da.left+6,Math.min(zi-52,La-Da.right-104)),y:Da.top+24,width:104,height:20,rx:10,fill:C.isDark?"#0F172A":"#FFFFFF",stroke:C.isDark?"#334155":"#CBD5E1"}),g().createElement("text",{x:Math.max(Da.left+58,Math.min(zi,La-Da.right-52)),y:Da.top+38,textAnchor:"middle",fill:C.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},Pe(null!==(b=null==Ot?void 0:Ot.time)&&void 0!==b?b:ha,va,"dense",s))):null,"multi"===q.detectionMode&&Ri.length>0?g().createElement("g",null,Ri.map(({event:e,x:t,width:a,centerX:i})=>{const n="event"===(null==Dt?void 0:Dt.kind)&&Dt.time===e.time,r=we[e.severityLabel],s=Re(e.severityLabel,q.markerShapeMode),o="high"===e.confidenceLabel?.18:"medium"===e.confidenceLabel?.12:.08,l=Da.top+18;return g().createElement("g",{key:`event-${e.time}`,style:{cursor:"pointer"},onClick:()=>{qe({kind:"event",time:e.time}),Ye(e.time)}},g().createElement("title",null,`Combined anomaly at ${Ae(e.time)} | Score ${$e(e.score)} | ${be[e.severityLabel]} | ${xe[e.confidenceLabel]}`),g().createElement("rect",{x:t,y:Da.top+1,width:a,height:Pa-2,rx:n?10:8,fill:r,fillOpacity:n?.18:o}),g().createElement("rect",{x:t,y:Da.top+4,width:a,height:4,rx:2,fill:r,fillOpacity:n?.95:"high"===e.confidenceLabel?.8:.62}),g().createElement("rect",{x:t,y:Da.top+Pa-6,width:a,height:3,rx:1.5,fill:r,fillOpacity:n?.9:"high"===e.confidenceLabel?.72:.5}),g().createElement("line",{x1:i,y1:l+8,x2:i,y2:Ja-8,stroke:r,strokeOpacity:n?.74:.38,strokeWidth:n?1.8:1.25,strokeDasharray:"4 5"}),Ve(s,i,l,n?7.5:6.2,C.isDark?"#08111F":"#FFFFFF",r,n?2.8:2.2),Ve(s,i,l,n?3:2.5,r))})):null,g().createElement("g",{clipPath:`url(#${Ii})`},pe.map(e=>{const a=!1===t.showBands?"":((e,t,a)=>{const i=e.filter(e=>null!==e.lower&&null!==e.upper);if(i.length<2)return"";const n=i.map(e=>`${t(e.time).toFixed(2)},${a(e.upper).toFixed(2)}`),r=[...i].reverse().map(e=>`${t(e.time).toFixed(2)},${a(e.lower).toFixed(2)}`);return`M${n.join(" L")} L${r.join(" L")} Z`})(e.points,_a,Ra),i=it(e.points,_a,Ra,e=>e.value),n=q.showExpectedLine?it(e.points,_a,Ra,e=>e.expected):"",r="point"===(null==Dt?void 0:Dt.kind)&&Dt.seriesKey===e.key?Dt.time:null,s=q.markerShapeMode,o=Math.max(54,Ta/12),l=Math.max(12,Ta/44),c="multi"===q.detectionMode?[]:ot(rt(e.points.filter(e=>e.isAnomaly),_a,Za?o:l,r),Za?2:8,r);return g().createElement("g",{key:e.key},a?g().createElement("path",{d:a,fill:e.color,opacity:It&&"point"===It.kind&&It.seriesKey===e.key?.14:.07}):null,n?g().createElement("path",{d:n,fill:"none",stroke:e.color,strokeOpacity:.32,strokeWidth:1.3,strokeDasharray:"6 6"}):null,g().createElement("path",{d:i,fill:"none",stroke:e.color,strokeWidth:2.6,strokeLinecap:"round",strokeLinejoin:"round"}),c.map(t=>{const a="point"===(null==Dt?void 0:Dt.kind)&&Dt.seriesKey===e.key&&Dt.time===t.time,i=_a(t.time),n=Ra(t.value),r=Re(t.severityLabel,s),o=a?11:"high"===t.confidenceLabel?8.4:"medium"===t.confidenceLabel?7.4:6.2;return g().createElement("g",{key:`${e.key}-${t.time}`,style:{cursor:"pointer"},onClick:()=>{qe({kind:"point",seriesKey:e.key,time:t.time}),Ye(t.time)}},g().createElement("title",null,`${e.label} | ${Ae(t.time)} | ${be[t.severityLabel]} | ${xe[t.confidenceLabel]}`),g().createElement("line",{x1:i,y1:Da.top+18,x2:i,y2:Math.max(Da.top+26,n-10),stroke:we[t.severityLabel],strokeOpacity:a?.72:.3,strokeWidth:a?1.7:1.2,strokeDasharray:"4 5"}),g().createElement("circle",{cx:i,cy:n,r:o,fill:Ee[t.confidenceLabel],opacity:a?.28:.18}),Ve(r,i,n,a?7.2:5.4,C.isDark?"#111827":"#FFFFFF",we[t.severityLabel],a?2.8:2.4),Ve(r,i,n,a?3.2:2.6,we[t.severityLabel],void 0,0,"high"===t.confidenceLabel?.96:.8),g().createElement("circle",{cx:i,cy:n,r:11,fill:"transparent"}))}))})),ei.map(e=>{const t=Math.max(Da.left+8,e.anchorX-e.width),a=t-8;return g().createElement("g",{key:`inline-${e.key}`},g().createElement("line",{x1:e.lastX,y1:e.lastY,x2:a,y2:e.labelY,stroke:e.color,strokeOpacity:.78,strokeWidth:1.4}),g().createElement("rect",{x:t,y:e.labelY-11,width:e.width,height:22,rx:11,fill:C.isDark?"#0F172A":"#FFFFFF",stroke:e.color,strokeOpacity:.48}),g().createElement("circle",{cx:t+11,cy:e.labelY,r:3,fill:e.color}),g().createElement("text",{x:t+19,y:e.labelY+4,fill:C.isDark?"#E2E8F0":"#0F172A",fontSize:"11",fontWeight:"700"},e.label))}),Qa?(()=>{const e=Da.left+14,t=Math.max(Ta-28,48),a=Ka,i=Math.max(Ya-28,18),n=Qa.minValue,r=Qa.maxValue,o=Math.max(r-n,1e-6),l=a=>e+(a-Qa.startTime)/Math.max(Qa.endTime-Qa.startTime,1)*t,c=e=>a+18+i-(e-n)/o*i,d=l(Qa.bucketStart),m=l(Math.max(Qa.bucketEnd,Qa.selectedTime));return g().createElement("g",null,g().createElement("rect",{x:Da.left+6,y:a,width:Ta-12,height:Ya,rx:14,fill:C.isDark?"rgba(8,17,31,0.92)":"rgba(255,255,255,0.94)",stroke:C.isDark?"#1E293B":"#D7E3F4"}),g().createElement("text",{x:e,y:a+14,fill:C.isDark?"#CBD5E1":"#334155",fontSize:"10",fontWeight:"700",letterSpacing:"0.08em"},"FOCUSED ANOMALY WINDOW"),g().createElement("text",{x:La-Da.right-8,y:a+14,textAnchor:"end",fill:C.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Qa.title),g().createElement("rect",{x:Math.min(d,m),y:a+18,width:Math.max(Math.abs(m-d),8),height:i,rx:8,fill:C.isDark?"rgba(59,130,246,0.14)":"rgba(37,99,235,0.10)",stroke:C.isDark?"rgba(96,165,250,0.28)":"rgba(37,99,235,0.22)"}),Qa.series.map(e=>{const t=it(e.points,l,c,e=>e.value);return g().createElement("path",{key:`focus-${e.key}`,d:t,fill:"none",stroke:e.color,strokeWidth:1.8,strokeOpacity:"point"===(null==Dt?void 0:Dt.kind)&&Dt.seriesKey===e.key?1:.78,strokeLinecap:"round",strokeLinejoin:"round"})}),g().createElement("line",{x1:l(Qa.selectedTime),y1:a+18,x2:l(Qa.selectedTime),y2:a+18+i,stroke:C.isDark?"#93C5FD":"#2563EB",strokeDasharray:"4 4",strokeWidth:1.4}),g().createElement("text",{x:e,y:a+Ya-8,fill:C.isDark?"#94A3B8":"#64748B",fontSize:"10"},Pe(Qa.startTime,Qa.endTime-Qa.startTime,"dense",s)),g().createElement("text",{x:l(Qa.selectedTime),y:a+Ya-8,textAnchor:"middle",fill:C.isDark?"#E2E8F0":"#0F172A",fontSize:"10",fontWeight:"700"},Pe(Qa.selectedTime,Qa.endTime-Qa.startTime,"dense",s)),g().createElement("text",{x:La-Da.right-8,y:a+Ya-8,textAnchor:"end",fill:C.isDark?"#94A3B8":"#64748B",fontSize:"10"},Pe(Qa.endTime,Qa.endTime-Qa.startTime,"dense",s)))})():null,g().createElement("rect",{x:Da.left,y:Da.top,width:Ta,height:Pa,rx:12,fill:"none",stroke:C.isDark?"#22314A":"#D7E3F4"})),Ot?g().createElement("div",{style:ae(te({position:"absolute",top:18},null!=Hi?Hi:{}),{width:272,pointerEvents:null!==Ge?"auto":"none",borderRadius:16,border:"1px solid "+(C.isDark?"#334155":"#CBD5E1"),background:C.isDark?"rgba(8,17,31,0.96)":"rgba(255,255,255,0.96)",boxShadow:C.isDark?"0 18px 42px rgba(2,6,23,0.42)":"0 18px 42px rgba(15,23,42,0.12)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,backdropFilter:"blur(8px)"})},g().createElement("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}},g().createElement("div",{style:{minWidth:0}},g().createElement("div",{style:{fontSize:12,fontWeight:800,color:C.isDark?"#F8FAFC":"#0F172A"}},_e(Ot.time,va,s)),g().createElement("div",{style:{fontSize:11,color:C.isDark?"#94A3B8":"#64748B"}},(null===(N=Ot.event)||void 0===N?void 0:N.isAnomaly)?`Cross-metric incident | ${Ot.event.activeSeries} aligned metric${1===Ot.event.activeSeries?"":"s"}`:Ot.anomalyCount>0?`${Ot.anomalyCount} flagged signal${1===Ot.anomalyCount?"":"s"} at this time`:"Live metric snapshot")),g().createElement("div",{style:{display:"flex",alignItems:"center",gap:8}},g().createElement("span",{style:{display:"inline-flex",alignItems:"center",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:800,background:`${we[Ot.severityLabel]}22`,color:we[Ot.severityLabel]}},be[Ot.severityLabel]," ",Ot.severityScore),null!==Ge?g().createElement("button",{type:"button",onClick:e=>{e.stopPropagation(),Ye(null)},style:{border:"1px solid "+(C.isDark?"#334155":"#CBD5E1"),background:C.isDark?"#0F172A":"#F8FAFC",color:C.isDark?"#E2E8F0":"#334155",borderRadius:999,padding:"4px 8px",fontSize:10,fontWeight:700,cursor:"pointer"}},"Unpin"):null)),g().createElement("div",{style:{display:"flex",flexDirection:"column",gap:6,maxHeight:240,overflowY:"auto"}},Ot.series.map(e=>g().createElement("div",{key:`tooltip-${e.key}`,style:{display:"grid",gridTemplateColumns:"minmax(0,1fr) auto auto",gap:8,alignItems:"center",padding:"6px 8px",borderRadius:12,background:C.isDark?"rgba(15,23,42,0.72)":"#F8FAFC",border:"1px solid "+(C.isDark?"#1E293B":"#E2E8F0")}},g().createElement("div",{style:{minWidth:0,display:"flex",alignItems:"center",gap:8}},g().createElement("span",{style:{width:8,height:8,borderRadius:999,background:e.color,flex:"0 0 auto"}}),g().createElement("span",{style:{fontSize:11,fontWeight:700,color:C.isDark?"#E2E8F0":"#0F172A",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},Be(e.label,24))),g().createElement("span",{style:{fontSize:11,fontWeight:700,color:C.isDark?"#F8FAFC":"#0F172A"}},$e(e.actual)),g().createElement("span",{style:{fontSize:10,fontWeight:700,color:e.isAnomaly?we[e.severityLabel]:C.isDark?"#94A3B8":"#64748B"}},e.isAnomaly?be[e.severityLabel]:"normal"))))):null):null,$a?g().createElement("div",{className:A.bottomDock,style:{gridTemplateColumns:O.seriesSummary&&O.scoreFeed&&na?void 0:"minmax(0, 1fr)"}},O.seriesSummary?g().createElement("div",{className:A.legendTable,"aria-label":"Series anomaly summary",style:{maxHeight:390,overflowY:"auto"}},sa>8?g().createElement("div",{className:A.legendToolbar},g().createElement("input",{className:A.legendControl,type:"search",value:oe,onChange:e=>ce(e.currentTarget.value),placeholder:`Search ${sa} series`,"aria-label":"Search series legend"}),g().createElement("select",{className:A.legendControl,value:me,onChange:e=>ue(e.currentTarget.value),"aria-label":"Sort series legend"},g().createElement("option",{value:"flagged"},"Most flagged"),g().createElement("option",{value:"score"},"Highest alert score"),g().createElement("option",{value:"last"},"Highest last value"),g().createElement("option",{value:"name"},"Series name"))):null,g().createElement("div",{className:A.legendTableHeader},g().createElement("span",null,"Series (",sa,")"),g().createElement("span",null,"Flagged"),g().createElement("span",null,"Max"),g().createElement("span",null,"Last")),Pi.map(e=>{var t;const a=null!==(t=e.allPoints[e.allPoints.length-1])&&void 0!==t?t:null;return g().createElement("button",{key:e.key,type:"button",className:A.legendTableRow,"aria-pressed":ne===e.key,title:`${e.label} | click to isolate; Ctrl/Cmd+click toggles visibility | ${e.anomalyCount} flagged buckets | max ${Ne(e.maxSeverityScore)}`,style:{opacity:ee.has(e.key)&&ne!==e.key?.42:1},onClick:t=>{if(t.ctrlKey||t.metaKey)return se(null),void ie(t=>{const a=new Set(t);return a.has(e.key)?a.delete(e.key):a.add(e.key),a});se(t=>t===e.key?null:e.key)}},g().createElement("span",{className:A.legendSeriesName},g().createElement("span",{className:A.legendSwatch,style:{background:e.color}}),g().createElement("span",{style:{minWidth:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},e.label)),g().createElement("span",{className:A.legendValue,style:{color:e.anomalyCount>0?we[e.maxSeverityLabel]:void 0}},e.anomalyCount),g().createElement("span",{className:A.legendValue},Ne(e.maxSeverityScore)),g().createElement("span",{className:A.legendValue},a?$e(a.value):"n/a"))}),0===Pi.length?g().createElement("div",{className:A.incidentRibbonEmpty},"No series match this search."):null,g().createElement("div",{className:A.legendTableFooter},g().createElement("span",null,ne?"1 series isolated":`${pe.length} of ${sa} visible${Ti?` · ${Pi.length} matched`:""}`),g().createElement("span",{style:{display:"flex",gap:6}},g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>{ie(new Set),se(null)}},"Show all"),g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>{ie(new Set(J.map(e=>e.key))),se(null)}},"Hide all")))):null,O.scoreFeed?na:null):null,Ma?g().createElement("div",{className:A.secondaryDock,style:{gridTemplateColumns:O.anomalyFeed&&Fa?void 0:"minmax(0, 1fr)"}},O.anomalyFeed?g().createElement(g().Fragment,null,g().createElement("div",{className:A.card},g().createElement("div",{className:A.cardTitle},"Detected incidents"),Pt.length>0?g().createElement("div",{className:A.summaryTimeline},g().createElement("div",{className:A.subtitle},"Incident timeline"),g().createElement("svg",{width:"100%",height:"56",viewBox:"0 0 320 56",role:"img","aria-label":"Incident timeline overview"},g().createElement("line",{x1:18,y1:28,x2:302,y2:28,stroke:C.isDark?"#22314A":"#CBD5E1",strokeWidth:4,strokeLinecap:"round"}),Pt.map((e,t)=>{const a=ga===ha?160:18+(e.time-ha)/Math.max(ga-ha,1)*284,i=ze(e.selection)===_t,n=Re(e.severityLabel,q.markerShapeMode);return g().createElement("g",{key:`summary-timeline-${e.key}`,style:{cursor:"pointer"},onClick:()=>Rt(e)},g().createElement("title",null,`${e.title} | ${_e(e.time,va,s)}`),g().createElement("line",{x1:a,y1:16,x2:a,y2:40,stroke:we[e.severityLabel],strokeOpacity:i?.85:.4,strokeWidth:i?2:1.3}),Ve(n,a,28,i?7:5.4,C.isDark?"#08111F":"#FFFFFF",we[e.severityLabel],i?2.5:2),i?g().createElement("circle",{cx:a,cy:28,r:10.5,fill:"none",stroke:C.isDark?"#E2E8F0":"#0F172A",strokeOpacity:.4,strokeWidth:1.3}):null,0===t?g().createElement("text",{x:a,y:50,textAnchor:a>250?"end":"start",fill:C.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Pe(e.time,va,"compact",s)):t===Pt.length-1&&Math.abs(e.time-Pt[0].time)/Math.max(ga-ha,1)*284>=64&&Pe(e.time,va,"compact",s)!==Pe(Pt[0].time,va,"compact",s)?g().createElement("text",{x:a,y:50,textAnchor:"end",fill:C.isDark?"#94A3B8":"#64748B",fontSize:"10",fontWeight:"700"},Pe(e.time,va,"compact",s)):null)}))):null,g().createElement("div",{className:A.summaryList},0===Fe.length?g().createElement("div",{className:A.subtitle},"No operationally relevant incidents crossed the active threshold in the selected time range."):Fe.map(e=>g().createElement("button",{key:e.key,type:"button","aria-label":`Detected incident ${e.title}`,className:`${A.summaryRow} ${_t===ze(e.selection)?A.summaryRowSelected:""}`,onClick:()=>Rt(e),style:{textAlign:"left",color:"inherit"}},g().createElement("div",{className:A.summaryMeta},g().createElement("span",{className:A.summaryTitle,title:e.title},e.title),g().createElement("span",{className:A.severityBadge,style:{background:`${we[e.severityLabel]}22`,color:we[e.severityLabel]}},be[e.severityLabel]," ",e.severityScore)),g().createElement("div",{className:A.subtitle},e.subtitle),g().createElement("div",{className:A.recommendationText},e.detail))))),g().createElement("div",{className:`${A.card} ${A.inlineInspectorLegacy}`},g().createElement("div",{className:A.cardTitle},"Legacy inspector details"),It?g().createElement(g().Fragment,null,g().createElement("div",{className:A.recommendationText},It.title),g().createElement("div",{className:A.subtitle},It.subtitle),g().createElement("div",{className:A.recommendationText},ii),g().createElement("div",{className:A.actionRow},g().createElement("button",{type:"button",className:A.actionButton,disabled:!wi||!H,onClick:()=>{wi?H?Mt(wi).then(()=>Je({tone:"success",message:"Created a Grafana annotation for the selected anomaly."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to create the Grafana annotation."})):Je({tone:"error",message:"Save the dashboard once before creating Grafana annotations from the panel."}):Je({tone:"error",message:"Select an anomaly first to create an annotation."})}},"Create annotation"),g().createElement("button",{type:"button",className:A.actionButtonSecondary,disabled:!ri,onClick:()=>{ri?St(ri).then(()=>Je({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):Je({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy alert query"),g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>{xi?St(xi).then(()=>Je({tone:"success",message:"Copied the selected anomaly annotation JSON."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation JSON."})):Je({tone:"error",message:"Select an anomaly first to copy its annotation JSON."})}},"Copy annotation JSON")),H?null:g().createElement("div",{className:A.subtitle},"Save the dashboard once so Grafana knows which dashboard the new annotation belongs to."),g().createElement("div",{className:A.detailGrid},g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Raw detection score"),g().createElement("div",{className:A.detailValue},$e(It.score))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Alert score (0-100)"),g().createElement("div",{className:A.detailValue,style:{color:we[It.severityLabel]}},be[It.severityLabel]," ",It.severityScore)),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Confidence"),g().createElement("div",{className:A.detailValue,style:{color:Ee[It.confidenceLabel]}},xe[It.confidenceLabel])),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Data quality"),g().createElement("div",{className:A.detailValue},ke[It.dataQualityLabel])),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Bucket span"),g().createElement("div",{className:A.detailValue},Le(It.bucketStart,It.bucketEnd))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Recommended action"),g().createElement("div",{className:A.detailValue},Ue(It,q.severityPreset)))),"point"===It.kind?g().createElement("div",{className:A.detailGrid},g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Current value"),g().createElement("div",{className:A.detailValue},$e(It.actual))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Expected value"),g().createElement("div",{className:A.detailValue},$e(It.expected))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Change"),g().createElement("div",{className:A.detailValue},$e(It.deviation))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Change %"),g().createElement("div",{className:A.detailValue},Ce(It.deviationPercent))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Expected range"),g().createElement("div",{className:A.detailValue},(Qi=It.rangeLower,Gi=It.rangeUpper,null===Qi||null===Gi?"n/a":`${$e(Qi)} - ${$e(Gi)}`))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Samples in bucket"),g().createElement("div",{className:A.detailValue},It.sampleCount)),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Instant signal"),g().createElement("div",{className:A.detailValue},$e(It.pointScore))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Sustained signal"),g().createElement("div",{className:A.detailValue},$e(It.windowScore))),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Main reason"),g().createElement("div",{className:A.detailValue},He(It.scoreDriver,q.algorithm)))):g().createElement("div",{className:A.metricBreakdownList},g().createElement("div",{className:A.subtitle},"Metric breakdown"),It.breakdown.map(e=>g().createElement("div",{key:e.label,className:A.metricBreakdownCard,style:{borderColor:C.isDark?`${e.color}55`:`${e.color}66`}},g().createElement("div",{className:A.metricBreakdownHeader},g().createElement("div",null,g().createElement("div",{className:A.metricBreakdownTitle,style:{color:e.color}},e.label),g().createElement("div",{className:A.metricBreakdownReason},He(e.scoreDriver,q.algorithm)," | ",xe[e.confidenceLabel])),g().createElement("span",{className:A.severityBadge,style:{background:`${we[e.severityLabel]}22`,color:we[e.severityLabel]}},be[e.severityLabel]," ",e.severityScore)),g().createElement("div",{className:A.metricBreakdownGrid},g().createElement("div",{className:A.metricBreakdownStat},g().createElement("div",{className:A.metricBreakdownStatLabel},"Current"),g().createElement("div",{className:A.metricBreakdownStatValue},$e(e.actual))),g().createElement("div",{className:A.metricBreakdownStat},g().createElement("div",{className:A.metricBreakdownStatLabel},"Expected"),g().createElement("div",{className:A.metricBreakdownStatValue},$e(e.expected))),g().createElement("div",{className:A.metricBreakdownStat},g().createElement("div",{className:A.metricBreakdownStatLabel},"Change"),g().createElement("div",{className:A.metricBreakdownStatValue},$e(e.deviation))),g().createElement("div",{className:A.metricBreakdownStat},g().createElement("div",{className:A.metricBreakdownStatLabel},"Main reason"),g().createElement("div",{className:A.metricBreakdownStatValue},He(e.scoreDriver,q.algorithm))),g().createElement("div",{className:A.metricBreakdownStat},g().createElement("div",{className:A.metricBreakdownStatLabel},"Confidence"),g().createElement("div",{className:A.metricBreakdownStatValue,style:{color:Ee[e.confidenceLabel]}},xe[e.confidenceLabel])),g().createElement("div",{className:A.metricBreakdownStat},g().createElement("div",{className:A.metricBreakdownStatLabel},"Strength"),g().createElement("div",{className:A.metricBreakdownStatValue,style:{color:we[e.severityLabel]}},$e(e.score)))))))):g().createElement("div",{className:A.subtitle},"Select a detected incident to see why it was flagged, how strong the signal is, and whether it is ready for alerting."))):null,Fa?g().createElement("div",{className:A.sideUtilityStack},O.detectionProfile?g().createElement("div",{className:`${A.card} ${A.profileCard}`},g().createElement("div",{className:A.cardTitle},"Active detection profile"),g().createElement("div",{className:`${A.recommendationText} ${A.profileSummary}`},ai),g().createElement("div",{className:A.profileDetailGrid},g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Setup mode"),g().createElement("div",{className:A.detailValue},le[q.setupMode])),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Metric preset"),g().createElement("div",{className:A.detailValue},de[q.metricPreset])),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Effective preset"),g().createElement("div",{className:A.detailValue},"custom"===q.effectiveMetricPreset?"Custom":de[q.effectiveMetricPreset])),g().createElement("div",{className:A.detailStat},g().createElement("div",{className:A.detailLabel},"Severity preset"),g().createElement("div",{className:A.detailValue},ve[q.severityPreset])))):null,O.exports?g().createElement("div",{className:`${A.card} ${A.handoffCard}`},g().createElement("div",{className:A.handoffHeader},g().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},g().createElement("div",{className:A.cardTitle},"Alerting & automation"),g().createElement("div",{className:A.subtitle},"Optional handoff only. Daily alert setup should use the inspector buttons; expand this when you need raw JSON.")),g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>vt(e=>!e)},gt?"Hide exports":"Show exports")),gt?g().createElement(g().Fragment,null,g().createElement("div",{className:A.feedRuleCard},g().createElement("div",{className:A.handoffHeader},g().createElement("div",{className:A.cardTitle},"Annotation export"),g().createElement("button",{type:"button",className:A.actionButtonSecondary,onClick:()=>{St(ni).then(()=>Je({tone:"success",message:"Copied the annotation export JSON."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the annotation export JSON."}))}},"Copy JSON")),g().createElement("div",{className:A.subtitle},"Use this JSON as a ready annotation or incident handoff payload."),g().createElement("pre",{className:A.monoBlock},ni)),g().createElement("div",{className:A.feedRuleCard},g().createElement("div",{className:A.handoffHeader},g().createElement("div",{style:{minWidth:0,flex:"1 1 220px"}},g().createElement("div",{className:A.cardTitle},"Alert rule export"),g().createElement("div",{className:A.subtitle},ri?`Paste this ${Ut} into Grafana Alerting, then set WHEN QUERY IS ABOVE ${si} FOR 10m and evaluate every 3m.`:"Sync anomaly score feed first to generate an alert-ready anomaly score query.")),g().createElement("button",{type:"button",className:A.actionButtonSecondary,disabled:!ri,onClick:()=>{ri?St(ri).then(()=>Je({tone:"success",message:"Copied the alert query for Grafana Alerting."})).catch(e=>Je({tone:"error",message:e instanceof Error?e.message:"Failed to copy the alert query."})):Je({tone:"error",message:"Sync anomaly score feed first to generate the alert query."})}},"Copy query")),g().createElement("div",null,g().createElement("div",{className:A.subtitle},"Suggested labels"),g().createElement("div",{className:A.labelChipGrid,style:{marginTop:8}},Object.entries(ui).map(([e,t])=>g().createElement("span",{key:e,className:A.labelChip,title:`${e}=${t}`},g().createElement("span",{className:A.labelChipKey},e),g().createElement("span",null,"="),g().createElement("span",{className:A.labelChipValue},t))))),g().createElement("div",{className:A.codeLine},ri||"Sync anomaly score feed first to generate an alert-ready query."),g().createElement("pre",{className:A.monoBlock},bi))):null):null):null):null),O.inspector?g().createElement("aside",{className:A.inspectorRail},Ui):null));var Qi,Gi}).setPanelOptions(e=>e.addTextInput({path:"title",name:"Panel title",description:"Short label shown above the anomaly chart.",defaultValue:"Anomaly detector",category:ia}).addRadio({path:"setupMode",name:"Setup mode",description:"Recommended mode keeps the UI simple. Advanced mode unlocks manual algorithm controls.",defaultValue:"recommended",settings:{options:ca},category:ia}).addSelect({path:"metricPreset",name:"Metric type",description:"Start with Auto unless you already know the metric family.",defaultValue:"auto",settings:{options:ha},category:ia,showIf:e=>"advanced"!==e.setupMode&&"custom"!==e.metricPreset}).addRadio({path:"detectionMode",name:"Detection mode",description:"Single metric scores each series independently. Multi metric combines same-timestamp signals into one event score.",defaultValue:"single",settings:{options:da},category:ia}).addSelect({path:"scoreFeedMode",name:"Score feed mode",description:"Publish the anomaly scores detected by this plugin panel to Prometheus metrics or an exporter sink.",defaultValue:"auto",settings:{options:ua},category:na}).addSelect({path:"scoreFeedTarget",name:"Score feed target",description:"Choose where the plugin-computed anomaly score snapshot is published.",defaultValue:"prometheus",settings:{options:pa},category:na,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedEndpoint",name:"Exporter endpoint",description:"Browser-side endpoint for the anomaly exporter. The plugin posts detected score snapshots here.",defaultValue:"http://127.0.0.1:9110",category:na,showIf:e=>"off"!==e.scoreFeedMode}).addTextInput({path:"scoreFeedRuleNamePrefix",name:"Rule name prefix",description:"Optional short prefix used when naming the published anomaly score feed for this panel.",defaultValue:"",category:na,showIf:e=>"off"!==e.scoreFeedMode}).addSelect({path:"bucketSpan",name:"Bucket span",description:"Optional pre-aggregation before anomaly scoring. Auto keeps the panel responsive on large or live queries.",defaultValue:"auto",settings:{options:ga},category:ra}).addSelect({path:"algorithm",name:"Algorithm",description:"Visible in Advanced mode when you want to pick the scoring strategy yourself.",defaultValue:"zscore",settings:{options:fa},category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addSelect({path:"anomalyDirection",name:"Anomaly direction",description:"Elastic-style mean direction policy. Choose whether high, low, or both deviations may become anomalies.",defaultValue:"high_or_low",settings:{options:ma},category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"minimumAbsoluteDeviation",name:"Minimum absolute deviation",description:"Ignore statistically unusual changes smaller than this metric-unit difference. Use 0 to disable the floor.",defaultValue:0,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"minimumRelativeDeviation",name:"Minimum relative deviation",description:"Minimum proportional change from the baseline; 0.10 means 10%. Use 0 to disable the floor.",defaultValue:0,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"minimumActivity",name:"Minimum activity",description:"Suppress anomaly decisions while both the current value and baseline are below this activity floor.",defaultValue:0,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"persistenceBuckets",name:"Required anomaly buckets",description:"Number of anomalous evaluations required inside the persistence window. Recommended: 3 of 4.",defaultValue:3,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"persistenceWindow",name:"Persistence window",description:"Evaluation bucket window used by the N-of-M anomaly decision. Must be at least the required bucket count.",defaultValue:4,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"recoveryThreshold",name:"Recovery threshold",description:"Keep an open incident active until its raw score falls below this lower threshold. Use 0 to close at the anomaly threshold.",defaultValue:3,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"recoveryBuckets",name:"Recovery buckets",description:"Consecutive recovered evaluations required before an open incident closes.",defaultValue:2,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"cooldownBuckets",name:"Cooldown buckets",description:"Evaluations to suppress reopening after recovery. Use 0 to disable cooldown.",defaultValue:2,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addBooleanSwitch({path:"dataQualityGate",name:"Block degraded data",description:"Prevent thin, flatline, or irregular data from becoming an anomaly until data quality is healthy.",defaultValue:!0,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addSliderInput({path:"sensitivity",name:"Anomaly threshold",description:"Move left to catch subtler changes (more alerts), or right to suppress noise (fewer alerts). Balanced 4.0 is the recommended starting point.",defaultValue:4,settings:{min:.2,max:10,step:.1,marks:{[m]:"Sensitive",[p]:"Balanced",[u]:"Strict"},ariaLabelForHandle:"Anomaly threshold: lower is more sensitive, higher is stricter"},category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"baselineWindow",name:"History & warm-up window",description:"Baseline bucket count for rolling models. For Harmonic, this controls quality diagnostics only; its warm-up is two full cycles set by Season length.",defaultValue:12,category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"seasonalitySamples",name:"Season length (samples)",description:"Samples per cycle AFTER bucketing. Example: 288 for a daily pattern in 5-minute data. Harmonic requires 8-4096 and two full cycles of warm-up.",defaultValue:24,category:sa,showIf:e=>!("advanced"!==e.setupMode&&"custom"!==e.metricPreset||"seasonal"!==e.algorithm&&"harmonic"!==e.algorithm)}).addSelect({path:"seasonalRefinement",name:"Seasonal refinement",description:"Choose whether seasonal matching is based on fixed cycles, hour-of-day, or weekday plus hour.",defaultValue:"cycle",settings:{options:ya},category:sa,showIf:e=>("advanced"===e.setupMode||"custom"===e.metricPreset)&&"seasonal"===e.algorithm}).addSelect({path:"severityPreset",name:"Severity preset",description:"Controls how severity scores are translated into warning, high, and critical style labels.",defaultValue:"balanced",settings:{options:va},category:sa,showIf:e=>"advanced"===e.setupMode||"custom"===e.metricPreset}).addNumberInput({path:"maxAnomalies",name:"Max anomalies in summary",description:"Limits the number of highest scoring anomalies listed below the chart.",defaultValue:8,category:oa}).addBooleanSwitch({path:"showBands",name:"Show expected band",defaultValue:!0,category:oa}).addBooleanSwitch({path:"showExpectedLine",name:"Show expected line",defaultValue:!0,category:oa}).addBooleanSwitch({path:"showInitialLabels",name:"Initial labels",description:"Show the panel title, algorithm, bucket, selected series, and datasource context.",defaultValue:!0,category:la}).addBooleanSwitch({path:"showStatistics",name:"Statistics",description:"Show severity, confidence, anomaly count, and data quality cards.",defaultValue:!0,category:la}).addBooleanSwitch({path:"showAnomalyFeed",name:"Anomaly feed",description:"Show the incident overview ribbon, timeline, and incident list.",defaultValue:!0,category:la}).addBooleanSwitch({path:"showMainChart",name:"Main chart",defaultValue:!0,category:la}).addBooleanSwitch({path:"showSeriesSummary",name:"Series summary",defaultValue:!0,category:la}).addBooleanSwitch({path:"showInspector",name:"Anomaly inspector",defaultValue:!0,category:la}).addBooleanSwitch({path:"showScoreFeed",name:"Score feed status",description:"Show the selected score target and its synchronization status. Publishing remains controlled by Score feed mode.",defaultValue:!0,category:la}).addBooleanSwitch({path:"showDetectionProfile",name:"Detection profile",defaultValue:!0,category:la}).addBooleanSwitch({path:"showInlineSeriesLabels",name:"Show inline series labels",description:"Show each series name at the right edge of the chart so the line identity stays visible without scanning the legend.",defaultValue:!0,category:oa}).addBooleanSwitch({path:"showFocusBand",name:"Show anomaly focus band",description:"Render a zoomed local band around the selected anomaly for faster incident review.",defaultValue:!1,category:oa}).addSelect({path:"timeAxisDensity",name:"Time axis density",description:"Control how many time labels are shown on the chart.",defaultValue:"auto",settings:{options:ba},category:oa}).addSelect({path:"timeAxisPlacement",name:"Time axis placement",description:"Choose whether time labels are shown only at the bottom or on both top and bottom edges.",defaultValue:"top_and_bottom",settings:{options:wa},category:oa}).addSelect({path:"markerShapeMode",name:"Anomaly marker style",description:"Choose whether severity is communicated with different marker shapes or with classic circular markers.",defaultValue:"severity",settings:{options:xa},category:oa}).addBooleanSwitch({path:"showExports",name:"Show export blocks",defaultValue:!1,category:la}));return l})());
//# sourceMappingURL=module.js.map